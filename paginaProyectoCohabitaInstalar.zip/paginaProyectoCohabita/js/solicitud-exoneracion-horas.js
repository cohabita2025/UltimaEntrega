var cantidadPruebas = 0;



function agregarArchivo() {
    const inputTrucho = document.getElementById("input-file-falso");
    const listaPruebas = document.getElementById("pruebas-archivos");

    if (inputTrucho.files.length === 0) return;

    const archivoTrucho = inputTrucho.files[0];

    // Revisar si ya existe un input con el mismo archivo
    const pruebas = document.getElementsByClassName("prueba");
    for (const actual of pruebas) {
        if (actual.files.length === 0) continue; // prevención
        const archivoActual = actual.files[0];
        if (
            archivoActual.name === archivoTrucho.name &&
            archivoActual.size === archivoTrucho.size &&
            archivoActual.type === archivoTrucho.type
        ) {
            console.log("Archivo ya agregado, no se repite");
            return; // salir si ya existe
        }
    }

    // Incrementar contador
    cantidadPruebas++;

    // Crear div contenedor
    const nuevoDiv = document.createElement("div");
    nuevoDiv.classList.add("input-archivo");
    nuevoDiv.id = `div-prueba${cantidadPruebas}`;

    // Crear input file y asignarle el archivo usando DataTransfer
    const dt = new DataTransfer();
    dt.items.add(archivoTrucho);

    const nuevoInput = document.createElement("input");
    nuevoInput.type = "file";
    nuevoInput.classList.add("prueba");
    nuevoInput.id = `prueba${cantidadPruebas}`;
    nuevoInput.files = dt.files;

    // Crear párrafo con nombre de archivo
    const p = document.createElement("p");
    p.classList.add("nombre-archivo");
    p.textContent = archivoTrucho.name;

    // Crear botón de borrar
    const btn = document.createElement("button");
    btn.type = "button";
    btn.innerHTML = `<img src="../archivos/imagenes/SimboloTachar.svg" alt="">`;
    btn.onclick = () => nuevoDiv.remove();

    // Agregar todo al div
    nuevoDiv.appendChild(nuevoInput);
    nuevoDiv.appendChild(p);
    nuevoDiv.appendChild(btn);

    // Agregar el div al inicio de la lista
    listaPruebas.prepend(nuevoDiv);
}

function validarDatos(){
    var datosValidos=true;

    const conclusion = document.getElementById("conclusion");
    const pruebas = document.getElementsByClassName("prueba");
    const listaPruebas = document.getElementById("pruebas-archivos");
    const mesInicio = document.getElementById("mesInputInicio");
    const mesFin = document.getElementById("mesInputFin");
    const diaInicio = document.getElementById("dia_inicio");
    const diaFin = document.getElementById("dia_fin");
    const anioInicio = document.getElementById("anio_inicio");
    const anioFin = document.getElementById("anio_fin");

    if(!mesInicio.checkValidity()){
        datosValidos=false;            
        if (!mesInicio.parentNode.parentNode.parentNode.classList.contains("invalido")){
            mesInicio.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un mes valido.</p>');
            mesInicio.parentNode.parentNode.parentNode.classList.add("invalido");
        }
    }else{
        console.log(anioInicio.value+'-'+mesInicio.value+'-'+diaInicio.value);
        

        const fechaInicio = new Date(anioInicio.value, mesInicio.value - 1, diaInicio.value);
        console.log(fechaInicio);
        console.log(fechaInicio.getDay());
        console.log((anioInicio.value+'-'+mesInicio.value+'-'+diaInicio.value));
        if(fechaInicio.getDay() !== 1){
            console.log(fechaInicio.getDay());
            console.log((anioInicio.value+'-'+mesInicio.value+'-'+diaInicio.value));
            datosValidos=false;            
            if (!mesInicio.parentNode.parentNode.parentNode.classList.contains("invalido")){
                mesInicio.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">La fecha de inicio debe ser lunes.</p>');
                mesInicio.parentNode.parentNode.parentNode.classList.add("invalido");
            }else{
                mesInicio.parentNode.parentNode.parentNode.classList.remove("invalido");
                mesInicio.parentNode.parentNode.parentNode.querySelector("p.mensaje-error").remove();
                mesInicio.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">La fecha de inicio debe ser lunes.</p>');
                mesInicio.parentNode.parentNode.parentNode.classList.add("invalido");
            }
        }else{
            if (mesInicio.parentNode.parentNode.parentNode.querySelector("p.mensaje-error") !== null){
                console.log("josesu")
                mesInicio.parentNode.parentNode.parentNode.classList.remove("invalido");
                mesInicio.parentNode.parentNode.parentNode.querySelector("p.mensaje-error").remove();
            }
        }
    }

    if(!mesFin.checkValidity()){
        datosValidos=false;            
        if (!mesFin.parentNode.parentNode.parentNode.classList.contains("invalido")){
            mesFin.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un mes valido.</p>');
            mesFin.parentNode.parentNode.parentNode.classList.add("invalido");
        }
    }else{
        const fechaInicio = new Date(anioFin.value, mesFin.value - 1, diaFin.value);
        console.log(fechaInicio.getDay());
        console.log((anioFin.value+'-'+mesFin.value+'-'+diaFin.value));
        if(fechaInicio.getDay() !== 0){
            console.log(fechaInicio.getDay());
            console.log((anioFin.value+'-'+mesFin.value+'-'+diaFin.value));
            datosValidos=false;            
            if (!mesFin.parentNode.parentNode.parentNode.classList.contains("invalido")){
                mesFin.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">La fecha de Fin debe ser domingo.</p>');
                mesFin.parentNode.parentNode.parentNode.classList.add("invalido");
            }else{
                mesFin.parentNode.parentNode.parentNode.classList.remove("invalido");
                mesFin.parentNode.parentNode.parentNode.querySelector("p.mensaje-error").remove();
                mesFin.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">La fecha de Fin debe ser domingo no .</p>');
                mesFin.parentNode.parentNode.parentNode.classList.add("invalido");
            }
        }else{
            if (mesFin.parentNode.parentNode.parentNode.querySelector("p.mensaje-error") !== null){
                console.log("josesu")
                mesFin.parentNode.parentNode.parentNode.classList.remove("invalido");
                mesFin.parentNode.parentNode.parentNode.querySelector("p.mensaje-error").remove();
            }
        }
    }

    if(!conclusion.checkValidity()){
    
        datosValidos=false;            
    
        if (!conclusion.parentNode.classList.contains("invalido")){
            conclusion.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una razon valida.</p>');
            conclusion.parentNode.classList.add("invalido");
        }
    }else{
        if (conclusion.parentNode.querySelector("p.mensaje-error") !== null){
            conclusion.parentNode.classList.remove("invalido");
            conclusion.parentNode.querySelector("p.mensaje-error").remove();
        }
    } 

    if(pruebas.length === 0){
    
        datosValidos=false;            
    
        if (!listaPruebas.classList.contains("invalido")){
            listaPruebas.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar pruebas..</p>');
            listaPruebas.classList.add("invalido");
        }
    }else{
        if (listaPruebas.parentNode.querySelector("p.mensaje-error") !== null){
            listaPruebas.classList.remove("invalido");
            listaPruebas.parentNode.querySelector("p.mensaje-error").remove();
        }
    } 

    return datosValidos;
}

function recolectarDatos(){
    var datos={};
    var pruebas=[];

    var mesInicio = document.getElementById("mesInputInicio").value;
    var mesFin = document.getElementById("mesInputFin").value;
    
    var diaInicio = document.getElementById("dia_inicio").value;
    var diaFin = document.getElementById("dia_fin").value;
    
    const anioInicio = document.getElementById("anio_inicio").value;
    const anioFin = document.getElementById("anio_fin").value;

    if(diaInicio.length === 1){
        diaInicio = "0" + diaInicio
    }

    if(diaFin.length === 1){
        diaFin = "0" + diaFin
    }

    if(mesInicio.length === 1){
        mesInicio = "0" + mesInicio
    }

    if(mesFin.length === 1){
        mesFin = "0" + mesFin
    }

    datos.fecha_fin = (anioFin+'-'+mesFin+'-'+diaFin);
    datos.fecha_inicio = (anioInicio+'-'+mesInicio+'-'+diaInicio);
    datos.cedula_adulto = usuario.cedula
    datos.motivo = document.getElementById("conclusion").value ;

    const pruebasDivs=document.getElementsByClassName("input-archivo");
    
    for(const actual of pruebasDivs){
        pruebas.push(actual.querySelector("input").files[0]);
    }

    datos.pruebas=pruebas;

    return datos;
}


async function enviarSolicitudExoneracion() {
    if (validarDatos()) {
        if (await confirmarAccion('¿Enviar?')) {
            const datos = recolectarDatos(); // tu función que devuelve cant_horas, motivo, id_familia y archivos

            const formData = new FormData();
            formData.append("fecha_fin", datos.fecha_fin);
            formData.append("fecha_inicio", datos.fecha_inicio);
            formData.append("motivo", datos.motivo);
            formData.append("cedula_adulto", datos.cedula_adulto);

            datos.pruebas.forEach(archivo => formData.append("pruebas[]", archivo));

            console.log("fecha fin " , datos.fecha_fin ,"fecha_inicio " , datos.fecha_inicio ,"motivo" , datos.motivo , "cedula_adulto" , datos.cedula_adulto ,"pruebas" , datos.pruebas )

            try {
                const respuesta = await fetch("../php/solicitud_exoneracion_horas.php", { // ajustar ruta según tu HTML
                    method: "POST",
                    body: formData
                });
                const result = await respuesta.json();
                console.log("===== DEBUG EXONERACION HORAS =====");
                console.log(result);
                window.location.href="../html/pagina-principal.html";
            } catch (err) {
                console.error("Error al enviar solicitud:", err);
            }
        }
    }
}
