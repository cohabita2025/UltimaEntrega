
function recopilarFamiliaresTexto() {
    const cedulaTitular = document.getElementById("cedula-titular").value;
    const listaFamiliares = document.getElementsByClassName("familiar");
    let Familiares = [];
    let rolCoperativa = "";
    let contraseniaTitular = "";

    for (const familiarActual of listaFamiliares) {
        let nombreFamiliar = familiarActual.querySelector(".nombre").value;
        let primerApellidoFamiliar = familiarActual.querySelector(".primer-apellido").value;
        let segundoApellidoFamiliar = familiarActual.querySelector(".segundo-apellido").value;
        let cedulaFamiliar = familiarActual.querySelector(".cedula").value;

        let dia = familiarActual.querySelector(".input-dia").value;
        if (dia.length === 1) dia = "0" + dia;

        let mes = familiarActual.querySelector(".select-mes").value;
        if (mes.length === 1) mes = "0" + mes;

        let anio = familiarActual.querySelector(".input-anio").value;
        let fechaNacimiento = `${anio}-${mes}-${dia}`;

        let correo = familiarActual.querySelector(".input-gmail").value;
        let telefono = familiarActual.querySelector(".input-numero-telefonico").value;
        let rolEnFamilia = familiarActual.querySelector(".select-rol-familiar").selectedOptions[0].text;
        let genero = familiarActual.querySelector(".select-genero").selectedOptions[0].text[0];

        if (cedulaFamiliar === cedulaTitular) {
            rolCoperativa = "titular";
            contraseniaTitular = document.getElementById("contrasenia-titular").value;
        }else{
            rolCoperativa= "";
            contraseniaTitular = null
        }

        Familiares.push({
            nombre: nombreFamiliar,
            primerApellido: primerApellidoFamiliar,
            segundoApellido: segundoApellidoFamiliar,
            genero: genero,
            fechaNacimiento: fechaNacimiento,
            cedula: cedulaFamiliar,
            rolEnFamilia: rolEnFamilia,

            correo: correo,
            telefono: telefono,
            rol: rolCoperativa,
            contrasenia: contraseniaTitular
        });
    }

    return Familiares;
}

function recopilarFamiliaresFiles() {
    const cedulaTitular = document.getElementById("cedula-titular").value;
    const listaFamiliares = document.getElementsByClassName("familiar");
    let Familiares = [];

    for (const familiarActual of listaFamiliares) {
        let copiaCedulaInput = familiarActual.querySelector(".input-copia-cedula");
        let copiaCedula = copiaCedulaInput ? copiaCedulaInput.files[0] : null;

        let comprobanteIngresosInput = familiarActual.querySelector(".input-comprobante-ingresos");
        let comprobanteIngresos = comprobanteIngresosInput ? comprobanteIngresosInput.files[0] : null;

        let declaracionNoViviendaInput = familiarActual.querySelector(".input-declaracion-no-vivienda");
        let declaracionNoVivienda = declaracionNoViviendaInput ? declaracionNoViviendaInput.files[0] : null;

        let fotoInput = familiarActual.querySelector(".input-foto");
        let foto = fotoInput ? fotoInput.files[0] : null;

        Familiares.push({
            copiaCedula: copiaCedula,
            foto: foto,
            declaracionNoVivienda: declaracionNoVivienda,
            comprobanteIngresos: comprobanteIngresos

        });
    }

    return Familiares;
}

async function obtenerCedulas() {
  try {
    const response = await fetch('../php/obtener_cedulas.php'); // tu archivo PHP
    const data = await response.json(); // parsea el JSON

    if (data.status === 'success') {
      // Aquí tienes el array de cédulas
      const cedulas = data.cedulas;
      // Puedes devolverlo para usarlo fuera de la función
      return cedulas;
    } else {
      console.error('Error en PHP:', data.message);
      return []; // devuelve array vacío en caso de error
    }

  } catch (error) {
    console.error('Error en fetch:', error);
    return []; // devuelve array vacío si falla la conexión
  }
}

function obtenerCedulasActuales(){
    var cedulas=[];
    for( const familiar of recopilarFamiliaresTexto()){
        cedulas.push(familiar.cedula)
    }
    return cedulas;
}

function compararCedulas(cedula , arrayCedulas){
    var conclusion=false;
    for(const cedulaActual of arrayCedulas){
        if(cedulaActual === cedula){
            console.log("si entra")
            conclusion=true;
        }
    }
    return conclusion
}

function cedulaRepetida(idFamiliar){
    const cedulaFamiliarActual= document.getElementById(idFamiliar).querySelector(".cedula").value;
    let conclusion=false;
    const listaFamiliares = document.getElementsByClassName("familiar");
    let familiaresCedula = [];
    for(const familiarActual of listaFamiliares){
        let cedulaFamiliar = familiarActual.querySelector(".cedula").value;
        if(cedulaFamiliar.length === 8){
            familiaresCedula.push({
                id: familiarActual.id,
                cedula: cedulaFamiliar
            })
        }
    }


    for(const familiarActual of familiaresCedula){
        if(familiarActual.id !== idFamiliar){
            if(familiarActual.cedula === cedulaFamiliarActual){
                conclusion=true;
            }
        }
    }

    return conclusion

}

function titularMayorDeEdad(){
    var conclusion=false;
    const cedulaTitular = document.getElementById("cedula-titular").value;
    const listaFamiliares = document.getElementsByClassName("familiar");
    for(const familiar of listaFamiliares){
        if(familiar.querySelector('.cedula').value === cedulaTitular){
            const dia = parseInt(familiar.querySelector('.input-dia').value, 10);
            const mes = parseInt(familiar.querySelector('.select-mes').value, 10) - 1; // JS cuenta 0-11
            const anio = parseInt(familiar.querySelector('.input-anio').value, 10);
            const hoy = new Date();
            const fechaNacimiento = new Date(anio, mes, dia);
            const diferencia = hoy - fechaNacimiento; // hoy - nacimiento
            const edad = Math.floor(diferencia / (1000 * 60 * 60 * 24 * 365.25));
            if(edad > 18){
                conclusion=true;
            }
        }
    }
    return conclusion
}


async function validacionDatos(){
    var datosValidos=true;
    const cedulasRegistradas = await obtenerCedulas(); 
    const listaFamiliares = document.getElementsByClassName("familiar");
    let FamiliaresInput = [];

    for (const familiarActual of listaFamiliares) {

        let nombreFamiliar = familiarActual.querySelector(".nombre");
        let primerApellidoFamiliar = familiarActual.querySelector(".primer-apellido");
        let segundoApellidoFamiliar = familiarActual.querySelector(".segundo-apellido");
        let cedulaFamiliar = familiarActual.querySelector(".cedula");
        let dia = familiarActual.querySelector(".input-dia");
        let mes = familiarActual.querySelector(".select-mes");
        let anio = familiarActual.querySelector(".input-anio");
        let correo = familiarActual.querySelector(".input-gmail");
        let telefono = familiarActual.querySelector(".input-numero-telefonico");
        let rolEnFamilia = familiarActual.querySelector(".select-rol-familiar");
        let genero = familiarActual.querySelector(".select-genero");
        let copiaCedulaInput = familiarActual.querySelector(".input-copia-cedula");
        let comprobanteIngresosInput = familiarActual.querySelector(".input-comprobante-ingresos");
        let declaracionNoViviendaInput = familiarActual.querySelector(".input-declaracion-no-vivienda");
        let fotoInput = familiarActual.querySelector(".input-foto");

        FamiliaresInput.push({
            familiarId:familiarActual.id,
            nombre: nombreFamiliar,
            primerApellido: primerApellidoFamiliar,
            segundoApellido: segundoApellidoFamiliar,
            cedula: cedulaFamiliar,
            diaNacimiento: dia,
            mesNacimiento: mes,
            anioNacimiento: anio,
            correo: correo,
            telefono: telefono,
            rolEnFamilia: rolEnFamilia,
            genero: genero,
            copiaCedula: copiaCedulaInput,
            comprobanteIngresos: comprobanteIngresosInput,
            declaracionNoVivienda: declaracionNoViviendaInput,
            foto: fotoInput

        });
    }


    for (const familiarActual of FamiliaresInput){

        if(!familiarActual.nombre.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.nombre.parentNode.classList.contains("invalido")){
                familiarActual.nombre.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un nombre valido.</p>');
                familiarActual.nombre.parentNode.classList.add("invalido");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{
            console.log("eso")
            if (familiarActual.nombre.parentNode.querySelector("p.mensaje-error") !== null){
                console.log("josesu")
                familiarActual.nombre.parentNode.classList.remove("invalido");
                familiarActual.nombre.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        if(!familiarActual.primerApellido.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.primerApellido.parentNode.classList.contains("invalido")){
                familiarActual.primerApellido.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un apellido valido.</p>');
                familiarActual.primerApellido.parentNode.classList.add("invalido");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{
            console.log("eso")
            if (familiarActual.primerApellido.parentNode.querySelector("p.mensaje-error") !== null){
                console.log("josesu")
                familiarActual.primerApellido.parentNode.classList.remove("invalido");
                familiarActual.primerApellido.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        if(!familiarActual.correo.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.correo.parentNode.classList.contains("invalido")){
                familiarActual.correo.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un correo valido.</p>');
                familiarActual.correo.parentNode.classList.add("invalido");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{
            console.log("eso")
            if (familiarActual.correo.parentNode.querySelector("p.mensaje-error") !== null){
                console.log("josesu")
                familiarActual.correo.parentNode.classList.remove("invalido");
                familiarActual.correo.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        if(!familiarActual.telefono.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.telefono.parentNode.classList.contains("invalido")){
                familiarActual.telefono.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un telefono valido.</p>');
                familiarActual.telefono.parentNode.classList.add("invalido");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{
            console.log("eso")
            if (familiarActual.telefono.parentNode.querySelector("p.mensaje-error") !== null){
                console.log("josesu")
                familiarActual.telefono.parentNode.classList.remove("invalido");
                familiarActual.telefono.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        if(!familiarActual.rolEnFamilia.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.rolEnFamilia.parentNode.classList.contains("invalido")){
                familiarActual.rolEnFamilia.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un rol valido.</p>');
                familiarActual.rolEnFamilia.parentNode.classList.add("invalido");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{
            console.log("eso")
            if (familiarActual.rolEnFamilia.parentNode.querySelector("p.mensaje-error") !== null){
                console.log("josesu")
                familiarActual.rolEnFamilia.parentNode.classList.remove("invalido");
                familiarActual.rolEnFamilia.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        if(!familiarActual.genero.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.genero.parentNode.classList.contains("invalido")){
                familiarActual.genero.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un genero valido.</p>');
                familiarActual.genero.parentNode.classList.add("invalido");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{
            if (familiarActual.genero.parentNode.querySelector("p.mensaje-error") !== null){
                familiarActual.genero.parentNode.classList.remove("invalido");
                familiarActual.genero.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        if(!familiarActual.mesNacimiento.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.mesNacimiento.parentNode.parentNode.parentNode.classList.contains("invalido")){
                familiarActual.mesNacimiento.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un mes valido.</p>');
                familiarActual.mesNacimiento.parentNode.parentNode.parentNode.classList.add("invalido");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{
            console.log("eso")
            if (familiarActual.mesNacimiento.parentNode.parentNode.parentNode.querySelector("p.mensaje-error") !== null){
                console.log("josesu")
                familiarActual.mesNacimiento.parentNode.parentNode.parentNode.classList.remove("invalido");
                familiarActual.mesNacimiento.parentNode.parentNode.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        if(!familiarActual.cedula.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.cedula.parentNode.classList.contains("invalido")){
                console.log("cedula mal puesta")

                familiarActual.cedula.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una cedula valida.</p>');
                familiarActual.cedula.parentNode.classList.add("invalido");
            }else{
                familiarActual.cedula.parentNode.classList.remove("invalido");
                familiarActual.cedula.parentNode.querySelector("p.mensaje-error").remove();

                familiarActual.cedula.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una cedula valida.</p>');
                familiarActual.cedula.parentNode.classList.add("invalido");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){       
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{

            if(compararCedulas(familiarActual.cedula.value , cedulasRegistradas)){
                datosValidos=false;
                console.log("cedula ya registrada")
                if (familiarActual.cedula.parentNode.querySelector("p.mensaje-error") !== null){
                    familiarActual.cedula.parentNode.querySelector("p.mensaje-error").remove();    
                }
                familiarActual.cedula.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Cedula ya registrada.</p>');
                familiarActual.cedula.parentNode.classList.add("invalido");
                if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){       
                desplegarFamiliar(familiarActual.familiarId)
                }
            }else if(cedulaRepetida(familiarActual.familiarId)){ 
                datosValidos=false;
                console.log("cedula repetida")
                if (familiarActual.cedula.parentNode.querySelector("p.mensaje-error") !== null){
                    familiarActual.cedula.parentNode.querySelector("p.mensaje-error").remove();    
                }
                familiarActual.cedula.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Cedula repetida.</p>');
                familiarActual.cedula.parentNode.classList.add("invalido");
                if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){       
                    desplegarFamiliar(familiarActual.familiarId)
                }
            }else if (familiarActual.cedula.parentNode.querySelector("p.mensaje-error") !== null){
                console.log("cedula correcta")
                familiarActual.cedula.parentNode.classList.remove("invalido");
                familiarActual.cedula.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        if(!familiarActual.copiaCedula.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.copiaCedula.parentNode.classList.contains("invalido-archivo")){
                familiarActual.copiaCedula.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una copia de cedula valida.</p>');
                familiarActual.copiaCedula.parentNode.classList.add("invalido-archivo");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{
            console.log("eso")
            if (familiarActual.copiaCedula.parentNode.querySelector("p.mensaje-error") !== null){
                console.log("josesu")
                familiarActual.copiaCedula.parentNode.classList.remove("invalido-archivo");
                familiarActual.copiaCedula.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        if(!familiarActual.comprobanteIngresos.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.comprobanteIngresos.parentNode.classList.contains("invalido-archivo")){
                familiarActual.comprobanteIngresos.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un comprobante de ingresos valido.</p>');
                familiarActual.comprobanteIngresos.parentNode.classList.add("invalido-archivo");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{
            if (familiarActual.comprobanteIngresos.parentNode.querySelector("p.mensaje-error") !== null){
                familiarActual.comprobanteIngresos.parentNode.classList.remove("invalido-archivo");
                familiarActual.comprobanteIngresos.parentNode.querySelector("p.mensaje-error").remove();
            }
        }        
        
        if(!familiarActual.declaracionNoVivienda.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.declaracionNoVivienda.parentNode.classList.contains("invalido-archivo")){
                familiarActual.declaracionNoVivienda.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una declaracion no vivienda valida.</p>');
                familiarActual.declaracionNoVivienda.parentNode.classList.add("invalido-archivo");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{
            if (familiarActual.declaracionNoVivienda.parentNode.querySelector("p.mensaje-error") !== null){
                familiarActual.declaracionNoVivienda.parentNode.classList.remove("invalido-archivo");
                familiarActual.declaracionNoVivienda.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        if(!familiarActual.foto.checkValidity()){
            datosValidos=false;            
            if (!familiarActual.foto.parentNode.classList.contains("invalido-archivo")){
                familiarActual.foto.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una foto valida.</p>');
                familiarActual.foto.parentNode.classList.add("invalido-archivo");
            }
            if(window.getComputedStyle(document.getElementById(familiarActual.familiarId).querySelector(".informacion-basica")).display == 'flex'){
                desplegarFamiliar(familiarActual.familiarId)
            }
        }else{
            if (familiarActual.foto.parentNode.querySelector("p.mensaje-error") !== null){
                familiarActual.foto.parentNode.classList.remove("invalido-archivo");
                familiarActual.foto.parentNode.querySelector("p.mensaje-error").remove();
            }
        }
    }

    inputContrasenia = document.getElementById('contrasenia-titular');
    inputRepetirContrasenia = document.getElementById('repetir-contrasenia-titular');
    inputCedulaTitular = document.getElementById('cedula-titular');

    if(!inputContrasenia.checkValidity()){
        datosValidos=false;            
        if (!inputContrasenia.parentNode.classList.contains("invalido")){
            inputContrasenia.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una contraseña valida.</p>');
            inputContrasenia.parentNode.classList.add("invalido");
        }else{
            inputContrasenia.parentNode.classList.remove("invalido");
            inputContrasenia.parentNode.querySelector("p.mensaje-error").remove();
            if(inputRepetirContrasenia.parentNode.classList.contains("invalido")){
                inputRepetirContrasenia.parentNode.classList.remove("invalido");
                inputRepetirContrasenia.parentNode.querySelector("p.mensaje-error").remove();
            }
            inputContrasenia.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una contraseña valida.</p>');
            inputContrasenia.parentNode.classList.add("invalido");
        }    
    }else{
            
        if(inputContrasenia.value !== inputRepetirContrasenia.value){
            datosValidos=false;            
            if (!inputContrasenia.parentNode.classList.contains("invalido")){
                inputContrasenia.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Las contrasenias deben ser iguales.</p>');
                inputContrasenia.parentNode.classList.add("invalido");
                inputRepetirContrasenia.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Las contrasenias deben ser iguales.</p>');
                inputRepetirContrasenia.parentNode.classList.add("invalido");
            }else{
                inputContrasenia.parentNode.classList.remove("invalido");
                inputContrasenia.parentNode.querySelector("p.mensaje-error").remove();
                if(inputRepetirContrasenia.parentNode.classList.contains("invalido")){
                    inputRepetirContrasenia.parentNode.classList.remove("invalido");
                    inputRepetirContrasenia.parentNode.querySelector("p.mensaje-error").remove();
                }
                inputContrasenia.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Las contrasenias deben ser iguales.</p>');
                inputContrasenia.parentNode.classList.add("invalido");
                inputRepetirContrasenia.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Las contrasenias deben ser iguales.</p>');
                inputRepetirContrasenia.parentNode.classList.add("invalido");
            }    
        }else{
            console.log("else2")
            if(inputContrasenia.parentNode.classList.contains("invalido")){
                inputContrasenia.parentNode.classList.remove("invalido");
                inputContrasenia.parentNode.querySelector("p.mensaje-error").remove();
            }
            if(inputRepetirContrasenia.parentNode.classList.contains("invalido")){
                inputRepetirContrasenia.parentNode.classList.remove("invalido");
                inputRepetirContrasenia.parentNode.querySelector("p.mensaje-error").remove();
            }
        }
    }
    if(!inputCedulaTitular.checkValidity()){
        datosValidos=false;            
        if (!inputCedulaTitular.parentNode.classList.contains("invalido")){
            console.log("cedula mal puesta")
            inputCedulaTitular.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una cedula valida.</p>');
            inputCedulaTitular.parentNode.classList.add("invalido");
        }else{
            inputCedulaTitular.parentNode.classList.remove("invalido");
            inputCedulaTitular.parentNode.querySelector("p.mensaje-error").remove();
            inputCedulaTitular.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una cedula valida.</p>');
            inputCedulaTitular.parentNode.classList.add("invalido");
        }
    }else{
        if(!compararCedulas(inputCedulaTitular.value , obtenerCedulasActuales())){
            datosValidos=false;
            if (inputCedulaTitular.parentNode.querySelector("p.mensaje-error") !== null){
                inputCedulaTitular.parentNode.querySelector("p.mensaje-error").remove();    
            }
            inputCedulaTitular.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">La cedula no coincide con ningun familar.</p>');
            inputCedulaTitular.parentNode.classList.add("invalido");
        }else if(!titularMayorDeEdad()){
            datosValidos=false;
            if (inputCedulaTitular.parentNode.querySelector("p.mensaje-error") !== null){
                inputCedulaTitular.parentNode.querySelector("p.mensaje-error").remove();    
            }
            inputCedulaTitular.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">El titular no puede ser menor de edad.</p>');
            inputCedulaTitular.parentNode.classList.add("invalido");
        }
        else if (inputCedulaTitular.parentNode.querySelector("p.mensaje-error") !== null){
            inputCedulaTitular.parentNode.classList.remove("invalido");
            inputCedulaTitular.parentNode.querySelector("p.mensaje-error").remove();
        }
    }



    return datosValidos;
}

async function enviarFamiliaresCompletos(event) {
    event.preventDefault();

    if(await validacionDatos()){
        // 1️⃣ Recopilar datos
        const familiaresTexto = recopilarFamiliaresTexto();
        const listaFamiliares = document.getElementsByClassName("familiar");
        if (familiaresTexto.length === 0) {
            alert("No hay datos de familiares para enviar");
            return false;
        }
        // 2️⃣ Crear array de archivos
        const familiaresArchivos = Array.from(listaFamiliares).map((f) => ({
            copiaCedula: f.querySelector(".input-copia-cedula")?.files[0] ?? null,
            foto: f.querySelector(".input-foto")?.files[0] ?? null,
            declaracionNoVivienda: f.querySelector(".input-declaracion-no-vivienda")?.files[0] ?? null,
            comprobanteIngresos: f.querySelector(".input-comprobante-ingresos")?.files[0] ?? null
        }));
        // 3️⃣ Construir FormData
        const formData = new FormData();
        formData.append('cedula_titular', document.getElementById("cedula-titular").value);
        formData.append('contrasenia_titular', document.getElementById("contrasenia-titular").value);
        formData.append('familiares_texto', JSON.stringify(familiaresTexto));
        familiaresArchivos.forEach((f, i) => {
            if (!f) return; // proteger contra undefined
            if (f.copiaCedula) formData.append(`copiaCedula_${i}`, f.copiaCedula);
            if (f.foto) formData.append(`foto_${i}`, f.foto);
            if (f.declaracionNoVivienda) formData.append(`declaracionNoVivienda_${i}`, f.declaracionNoVivienda);
            if (f.comprobanteIngresos) formData.append(`comprobanteIngresos_${i}`, f.comprobanteIngresos);
        });
        // 4️⃣ Depuración: log de FormData
        for (let pair of formData.entries()) {
            console.log(pair[0], pair[1]);
        }
        // 5️⃣ Enviar datos al PHP
        try {
            const resp = await fetch('../php/solicitud_registro.php', {
                method: 'POST',
                body: formData
            });
            const resultado = await resp.text();
            console.log("Respuesta PHP:", resultado);
        } catch (err) {
            console.error("Error al enviar los datos:", err);
        }
        window.location.href="../html/confirmacion-solicitud.html";
        return false;
    }
}
