if((usuario.rol !== 'admin') && (usuario.rol !== 'titular')){
    window.location.href="../html/acceso-denegado.html"
}

let id_aporte = sessionStorage.getItem("aporteSeleccionado");

async function cargarAporteSeleccionado() {
    let id_aporte = sessionStorage.getItem("aporteSeleccionado");

    if (!id_aporte) {
        console.log("No hay id_aporte en sessionStorage");
        return null;
    }

    id_aporte = JSON.parse(id_aporte);

    try {
        const response = await fetch(`../php/obtener_aporte.php?id_aporte=${id_aporte}`);
        
        if (!response.ok) {
            throw new Error("Error en la respuesta del servidor");
        }

        const data = await response.json();
        return data; // 🔹 Devuelve directamente el array recibido del PHP

        console.log(data)
    } catch (error) {
        console.error("Error al obtener los datos:", error);
        return null;
    }
}

async function acomodarPagina(){
    const datosAporte = await cargarAporteSeleccionado();

    const nombreArchivo = window.location.pathname.split("/").pop();
    if( (nombreArchivo === "evaluar-horas-trabajo.html") && ((Number(usuario.id_familia) !== Number(datosAporte.horas_semanales.id_familia)) && (usuario.rol !== 'admin')) ){
        window.location.href="../html/acceso-denegado.html"
    }

    document.getElementById("nombre").innerHTML= datosAporte.horas_semanales.nombre + " " + datosAporte.horas_semanales.primer_apellido + " " + datosAporte.horas_semanales.segundo_apellido;
    document.getElementById("fecha").innerHTML=(datosAporte.horas_semanales.fecha_horas).substring(0,10);

    document.getElementById("total-horas").innerHTML=datosAporte.horas_semanales.cant_horas;

    document.getElementById("actividad").innerHTML=datosAporte.horas_semanales.tarea;

    
    // 1️⃣ Convertir la fecha a un objeto Date
    let fecha = new Date(datosAporte.horas_semanales.fecha_horas);

    // 2️⃣ Ignorar día, mes, año y segundos, quedándonos con horas y minutos
    let horaEntrada = new Date();
    horaEntrada.setHours(fecha.getHours(), fecha.getMinutes(), 0, 0); // horas, minutos, segundos=0, ms=0

    // 3️⃣ Calcular hora de salida sumando las horas trabajadas
    let horaSalida = new Date(horaEntrada.getTime()); // copiamos
    horaSalida.setHours(horaSalida.getHours() + datosAporte.horas_semanales.cant_horas);

    // 4️⃣ Mostrar resultados en formato hh:mm
    function formatoHora(date) {
      let h = date.getHours().toString().padStart(2, "0");
      let m = date.getMinutes().toString().padStart(2, "0");
      return `${h}:${m}`;
    }

    document.getElementById("hora-entrada-salida").innerHTML="De "+ formatoHora(horaEntrada) + "hs a " + formatoHora(horaSalida)+"hs";

    console.log("Hora de entrada:", formatoHora(horaEntrada)); // ej: 17:00
    console.log("Hora de salida:", formatoHora(horaSalida));   // ej: 22:00


    const input_conclusion = document.getElementById('conclusion');
    const botones = document.querySelector(".botones");



    if(datosAporte.horas_semanales.estado_horas !== "pendiente"){
        botones.style.display="none";
        const conclusion_final =document.querySelector(".conclusion-final");
        const nombreEvaluador = datosAporte.validaciones[0].nombre + " " + datosAporte.validaciones[0].primer_apellido + " " + datosAporte.validaciones[0].segundo_apellido 
        const pNombreEvaluador = document.getElementById("evaluador_p");
        pNombreEvaluador.innerHTML="Admin que evaluo  : "+nombreEvaluador.toUpperCase();
        pNombreEvaluador.style.display="flex";
        const conclusion = document.getElementById("conclusion");
        conclusion.value = datosAporte.validaciones[0].razon_conclusion;

        conclusion.disabled=true;
        switch(datosAporte.horas_semanales.estado_horas){
            case "aprobado":
            console.log("aprobadonson")
            conclusion_final.innerHTML="Esta solicitud fue Aprobada";
            conclusion_final.classList.add('aceptar');
            conclusion_final.style.display="flex";
            break;
            case "rechazado":
            conclusion_final.innerHTML="Esta solicitud fue Rechazada";
            conclusion_final.classList.add('rechazar');
            conclusion_final.style.display="flex";
            break;
        }
    }else{
        if(((usuario.rol !== 'admin') && (usuario.rol !== 'titular')) || ((Number(usuario.id_familia) === Number(datosAporte.horas_semanales.id_familia)) && (datosAporte.horas_semanales.estado_horas === "pendiente"))){
            window.location.href="../html/acceso-denegado.html"
        }
    }


}

acomodarPagina();

function validacionDatos(){
    var datosValidos=true;
    const inputConclusion = document.getElementById('conclusion');
    if(!inputConclusion.checkValidity()){
        datosValidos=false;            
        if (!inputConclusion.parentNode.classList.contains("invalido")){
            inputConclusion.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una conclusion valida.</p>');
            inputConclusion.parentNode.classList.add("invalido");
        }
    }else{
        if (inputConclusion.parentNode.querySelector("p.mensaje-error") !== null){
            inputConclusion.parentNode.classList.remove("invalido");
            inputConclusion.parentNode.querySelector("p.mensaje-error").remove();
        }
    }
    return datosValidos;
}

// Función que se llama al click
async function evaluarAporteHoras(conclusion, razon_conclusion) {
    if (validacionDatos()) {
        if(await confirmarAccion('¿Enviar?')){
            try {
                const formData = new FormData();
                formData.append("id_aporte", id_aporte);
                formData.append("id_admin", usuario.cedula);
                formData.append("conclusion", conclusion);
                formData.append("razon_conclusion", razon_conclusion);

                const response = await fetch("../php/evaluar_aporte.php", {
                    method: "POST",
                    body: formData
                });

                if (response.ok) {
                    location.reload();
                } else {
                    alert("Error al enviar la evaluación");
                }

            } catch (error) {
                console.error("Error en evaluarAporteHoras:", error);
                alert("No se pudo enviar la evaluación.");
            }
    
        }
    }
}
