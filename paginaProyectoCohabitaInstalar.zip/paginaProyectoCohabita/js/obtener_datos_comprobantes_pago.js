if((usuario.rol !== 'admin') && (usuario.rol !== 'titular')){
    window.location.href="../html/acceso-denegado.html"
}

console.log(usuario , "comprobante")

async function cargarAporteSeleccionado() {
    let id = sessionStorage.getItem("comprobante");

    if (!id) {
        console.error("No hay id en sessionStorage");
        return null;
    }

    id = JSON.parse(id);

    try {
        // --- Crear FormData con el id_comprobante ---
        const formData = new FormData();
        formData.append("id_comprobante", id);

        const response = await fetch("../php/obtener_datos_comprobante_pago.php", {
            method: "POST",
            body: formData
        });

        if (!response.ok) {
            throw new Error("Error en la respuesta del servidor");
        }

        const data = await response.json();

        console.log("Datos recibidos del comprobante:", data);
        return data; // Devuelve directamente el objeto recibido del PHP
    } catch (error) {
        console.error("Error al obtener los datos:", error);
        return null;
    }
}

async function acomodarPagina(){
    const datosComprobante = await cargarAporteSeleccionado();
    if(((usuario.rol !== 'admin') && (usuario.rol !== 'titular')) || ((Number(usuario.id_familia) === Number(datosComprobante.adulto.id_familia)) && (datosComprobante.comprobante.estado === "pendiente"))){
        window.location.href="../html/acceso-denegado.html"
    }

    
    console.log("datos aporte con sissda" , datosComprobante)

    document.getElementById("nombre-titular").innerHTML= datosComprobante.adulto.nombre + " " + datosComprobante.adulto.primer_apellido + " " + datosComprobante.adulto.segundo_apellido;
    // document.getElementById("numero-factura").innerHTML= ;

    document.getElementById("monto-pago").innerHTML=datosComprobante.comprobante.monto;

    document.getElementById("fecha-pago").innerHTML=datosComprobante.comprobante.fecha;

    document.getElementById("cedula-emisor").innerHTML=datosComprobante.comprobante.cedula_emisor;

    document.getElementById("archivo").href=`../archivos/comprobantes de pago/${datosComprobante.comprobante.archivo_comprobante}`;
    document.getElementById("archivo").download= datosComprobante.comprobante.archivo_comprobante;
    document.getElementById("archivo-parrafo").innerHTML=  datosComprobante.comprobante.archivo_comprobante;


    const input_conclusion = document.getElementById('conclusion');
    const botones = document.querySelector(".botones");


    if(datosComprobante.comprobante.estado !== "pendiente"){
        botones.style.display="none";
        const conclusion_final =document.querySelector(".conclusion-final");
        const nombreEvaluador = datosComprobante.evaluaciones[0].nombre + " " + datosComprobante.evaluaciones[0].primer_apellido + " " + datosComprobante.evaluaciones[0].segundo_apellido 
        console.log(nombreEvaluador)
        const pNombreEvaluador = document.getElementById("evaluador_p");
        pNombreEvaluador.innerHTML="Admin que evaluo  : "+nombreEvaluador.toUpperCase();
        pNombreEvaluador.style.display="flex";
        const conclusion = document.getElementById("conclusion");
        conclusion.value = datosComprobante.evaluaciones[0].razon_conclusion;

        
        
        conclusion.disabled=true;
        switch(datosComprobante.comprobante.estado){
            case "aprobado":
            console.log("aprobadonson")
            conclusion_final.innerHTML="Esta solicitud fue Aprobada";
            conclusion_final.classList.add('aceptar');
            conclusion_final.style.display="flex";
            break;
            case "rechazado":
            conclusion_final.innerHTML="Esta solicitud fue Rechazada";
            conclusion_final.classList.add('rechazar');
            conclusion_final.style.display="flex";
            break;
        }
    }

    if(((datosComprobante.comprobante.estado !== "pendiente") || (datosComprobante.comprobante.estado !== "en_votacion")) && usuario.rol !== 'admin'){
        window.location.href="../html/acceso-denegado.html"
    }


}

acomodarPagina();

function validacionDatos(){
    var datosValidos=true;
    const inputConclusion = document.getElementById('conclusion');
    if(!inputConclusion.checkValidity()){
        datosValidos=false;            
        if (!inputConclusion.parentNode.classList.contains("invalido")){
            inputConclusion.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una conclusion valida.</p>');
            inputConclusion.parentNode.classList.add("invalido");
        }
    }else{
        if (inputConclusion.parentNode.querySelector("p.mensaje-error") !== null){
            inputConclusion.parentNode.classList.remove("invalido");
            inputConclusion.parentNode.querySelector("p.mensaje-error").remove();
        }
    }
    return datosValidos;
}

// Función que se llama al click
async function evaluarAporteHoras(conclusion, razon_conclusion) {
    if (validacionDatos()) {
        console.log("terrible down")
        if(await confirmarAccion('¿Enviar?')){
            const datosComprobante = await cargarAporteSeleccionado();
    
        try {
            const formData = new FormData();
            formData.append("id_comprobante", datosComprobante.comprobante.id_comprobante);
            formData.append("id_admin", usuario.cedula);
            formData.append("conclusion", conclusion);
            formData.append("razon_conclusion", razon_conclusion);

            const response = await fetch("../php/evaluar_comprobante_pago.php", {
                method: "POST",
                body: formData
            });

            if (response.ok) {
                location.reload();
            } else {
                alert("Error al enviar la evaluación");
            }

        } catch (error) {
            console.error("Error en evaluarAporteHoras:", error);
            alert("No se pudo enviar la evaluación.");
        }
    }
    }
}
