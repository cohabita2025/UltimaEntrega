console.log(" entra al .js")


if ((usuario.rol !== 'admin') && (usuario.rol !== 'titular')) {
    window.location.href = "../html/acceso-denegado.html"
}

const fechaActual = new Date().toISOString().split('T')[0];
function validarDatos() {
    var datosValidos = true;
    const mes = document.getElementById("mes");
    const monto = document.getElementById("monto");
    const cedula_pago = document.getElementById("cedula-pago");
    const comprobante = document.getElementById("comprobante-archivo");

    if (!mes.checkValidity()) {
        datosValidos = false;
        if (!mes.parentNode.parentNode.parentNode.classList.contains("invalido")) {
            mes.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un mes valido.</p>');
            mes.parentNode.parentNode.parentNode.classList.add("invalido");
        }
    } else {
        console.log("eso")
        if (mes.parentNode.parentNode.parentNode.querySelector("p.mensaje-error") !== null) {
            console.log("josesu")
            mes.parentNode.parentNode.parentNode.classList.remove("invalido");
            mes.parentNode.parentNode.parentNode.querySelector("p.mensaje-error").remove();
        }
    }

    if (!comprobante.checkValidity()) {
        datosValidos = false;
        if (!comprobante.parentNode.classList.contains("invalido-archivo")) {
            comprobante.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un comprobante valido.</p>');
            comprobante.parentNode.classList.add("invalido-archivo");
        }

    } else {
        if (comprobante.parentNode.querySelector("p.mensaje-error") !== null) {
            comprobante.parentNode.classList.remove("invalido-archivo");
            comprobante.parentNode.querySelector("p.mensaje-error").remove();
        }
    }

    if (!monto.checkValidity()) {
        datosValidos = false;
        if (!monto.parentNode.classList.contains("invalido")) {
            monto.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un monto valido.</p>');
            monto.parentNode.classList.add("invalido");
        }
    } else {
        console.log("eso")
        if (monto.parentNode.querySelector("p.mensaje-error") !== null) {
            console.log("josesu")
            monto.parentNode.classList.remove("invalido");
            monto.parentNode.querySelector("p.mensaje-error").remove();
        }
    }

    if (!cedula_pago.checkValidity()) {
        datosValidos = false;
        if (!cedula_pago.parentNode.classList.contains("invalido")) {
            cedula_pago.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una cedula valido.</p>');
            cedula_pago.parentNode.classList.add("invalido");
        }
    } else {
        console.log("eso")
        if (cedula_pago.parentNode.querySelector("p.mensaje-error") !== null) {
            console.log("josesu")
            cedula_pago.parentNode.classList.remove("invalido");
            cedula_pago.parentNode.querySelector("p.mensaje-error").remove();
        }
    }


    return datosValidos
}

async function enviarComprobante() {
    if (validarDatos()) {
        if (await confirmarAccion('¿Enviar?')) {
            try {
                const formData = new FormData();

                // --- Datos comunes ---
                formData.append("monto", document.getElementById("monto").value);

                const dia = document.getElementById("dia").value;
                const mes = document.getElementById("mes").value;
                const anio = document.getElementById("anio").value;
                const fecha = anio + "-" + mes + "-" + dia;

                formData.append("fecha", fecha);

                formData.append("fecha_envio_comprobante", fechaActual);

                formData.append("cedula_emisor", document.getElementById("cedula-pago").value);

                formData.append("cedula_titular", usuario.cedula);


                // --- Archivo ---
                const archivo = document.getElementById("comprobante-archivo").files[0];
                if (!archivo) {
                    alert("Debe seleccionar un archivo");
                    return;
                }
                formData.append("archivo_comprobante", archivo);

                // --- Enviar con fetch ---
                const response = await fetch("../php/agregar_comprobantes_pago.php", {
                    method: "POST",
                    body: formData
                });
                const data = await response.json();
                if (data.error) {
                    alert("❌ Error: " + data.error);
                } else {
                    redirigir("pagina-principal.html", "agregar-comprobante-pago.html", "Volver al inicio", "Enviar otro comprobante")
                }

            } catch (error) {
                console.error("Error en enviarComprobante:", error);

            }
        }
    }
}
