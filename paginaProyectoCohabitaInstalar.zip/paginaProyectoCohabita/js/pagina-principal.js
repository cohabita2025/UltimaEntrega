const usuario = obtenerFamiliarGuardado();

if (usuario == null) {
    console.log("Usuario no existe");
    window.location.href = "../html/acceso-denegado.html";
}



/*
                <img src="" alt="" id="foto-usuario">
                <p id="nombre-usuario">AGUSTIN VANNET ANTUNEZ    </p>
                <img src="../archivos/imagenes/flechita.svg" alt="">

*/

/*
switch (usuario.rol) {
    case "titular":
        mostrarItems("li.titular");
        break;
    case "admin":
        mostrarItems("li.admin");
        break;
}
*/

const usuarioNombreCompleto = (usuario.nombre + " " + usuario.primer_apellido + " " + (usuario.segundo_apellido || ""))
    .toUpperCase();
document.getElementById("nombre-usuario").innerHTML = usuarioNombreCompleto;

document.getElementById("foto-usuario").src = `../archivos/familias/${usuario.id_familia}/${usuario.cedula}/${usuario.foto}`;


async function mostrarDatosHoras() {
    const datosProcesados = await procesarHorasFamilia(usuario.id_familia);
    const horasUsuario = datosProcesados.adultos.find(a => a.cedula === usuario.cedula);
    const horasAportadaEstaSemana = horasUsuario.informacionSemanas[horasUsuario.informacionSemanas.length - 1].horasTotales
    const horasSancion = Number(horasUsuario.informacionSemanas[horasUsuario.informacionSemanas.length - 1].horasSancion);

    const pNumeroVerde = document.getElementById("porcentajeHorasAportadas")
    const pNumeroRojo = document.getElementById("porcentajeHorasQueFaltanAportar")

    const pagoSemanal = (21 + horasSancion)

    const graficaHoras = document.querySelector('.grafica-horas');
    const progreso = horasAportadaEstaSemana / pagoSemanal;

    document.getElementById("aporteSemanalHoras").innerHTML = horasAportadaEstaSemana

    if (progreso <= 1) {
        pNumeroVerde.innerHTML = Math.floor((horasAportadaEstaSemana / pagoSemanal) * 100) + "%"
        pNumeroRojo.innerHTML = Math.floor(100 - ((horasAportadaEstaSemana / pagoSemanal) * 100)) + "%"

        document.getElementById("aporteSemanalHorasFaltante").innerHTML = pagoSemanal - horasAportadaEstaSemana
        const rotacion = `rotate(calc((${horasAportadaEstaSemana} / ${pagoSemanal}) * 360deg - 90deg))`;
        graficaHoras.querySelector(".pieza-movil").style.transform = rotacion;
        graficaHoras.querySelector(".pieza-roja").style.display = "flex";
        if (progreso >= 0.75) {
            graficaHoras.querySelector(".parte_verde.pieza1").classList.add("visible");
        }

        if (progreso >= 0.5) {
            graficaHoras.querySelector(".parte_verde.pieza2").classList.add("visible");
        }

        if (progreso >= 0.25) {
            graficaHoras.querySelector(".pieza-roja").style.display = "none";
            graficaHoras.querySelector(".parte_verde.pieza4").classList.add("visible");
        }

        if (progreso === 0) {
            console.log("s i ent")
            graficaHoras.querySelector(".parte_verde.pieza1").classList.remove("visible");
            graficaHoras.querySelector(".parte_verde.pieza2").classList.remove("visible");
            graficaHoras.querySelector(".parte_verde.pieza3").classList.remove("visible");
            graficaHoras.querySelector(".parte_verde.pieza4").classList.remove("visible");

            graficaHoras.querySelector(".parte_verde.movil").classList.remove("visible");
        }

    } else {
        graficaHoras.querySelector(".fondo").style.backgroundColor = "red";

        graficaHoras.querySelector(".parte_verde.pieza1").classList.add("visible");
        graficaHoras.querySelector(".parte_verde.pieza2").classList.add("visible");
        graficaHoras.querySelector(".parte_verde.pieza3").classList.add("visible");
        graficaHoras.querySelector(".parte_verde.pieza4").classList.add("visible");
    }

}


async function mostrarDatosPagos() {
    const datosProcesadosHoras = await procesarHorasFamilia(usuario.id_familia);
    const datosProcesadosPagos = await procesarPagosFamilia(usuario.id_familia);

    const pNumeroVerde = document.getElementById("porcentajeMontoAportado")
    const pNumeroRojo = document.getElementById("porcentajeMontoQueFaltanAportar")

    const montoPagadoEsteMes = (datosProcesadosPagos.resumenMeses[datosProcesadosPagos.resumenMeses.length - 1].totalPagado)
    console.log(montoPagadoEsteMes)

    const pagoMensual = (datosProcesadosHoras.resumenMeses[datosProcesadosHoras.resumenMeses.length - 1].montoSancion)
    console.log(pagoMensual, montoPagadoEsteMes)

    const graficaHoras = document.querySelector('.grafica-pago');
    const progreso = montoPagadoEsteMes / pagoMensual;

    document.getElementById("aporteMensual").innerHTML = montoPagadoEsteMes

    if (progreso <= 1) {
        pNumeroVerde.innerHTML = Math.floor((montoPagadoEsteMes / pagoMensual) * 100) + "%"
        pNumeroRojo.innerHTML = Math.floor(100 - ((montoPagadoEsteMes / pagoMensual) * 100)) + "%"

        document.getElementById("aporteMensualFaltante").innerHTML = pagoMensual - montoPagadoEsteMes
        const rotacion = `rotate(calc((${montoPagadoEsteMes} / ${pagoMensual}) * 360deg - 90deg))`;
        graficaHoras.querySelector(".pieza-movil").style.transform = rotacion;
        graficaHoras.querySelector(".pieza-roja").style.display = "flex";
        if (progreso >= 0.75) {
            graficaHoras.querySelector(".parte_verde.pieza1").classList.add("visible");
        }

        if (progreso >= 0.5) {
            graficaHoras.querySelector(".parte_verde.pieza2").classList.add("visible");
        }

        if (progreso >= 0.25) {
            graficaHoras.querySelector(".pieza-roja").style.display = "none";
            graficaHoras.querySelector(".parte_verde.pieza4").classList.add("visible");
        }

        if (progreso === 0) {
            console.log("s i ent")
            graficaHoras.querySelector(".parte_verde.pieza1").classList.remove("visible");
            graficaHoras.querySelector(".parte_verde.pieza2").classList.remove("visible");
            graficaHoras.querySelector(".parte_verde.pieza3").classList.remove("visible");
            graficaHoras.querySelector(".parte_verde.pieza4").classList.remove("visible");

            graficaHoras.querySelector(".parte_verde.movil").classList.remove("visible");
        }

    } else {
        graficaHoras.querySelector(".fondo").style.backgroundColor = "red";

        graficaHoras.querySelector(".parte_verde.pieza1").classList.add("visible");
        graficaHoras.querySelector(".parte_verde.pieza2").classList.add("visible");
        graficaHoras.querySelector(".parte_verde.pieza3").classList.add("visible");
        graficaHoras.querySelector(".parte_verde.pieza4").classList.add("visible");
    }

}

async function obtenerAcciones() {
    try {
        // Llamamos al PHP que genera el JSON
        const response = await fetch(`../php/obtener_acciones_familiares.php?id_familia=${usuario.id_familia}`, {
            method: 'GET'
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        // Parseamos el JSON
        const datos = await response.json();

        // Retornamos el arreglo de aportes
        return datos;

    } catch (error) {
        console.error("Error al obtener aportes:", error);
        return []; // Retornamos un arreglo vacío en caso de error
    }
}

async function cargarSolicitudes() {
    soli = await obtenerAcciones(); // Llama al PHP y obtiene los datos

    if (soli.length > 9) {
        listaSolicitudes = dividirListaEnPaginas9(soli); // Divide en páginas

    } else {
        listaSolicitudes = soli;
    }
    // Ahora que los datos están listos, podemos listar la primera página
    listarPaginas(0, listaSolicitudes);
    acomodarControlesLista(dividirListaEnPaginas9(soli));



}

async function listarPagina(num) {
    soli = await obtenerAcciones(); // Llama al PHP y obtiene los datos

    listaSolicitudes = dividirListaEnPaginas9(soli); // Divide en páginas
    listarPaginas(num, listaSolicitudes);
}


function listarPaginas(num, listar) {
    var lista = document.querySelector(".lista-real");

    lista.innerHTML = "";
    if (listar[num][0] !== undefined) {
        listar = listar[num];
    } else {
        listar = listar;
    }
    for (var i = 0; i < listar.length; i++) {
        switch (listar[i].tipoAccion) {
            case "exoneracion de horas":
                switch (listar[i].tipo) {
                    case "evaluacion":
                        lista.innerHTML += `
                            <div class="accion">
                                <div class="fecha-accion">
                                    ${listar[i].fecha}
                                </div>
                                <div class="detalles-accion">
                                    la exoneracion de ${(listar[i].cant_horas / 3) / 7} semanas  de ${listar[i].nombre_familiar} ${listar[i].primer_apellido_familiar} ${listar[i].segundo_apellido_familiar} a sido ${listar[i].conclusion}. 
                                </div>
                            </div>
                        `;
                        break;
                    case "envio":
                        lista.innerHTML += `
                            <div class="accion">
                                <div class="fecha-accion">
                                    ${listar[i].fecha}
                                </div>
                                <div class="detalles-accion">
                                    ${listar[i].nombre} ${listar[i].primer_apellido} ${listar[i].segundo_apellido} ha solicitado una exoneracion de ${(listar[i].cant_horas / 3) / 7} semanas. 
                                </div>
                            </div>
                        `;
                        break;
                }
                break;
            case "sancion":
                switch (listar[i].tipo) {
                    case "evaluacion":
                        break;
                    case "envio":
                        switch (listar[i].tipoSancion) {
                            case "adulto":
                                lista.innerHTML += `
                                    <div class="accion">
                                        <div class="fecha-accion">
                                            ${listar[i].fecha}
                                        </div>
                                        <div class="detalles-accion">
                                            ${listar[i].nombre} ${listar[i].primer_apellido} ${listar[i].segundo_apellido} ha recibido una sancion de ${listar[i].cant_horas} horas. 
                                        </div>
                                    </div>
                                `;
                                break;
                            case "familia":
                                lista.innerHTML += `
                                    <div class="accion">
                                        <div class="fecha-accion">
                                            ${listar[i].fecha}
                                        </div>
                                        <div class="detalles-accion">
                                            Tu familia a recibido una sancion de ${listar[i].monto} USD y  ${listar[i].cant_horas} horas.
                                        </div>
                                    </div>
                                `;
                                break;
                        }
                        break;
                }
                break;
            case "comprobante de pago":
                switch (listar[i].tipo) {
                    case "evaluacion":
                        lista.innerHTML += `
                            <div class="accion">
                                <div class="fecha-accion">
                                    ${listar[i].fecha}
                                </div>
                                <div class="detalles-accion">
                                    el pago de ${listar[i].monto} usd  de ${listar[i].nombre_familiar} ${listar[i].primer_apellido_familiar} ${listar[i].segundo_apellido_familiar} a sido ${listar[i].conclusion}. 
                                </div>
                            </div>
                        `;
                        break;
                    case "envio":
                        lista.innerHTML += `
                            <div class="accion">
                                <div class="fecha-accion">
                                    ${listar[i].fecha}
                                </div>
                                <div class="detalles-accion">
                                    ${listar[i].nombre} ${listar[i].primer_apellido} ${listar[i].segundo_apellido} ha echo un pago de ${listar[i].monto} usd. 
                                </div>
                            </div>
                        `;
                        break;
                }
                break;
            case "aporte de horas":
                switch (listar[i].tipo) {
                    case "evaluacion":
                        lista.innerHTML += `
                            <div class="accion">
                                <div class="fecha-accion">
                                    ${listar[i].fecha}
                                </div>
                                <div class="detalles-accion">
                                    el aporte de ${listar[i].cant_horas} horas  de ${listar[i].nombre_familiar} ${listar[i].primer_apellido_familiar} ${listar[i].segundo_apellido_familiar} a sido ${listar[i].conclusion}. 
                                </div>
                            </div>
                        `;
                        break;
                    case "envio":
                        lista.innerHTML += `
                            <div class="accion">
                                <div class="fecha-accion">
                                    ${listar[i].fecha}
                                </div>
                                <div class="detalles-accion">
                                    ${listar[i].nombre} ${listar[i].primer_apellido} ${listar[i].segundo_apellido} ha hecho un aporte de ${listar[i].cant_horas} horas. 
                                </div>
                            </div>
                        `;
                        break;
                }
                break;
        }
    }
}

if (window.location.pathname.endsWith("pagina-principal.html")) {
    mostrarDatosHoras();
    mostrarDatosPagos();
    cargarSolicitudes();
}




