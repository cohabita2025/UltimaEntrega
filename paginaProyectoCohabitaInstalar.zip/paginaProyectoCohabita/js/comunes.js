function simularClick(id) {
    document.getElementById(id).click();
}

function formatearInput(id) {
    document.getElementById(id).value = "";
}

function sincronizarNombreInput(input) {
    document.getElementById(input + "Parrafo").innerHTML = document.getElementById(input).files[0].name;
}

function sincronizarFotoInput(idInput) {
    const input = document.getElementById(idInput);
    const file = input.files[0];
    const defaultImg = "../archivos/imagenes/personaVacia.svg"; // imagen por defecto

    // Imagen en el bloque de edición (informacion-completa)
    const imgEdicion = input.closest(".foto").querySelector("img");

    // Imagen en el bloque de vista previa (informacion-basica)
    const imgBasica = input.closest(".informacion-completa")
        .previousElementSibling
        .querySelector("img");

    if (file) {
        const url = URL.createObjectURL(file);
        imgEdicion.src = url;
        imgBasica.src = url;
    } else {
        // Si no hay archivo, volver a la imagen por defecto
        imgEdicion.src = defaultImg;
        imgBasica.src = defaultImg;
    }
}

function seleccionOpcion(id, value) {
    const cont = document.getElementById(id);

    if (!cont) {
        console.error(`❌ No se encontró el contenedor con id="${id}"`);
        return;
    }

    if (!cont.getElementsByClassName("select-oculto")[0]) {
        console.error(`❌ No hay ningún elemento con clase "select-oculto" dentro de #${id}`);
        return;
    }




    document.getElementById(id).getElementsByClassName("select-oculto")[0].value = value;
    document.getElementById(id).getElementsByClassName("valorSeleccionado")[0].style.display = 'block';
    document.getElementById(id).getElementsByClassName("valorSeleccionado")[0].innerHTML = document.getElementById(id).querySelector(`option[value="${value}"]`).innerHTML
}

function desplegarFamiliar(familiar) {
    const informacionBasica = document.getElementById(familiar).querySelector(".informacion-basica");
    const informacionCompleta = document.getElementById(familiar).querySelector(".informacion-completa");

    if (informacionBasica.style.display == 'none') {

        const nombre = informacionCompleta.querySelector(".nombre").value;
        const primerApellido = informacionCompleta.querySelector(".primer-apellido").value
        const segundoApellido = informacionCompleta.querySelector(".segundo-apellido").value

        if (nombre != "" && primerApellido != "") {
            informacionBasica.querySelector(".nombre-completo").innerHTML = nombre + " " + primerApellido + " " + segundoApellido
        } else {
            informacionBasica.querySelector(".nombre-completo").innerHTML = "nombre completo familiar"
        }
        informacionBasica.style.display = 'flex';
        informacionCompleta.style.display = 'none';
    } else {
        informacionBasica.style.display = 'none';
        informacionCompleta.style.display = 'flex';
    }

}

function mostrarOcultarContrasenia(idInput) {
    const input = document.getElementById(idInput);
    const ocultarImg = input.parentNode.querySelector(".ocultar-contrasenia");
    const mostrarImg = input.parentNode.querySelector(".mostrar-contrasenia");

    if (input.type == 'password') {
        input.type = 'text';
        mostrarImg.style.display = 'block';
        ocultarImg.style.display = 'none';
    } else {
        input.type = 'password';
        mostrarImg.style.display = 'none';
        ocultarImg.style.display = 'block';
    }

}

function HabilitarDesabilitarBotones(familiar, decision) {
    //comprobante , declaracion , gmail , numero 

    const comprobante = document.getElementById(familiar).querySelector('.input-comprobante-ingresos')
    const declaracion = document.getElementById(familiar).querySelector('.input-declaracion-no-vivienda')
    const gmail = document.getElementById(familiar).querySelector('.input-gmail')
    const numero = document.getElementById(familiar).querySelector('.input-numero-telefonico')

    if (decision === 'desabilitar') {
        comprobante.disabled = true;
        declaracion.disabled = true;
        gmail.disabled = true;
        numero.disabled = true;

        gmail.value = "";
        numero.value = '';

        gmail.parentNode.classList.add("desabilitado");
        numero.parentNode.classList.add("desabilitado");
        declaracion.parentNode.classList.add("desabilitado");
        comprobante.parentNode.classList.add("desabilitado");
    } else {
        comprobante.disabled = false;
        declaracion.disabled = false;
        gmail.disabled = false;
        numero.disabled = false;

        gmail.parentNode.classList.remove("desabilitado");
        numero.parentNode.classList.remove("desabilitado");
        declaracion.parentNode.classList.remove("desabilitado");
        comprobante.parentNode.classList.remove("desabilitado");
    }
}

function compararFechaEdad(idDia, idMes, idAnio, familiar) {
    const dia = parseInt(document.getElementById(idDia).value, 10);
    const mes = parseInt(document.getElementById(idMes).querySelector('select').value, 10) - 1; // JS cuenta 0-11
    const anio = parseInt(document.getElementById(idAnio).value, 10);

    const hoy = new Date();
    const fechaNacimiento = new Date(anio, mes, dia);

    const diferencia = hoy - fechaNacimiento; // hoy - nacimiento
    const edad = Math.floor(diferencia / (1000 * 60 * 60 * 24 * 365.25));


    if (edad < 18) {
        HabilitarDesabilitarBotones(familiar, 'desabilitar');

    } else {
        HabilitarDesabilitarBotones(familiar, 'habilitar');
    }

}

function acomodarAnio(id) {
    const hoy = new Date();
    const anioActual = hoy.getFullYear();

    input = document.getElementById(id);

    const anio = parseInt(input.value, 10)
    if (anio > anioActual) {
        input.value = anioActual;
    }
}

function eliminarFamiliar(familiar) {
    if (document.getElementsByClassName('familiar').length > 1) {
        document.getElementById(familiar).remove();
    }
}

let cantFamiliares = 1;

function agregarFamiliar() {
    cantFamiliares++;

    document.querySelector(".lista-familiares").insertAdjacentHTML('afterbegin', `

        <div class="familiar" id="familiar${cantFamiliares}">
        <div class="informacion-basica">
        <img src="../archivos/imagenes/personaVacia.svg" alt="foto" class="imgFamiliar${cantFamiliares}">
                        <p class="nombre-completo">nombre completo del familiar</p>

                        <button class="eliminar boton-simple-azul" type="button" onclick="eliminarFamiliar('familiar${cantFamiliares}')">
                            Eliminar
                        </button>
                    </div>

                    <div class="informacion-completa">
                        <div class="foto">
                            <img src="../archivos/imagenes/personaVacia.svg" alt="foto" class="imgFamiliar${cantFamiliares}">

                            <div class="input-archivo">
                                <input type="file" class="input-foto" id="fotoFamiliar${cantFamiliares}" onchange="sincronizarNombreInput('fotoFamiliar${cantFamiliares}') ; sincronizarFotoInput('fotoFamiliar${cantFamiliares}')" required>
                                <button type="button" class="falso-input" onclick="simularClick('fotoFamiliar${cantFamiliares}')" >Selecciona la foto del familiar</button>

                                <div class="edicion-archivo">
                                    <p id="fotoFamiliar${cantFamiliares}Parrafo"></p>
                                    <button type="button" class="borrar" onclick="formatearInput('fotoFamiliar${cantFamiliares}') ; sincronizarFotoInput('fotoFamiliar${cantFamiliares}')">
                                        <img src="../archivos/imagenes/SimboloTachar.svg" alt="">
                                    </button>
                                </div>

                            </div>
                        </div>

                        <div class="datos">
                            <div class="input-texto">
                                <input type="text" id="nombre${cantFamiliares}" class="nombre" minlength="2" maxlength="20" placeholder=" " required oninput="this.value = this.value.replace(/[^a-zA-Z]/g,'')">
                                <label for="nombre${cantFamiliares}">Nombre</label>
                            </div>

                            <div class="input-texto">
                                <input type="text" id="primer-apellido${cantFamiliares}" class="primer-apellido" minlength="2" maxlength="20" placeholder=" " required oninput="this.value = this.value.replace(/[^a-zA-Z]/g,'')">
                                <label for="primer-apellido${cantFamiliares}">Primer apellido</label>
                            </div>

                            <div class="input-texto">
                                <input type="text" id="segundo-apellido${cantFamiliares}" class="segundo-apellido" minlength="2" maxlength="20" placeholder=" " oninput="this.value = this.value.replace(/[^a-zA-Z]/g,'')">
                                <label for="segundo-apellido${cantFamiliares}">Segundo apellido</label>
                            </div>

                            <div class="input-texto">
                                <input type="text" class="cedula" id="cedula${cantFamiliares}" placeholder=" "  minlength="8" maxlength="8" required oninput="this.value = this.value.replace(/\\D/g,'')">
                                <label for="cedula${cantFamiliares}">Cedula</label>
                            </div>

                            <div class="input-fecha">
                                <p class="tipo-fecha">Fecha de nacimiento</p>
                                <div class="inputs-fecha">
                                    <input type="text" class="input-dia" name="" id="dia${cantFamiliares}" value="31" min="1" maxlength="2" minlength="1" required oninput="if(this.value===''){this.value='1'} ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}' , 'familiar${cantFamiliares}') ; this.value = this.value.replace(/\D/g,'') ; if( parseInt(this.value , 10) > 31) this.value = 31   ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')"> 
                                    <p>de</p>

                                    <div class="desplegable" tabindex="0" id="mes${cantFamiliares}">
                                        <select class="select-oculto select-mes" required >

                                            <option value="">titulo</option>
                                            <option value="1" >Enero</option>
                                            <option value="2">Febrero</option> 
                                            <option value="3">Marzo</option>
                                            <option value="4">Abril</option> 
                                            <option value="5">Mayo</option>
                                            <option value="6">Junio</option> 
                                            <option value="7">Julio</option>
                                            <option value="8">Agosto</option> 
                                            <option value="9">Septiembre</option>
                                            <option value="10">Octubre</option> 
                                            <option value="11">Noviembre</option>
                                            <option value="12">Diciembre</option> 

                                        </select>
                                        <p class="tipoDesplegable">Mes</p>
                                        <p class="valorSeleccionado"></p>
                                        <ul class="opciones">
                                            <li class="opcion" data-value="1" onclick="seleccionOpcion('mes${cantFamiliares}' , 1) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Enero</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="2" onclick="seleccionOpcion('mes${cantFamiliares}' , 2) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Febrero</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="3" onclick="seleccionOpcion('mes${cantFamiliares}' , 3) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Marzo</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="4" onclick="seleccionOpcion('mes${cantFamiliares}' , 4) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Abril</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="5" onclick="seleccionOpcion('mes${cantFamiliares}' , 5) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Mayo</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="6" onclick="seleccionOpcion('mes${cantFamiliares}' , 6) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Junio</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="7" onclick="seleccionOpcion('mes${cantFamiliares}' , 7) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Julio</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="8" onclick="seleccionOpcion('mes${cantFamiliares}' , 8) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Agosto</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="9" onclick="seleccionOpcion('mes${cantFamiliares}' , 9) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Septiembre</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="10" onclick="seleccionOpcion('mes${cantFamiliares}' , 10) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Octubre</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="11" onclick="seleccionOpcion('mes${cantFamiliares}' , 11) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Noviembre</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="12" onclick="seleccionOpcion('mes${cantFamiliares}' , 12) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Diciembre</li>
                                        </ul>
                                    </div>
                                    <p>del</p>
                                    <input type="text" class="input-anio" id="anio${cantFamiliares}" value="2000" minlength="4" maxlength="4" oninput="acomodarAnio('anio${cantFamiliares}') ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}') ; if(this.value===''){this.value='0000'}   ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')" required oninput="this.value = this.value.replace(/\D/g,'')">
                                </div>
                            </div>

                            <div class="input-texto">
                                <input type="email" id="gmail${cantFamiliares}" placeholder=" " class="input-gmail" maxlength="30" minlength="8" required>
                                <label for="gmail${cantFamiliares}">Gmail</label>
                            </div>

                            <div class="input-texto">
                                <input type="text" class="input-numero-telefonico" id="numero-telefonico${cantFamiliares}" placeholder=" " maxlength="15" minlength="8" required oninput="this.value = this.value.replace(/\D/g,'')">
                                <label for="numero-telefonico${cantFamiliares}">Numero telefonico</label>
                            </div>

                            <div class="desplegable" tabindex="0" id="rol${cantFamiliares}">
                                <select class="select-oculto select-rol-familiar" required>
                                    <option value="">titulo</option>
                                    <option value="1">Conyuge</option>
                                    <option value="2">Hijo/a</option> 

                                    <option value="3">Padre</option>
                                    <option value="4">Madre</option> 

                                    <option value="5">Hermano/a</option>
                                    <option value="6">Abuelo/a</option> 

                                    <option value="7">Nieto/a</option>
                                    <option value="8">Tío/a</option> 

                                    <option value="9">Primo/a</option>
                                    <option value="10">otro</option> 
                                </select>

                                <p class="tipoDesplegable">Rol en la familia</p>
                                <p class="valorSeleccionado"></p>
                                <img src="../archivos/imagenes/flechita.svg" alt="">

                                <ul class="opciones">
                                    <li class="opcion" data-value="1" onclick="seleccionOpcion('rol${cantFamiliares}' , 1)">Cónyuge </li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="2" onclick="seleccionOpcion('rol${cantFamiliares}' , 2)">Hijo/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="3" onclick="seleccionOpcion('rol${cantFamiliares}' , 3)">Padre</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="4" onclick="seleccionOpcion('rol${cantFamiliares}' , 4)">Madre</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="5" onclick="seleccionOpcion('rol${cantFamiliares}' , 5)">Hermano/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="6" onclick="seleccionOpcion('rol${cantFamiliares}' , 6)">Abuelo/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="7" onclick="seleccionOpcion('rol${cantFamiliares}' , 7)">Nieto/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="8" onclick="seleccionOpcion('rol${cantFamiliares}' , 8)">Tío/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="9" onclick="seleccionOpcion('rol${cantFamiliares}' , 9)">Primo/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="10" onclick="seleccionOpcion('rol${cantFamiliares}' ,10)">Otro</li>
                                </ul>
                            </div>


                            <div class="desplegable" tabindex="0" id="genero${cantFamiliares}">
                                <select class="select-oculto select-genero"  required>
                                    <option value="">titulo</option>
                                    <option value="1">Masculino</option>
                                    <option value="2">Femenino</option> 
                                </select>

                                <p class="tipoDesplegable">Genero</p>
                                <p class="valorSeleccionado"></p>
                                <img src="../archivos/imagenes/flechita.svg" alt="">

                                <ul class="opciones">
                                    <li class="opcion" data-value="1" onclick="seleccionOpcion('genero${cantFamiliares}' , 1)">Masculino</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="2" onclick="seleccionOpcion('genero${cantFamiliares}' , 2)">Femenino</li>
                                </ul>
                            </div>



                            <div class="input-archivo">
                                <input type="file" class="input-copia-cedula" id="CopiaCedulaFamiliar${cantFamiliares}" onchange="sincronizarNombreInput('CopiaCedulaFamiliar${cantFamiliares}')" required>
                                <button type="button" class="falso-input" onclick="simularClick('CopiaCedulaFamiliar${cantFamiliares}')" >Selecciona copia de la cedula</button>

                                <div class="edicion-archivo">
                                    <p id="CopiaCedulaFamiliar${cantFamiliares}Parrafo"></p>
                                    <button type="button" class="borrar" onclick="formatearInput('CopiaCedulaFamiliar${cantFamiliares}')">
                                        <img src="../archivos/imagenes/SimboloTachar.svg" alt="">
                                    </button>
                                </div>
                            </div>

                            <div class="input-archivo">
                                <input type="file" class="input-comprobante-ingresos" id="IngresosFamiliar${cantFamiliares}" onchange="sincronizarNombreInput('IngresosFamiliar${cantFamiliares}')" required>
                                <button type="button" class="falso-input" onclick="simularClick('IngresosFamiliar${cantFamiliares}')" >Selecciona Comprobante de ingresos</button>
                                <div class="edicion-archivo">
                                    <p id="IngresosFamiliar${cantFamiliares}Parrafo"></p>
                                    <button type="button" class="borrar" onclick="formatearInput('IngresosFamiliar${cantFamiliares}')">
                                        <img src="../archivos/imagenes/SimboloTachar.svg" alt="">
                                    </button>
                                </div>
                            </div>

                            <div class="input-archivo">
                                <input type="file" class="input-declaracion-no-vivienda" id="DeclaracionFamiliar${cantFamiliares}" onchange="sincronizarNombreInput('DeclaracionFamiliar${cantFamiliares}')" required>
                                <button type="button" class="falso-input" onclick="simularClick('DeclaracionFamiliar${cantFamiliares}')" >Selecciona la declaracion no vivienda</button>

                                <div class="edicion-archivo">
                                    <p id="DeclaracionFamiliar${cantFamiliares}Parrafo"></p>
                                    <button type="button" class="borrar" onclick="formatearInput('DeclaracionFamiliar${cantFamiliares}')">
                                        <img src="../archivos/imagenes/SimboloTachar.svg" alt="">
                                    </button>
                                </div>
                            </div>

                        </div>
                    </div>
                    
                    
                    
                    
                    <button type="button" class="desplegar-contraer-familiar boton-simple-azul" onclick="desplegarFamiliar('familiar${cantFamiliares}')">Desplegar Familiar</button>
                </div>
`);

}

async function obtenerFamiliar(familiarCedula) {
    try {
        const formData = new FormData();
        formData.append("cedula", familiarCedula);

        const resp = await fetch("../php/obtener_familiar.php", {
            method: "POST",
            body: formData
        });

        const data = await resp.json();
        return data;

    } catch (err) {
        console.error("Error de conexión o JSON:", err);
        return null;
    }
}

async function guardarFamiliarYSiguiente(cedula, urlDestino) {
    try {
        const familiar = await obtenerFamiliar(cedula);
        if (familiar) {
            sessionStorage.setItem('familiar', JSON.stringify(familiar));
            // redirigir solo después de guardar
            window.location.href = urlDestino;
        } else {
            console.error("No se encontró familiar adulto.");
        }
    } catch (err) {
        console.error("Error al obtener familiar:", err);
    }
}

function mostrarItems(selector) {
    const lista = document.querySelectorAll(selector);
    for (const elemento of lista) {
        elemento.style.display = "flex";
    }
}

// Devuelve el familiar guardado en sessionStorage como objeto
function obtenerFamiliarGuardado() {
    const familiarStr = sessionStorage.getItem('familiar');
    if (!familiarStr) return null; // si no existe, devuelve null
    try {
        return JSON.parse(familiarStr);
    } catch (e) {
        console.error("Error al parsear familiar guardado:", e);
        return null;
    }
}

function cerrarSesion() {
    sessionStorage.removeItem('familiar');
    window.location.href = "../html/index.html";
}

function mostrarPersona(persona) {
    const personaString = encodeURIComponent(JSON.stringify(persona));
    window.open("../html/perfil-persona.html?persona=" + personaString, "_blank");
    console.log("Objeto enviado:", persona);
}

const extensionesImagen = ["jpg", "jpeg", "png", "gif", "webp", "svg", "avif"];

function validarImagenInput(id) {
    const input = document.getElementById(id);
    const file = input.files[0]; // siempre hay un archivo
    const extension = file.name.split('.').pop().toLowerCase();

    if (!extensionesImagen.includes(extension)) {
        // borra el archivo y formatea
        formatearInput(id);        // tu función para limpiar/mostrar error
        sincronizarFotoInput(id);  // tu función de sincronización

        if (!input.checkValidity()) {
            datosValidos = false;
            if (!input.parentNode.classList.contains("invalido-archivo")) {
                input.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una foto valida.</p>');
                input.parentNode.classList.add("invalido-archivo");
            }
        } else {
            if (input.parentNode.querySelector("p.mensaje-error") !== null) {
                input.parentNode.classList.remove("invalido-archivo");
                input.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        return false;
    }

    return true; // todo OK
}

function arreglarFecha(inputMes, inputDia, inputAnio) {
    mes = Number(document.getElementById(inputMes).querySelector('.select-mes').value)
    const diaInput = document.getElementById(inputDia);
    const anio = Number(document.getElementById(inputAnio).value);
    console.log(mes, diaInput.value, anio)

    if ([4, 6, 9, 11].includes(mes)) {
        console.log("olas")
        if (diaInput.value > 30) {
            diaInput.value = 30;
        }
    } else if (mes === 2) {
        console.log("ola")
        if (diaInput.value > 28) {
            console.log("ola")
            if ((anio % 4 === 0) && (anio % 100 !== 0 || anio % 400 === 0)) {
                console.log((anio % 4 === 0) && (anio % 100 !== 0 || anio % 400 === 0))
                diaInput.value = 29;
                console.log("olas")
            } else {
                diaInput.value = 28;
                console.log("fuap")
            }
        }
    }
}

function confirmarAccion(mensaje) {
    return new Promise((resolve) => {
        const div = document.createElement('div');
        div.className = 'confirmacionAccion';
        div.innerHTML = `
            <div class="confirmacionBotones">
                <p>${mensaje}</p>
                <div class="botones">
                    <button id="confirmar">Confirmar</button>
                    <button id="cancelar">Cancelar</button>
                </div>
            </div>
        `;
        document.body.appendChild(div);

        div.querySelector('#confirmar').addEventListener('click', () => {
            resolve(true);
            div.remove();
        });
        div.querySelector('#cancelar').addEventListener('click', () => {
            resolve(false);
            div.remove();
        });
    });
}

function comprobarPermisos() {
    if (!usuario) {
        console.log("usuario no registrado")
    }
}

function redirigir(direccion1, direccion2, mensaje1, mensaje2) {
    document.querySelector("body").insertAdjacentHTML('afterbegin', `
        <div class="confirmacionAccion redirigir">
        <div class="confirmacionBotones">
            <p>Enviado correctamente</p>
            <div class="botones">
                <a href="../html/${direccion1}" id="confirmar" class="boton-naranja">${mensaje1}</a>
                <a href="../html/${direccion2}" id="cancelar" class="boton-naranja">${mensaje2}</a>    
            </div>
        </div>
    </div>
    `);

}

const meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
const dias = ["Lunes", "Martes", "Miercoles", "Jueves", "Miernes", "Sabado", "Domingo"]

function pasarFechaNumeroTexto(fecha) {
    return dias[fecha.getDay()] + " " + fecha.getDate() + " de " + meses[fecha.getMonth()] + " del " + fecha.getFullYear();
}

async function listarArchivos(rutaCarpeta) {
    const response = await fetch("../php/listar_archivos.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "ruta=" + encodeURIComponent(rutaCarpeta)
    });

    if (!response.ok) {
        const txt = await response.text();
        console.error("❌ Error:", txt);
        return [];
    }

    const archivos = await response.json();
    console.log("📂 Archivos encontrados:", archivos);
    return archivos;
}

async function descargarVariosArchivos(direccion) {
    const archivos = await listarArchivos(direccion);

    for (const actual of archivos) {
        console.log(actual);

        const descarga = document.createElement("a");
        descarga.style.display = "none";
        descarga.href = direccion + "/" + actual;
        console.log(" archivo no se nose ", String(descarga.href))
        descarga.download = actual;

        document.body.appendChild(descarga);
        descarga.click();
        document.body.removeChild(descarga);
    }
}

function diferenciaFechas(fecha1, fecha2, tipoCalculo) {
    // Asegurarnos de que sean objetos Date
    const f1 = new Date(fecha1);
    const f2 = new Date(fecha2);

    // Diferencia en milisegundos → días
    const diferenciaDias = (f1 - f2) / (1000 * 60 * 60 * 24);

    switch (tipoCalculo.toLowerCase()) {
        case "restar":
            return diferenciaDias; // fecha1 - fecha2 en días
        case "sumar":
            return Math.abs(diferenciaDias); // suma en días (valor absoluto)
        case "multiplicar":
            return diferenciaDias * diferenciaDias;
        case "dividir":
            return diferenciaDias !== 0 ? 1 / diferenciaDias : null;
        default:
            throw new Error("Tipo de cálculo no válido (usar: sumar, restar, multiplicar, dividir)");
    }
}


async function obtenerFechaServidor() {
    try {
        const respuesta = await fetch('../php/fecha.php');
        if (!respuesta.ok) throw new Error('Error en la solicitud al servidor');

        const data = await respuesta.json();
        const [year, month, day] = data.hoy.split('-').map(Number);

        // ⚠️ Aquí construimos una fecha local (no UTC)
        return new Date(year, month - 1, day);
    } catch (error) {
        console.error('No se pudo obtener la fecha del servidor:', error);
        return null;
    }
}


// 🌍 Variable global accesible desde cualquier función
let fechaServidorGlobal = null;

// Función para obtener y guardar la fecha del servidor
async function inicializarFechaServidor() {
    fechaServidorGlobal = await obtenerFechaServidor();
    console.log("📅 Fecha del servidor guardada:", fechaServidorGlobal);
}



function formatearFecha(fecha) {
    const f = new Date(fecha);
    const año = f.getFullYear();
    const mes = String(f.getMonth() + 1).padStart(2, '0'); // +1 porque enero es 0
    const dia = String(f.getDate()).padStart(2, '0');
    return `${año}-${mes}-${dia}`;
}


function fechaMinima(dia, mes, anio, fechaMin) {
    console.log("fecha minima")

    const diaInput = document.getElementById(dia);
    const mesInput = document.getElementById(mes);
    const anioInput = document.getElementById(anio);

    const fechaMinima = new Date(fechaMin)


    const fechaActual = new Date(anioInput.value + "-" + mesInput.value + "-" + diaInput.value)

    if ((fechaMinima.getTime() > fechaActual.getTime()) || mesInput.value === "") {
        seleccionOpcion('mes', fechaMinima.getMonth() + 1)
        diaInput.value = fechaMinima.getDate()
        mesInput.value = fechaMinima.getMonth() + 1
        anioInput.value = fechaMinima.getFullYear()
    }

}

async function fechaMaxima(dia, mes, anio, fechaMax) {
    console.log("fecha maxima")

    const diaInput = document.getElementById(dia);
    const mesInput = document.getElementById(mes);
    const anioInput = document.getElementById(anio);

    const fechaMaxima = new Date(fechaMax)

    const fechaActual = new Date(anioInput.value + "-" + mesInput.value + "-" + diaInput.value)

    if ((fechaMaxima.getTime() < fechaActual.getTime()) || mesInput.value === "") {
        seleccionOpcion('mes', fechaMaxima.getMonth() + 1)
        diaInput.value = fechaMaxima.getDate()
        mesInput.value = fechaMaxima.getMonth() + 1
        anioInput.value = fechaMaxima.getFullYear()
    }
}

async function obtenerProximoDia(dia) {
    const fecha = await obtenerFechaServidor();
    const diff = (dia - fecha.getDay() + 7) % 7 || 7;
    fecha.setDate(fecha.getDate() + diff);
    return formatearFecha(fecha);
}

function calcularSemanas(dia1, dia2) {
    const fecha1 = new Date(dia1)
    const fecha2 = new Date(dia2)

    const miliSegundos = fecha2 - fecha1;

    const dias = miliSegundos / (1000 * 60 * 60 * 24);
    const semanas = (dias + 1) / 7;
    return semanas;
}

async function obtenerHorasFamilia(idFamilia) {
    try {
        const response = await fetch(`../php/obtener_horas_familia.php?id_familia=${idFamilia}`);
        if (!response.ok) throw new Error("Error al obtener los datos");

        const data = await response.json();
        return data; // Devuelve el JSON completo
    } catch (error) {
        console.error("Ocurrió un error:", error);
        return null;
    }
}

async function obtenerPagosFamilia(idFamilia) {
    try {
        const response = await fetch(`../php/obtener_pagos_familia.php?id_familia=${idFamilia}`);
        if (!response.ok) throw new Error("Error al obtener los datos");

        const data = await response.json();
        return data; // Devuelve el JSON completo
    } catch (error) {
        console.error("Ocurrió un error:", error);
        return null;
    }
}

async function obtenerSancionesFamilia(idFamilia) {
    try {
        const response = await fetch(`../php/obtener_sanciones_familiares.php?id_familia=${idFamilia}`);
        if (!response.ok) throw new Error("Error al obtener los datos");

        const data = await response.json();
        return data; // Devuelve el JSON completo
    } catch (error) {
        console.error("Ocurrió un error:", error);
        return null;
    }
}

async function obtenerSancionesFamiliaActivas(idFamilia) {
    try {
        const response = await fetch(`../php/obtener_sanciones_activas.php?id_familia=${idFamilia}`);
        if (!response.ok) throw new Error("Error al obtener los datos");

        const data = await response.json();
        return data; // Devuelve el JSON completo
    } catch (error) {
        console.error("Ocurrió un error:", error);
        return null;
    }
}

async function verificarSancionPagada(idSancion) { // Sanciones pagas lslslslSanciones pagas lslslslSanciones pagas lslslslSanciones pagas lslslslSanciones pagas lslslslSanciones pagas lslslslSanciones pagas lslslslSanciones pagas lslslsl
    try {
        const respuesta = await fetch("../php/sancion_pagada.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: `id=${encodeURIComponent(idSancion)}`
        });

        const data = await respuesta.json();

        if (!data.ok) {
            console.error("Error del servidor:", data.error);
            return null;
        }

        return data;

    } catch (error) {
        console.error("Error en fetch:", error);
        return null;
    }
}


function toLocalISOString(date) {
    // Convertir Date a ISO string local
    const tzOffset = date.getTimezoneOffset() * 60000; // en ms
    const localISO = new Date(date.getTime() - tzOffset).toISOString().slice(0, -1);
    return localISO;
}

async function obtenerMeses(fechaInicial) {
    const hoy = new Date(await obtenerFechaServidor());
    hoy.setHours(0, 0, 0, 0); // Año-mes-día solo

    let fechaActual = new Date(fechaInicial);
    fechaActual.setHours(0, 0, 0, 0);

    const meses = [];

    while (fechaActual.getTime() <= hoy.getTime()) {
        const inicioMes = new Date(fechaActual); // Empieza desde la fecha actual o inicial

        // Último día del mes actual
        const finMes = new Date(inicioMes.getFullYear(), inicioMes.getMonth() + 1, 0);

        // Si el fin del mes supera "hoy", cortamos en hoy
        const finReal = finMes.getTime() > hoy.getTime() ? new Date(hoy) : finMes;
        finReal.setHours(23, 59, 59, 999);

        meses.push({
            inicioMes: toLocalISOString(inicioMes),
            finMes: toLocalISOString(finReal)
        });

        // Avanzar al primer día del mes siguiente
        fechaActual = new Date(inicioMes.getFullYear(), inicioMes.getMonth() + 1, 1);
    }

    return meses;
}

async function obtenerSemanas(fechaInicial) {
    const hoy = new Date(await obtenerFechaServidor());
    hoy.setHours(0, 0, 0, 0); // solo año-mes-día
    let diaActual = new Date(fechaInicial);
    diaActual.setHours(0, 0, 0, 0);

    const semanas = [];

    // ---- Primera semana ----
    let inicioSemana = new Date(diaActual);
    let finSemana = new Date(diaActual);
    finSemana.setDate(finSemana.getDate() + (7 - finSemana.getDay())); // hasta domingo
    if (finSemana.getTime() > hoy.getTime()) finSemana = new Date(hoy);

    // Ajustar fin al último instante del día
    finSemana.setHours(23, 59, 59, 999);

    semanas.push({
        inicioSemana: toLocalISOString(inicioSemana),
        finSemana: toLocalISOString(finSemana)
    });

    // ---- Semanas completas ----
    diaActual = new Date(finSemana);
    diaActual.setDate(diaActual.getDate() + 1); // lunes siguiente
    diaActual.setHours(0, 0, 0, 0);

    while (diaActual.getTime() <= hoy.getTime()) {
        inicioSemana = new Date(diaActual);
        inicioSemana.setHours(0, 0, 0, 0);

        finSemana = new Date(inicioSemana);
        finSemana.setDate(inicioSemana.getDate() + 6);
        if (finSemana.getTime() > hoy.getTime()) finSemana = new Date(hoy);

        // último instante del día para finSemana
        finSemana.setHours(23, 59, 59, 999);

        semanas.push({
            inicioSemana: toLocalISOString(inicioSemana),
            finSemana: toLocalISOString(finSemana)
        });

        diaActual = new Date(finSemana);
        diaActual.setDate(diaActual.getDate() + 1);
        diaActual.setHours(0, 0, 0, 0);
    }

    return semanas;
}

async function obtenerAnios(fechaInicial) {
    const hoy = new Date(await obtenerFechaServidor());
    hoy.setHours(23, 59, 59, 999); // fin del día actual

    const fechaInicio = new Date(fechaInicial);
    fechaInicio.setHours(0, 0, 0, 0);

    const anios = [];
    let anioActual = fechaInicio.getFullYear();

    while (anioActual <= hoy.getFullYear()) {
        let inicioAnio, finAnio;

        if (anioActual === fechaInicio.getFullYear()) {
            // El primer año arranca desde la fecha inicial
            inicioAnio = new Date(fechaInicio);
        } else {
            // Los demás años arrancan el 1 de enero
            inicioAnio = new Date(anioActual, 0, 1, 0, 0, 0, 0);
        }

        if (anioActual === hoy.getFullYear()) {
            // El último año termina hoy
            finAnio = new Date(hoy);
        } else {
            // Los años intermedios terminan el 31 de diciembre
            finAnio = new Date(anioActual, 11, 31, 23, 59, 59, 999);
        }

        anios.push({
            inicioAnio: toLocalISOString(inicioAnio),
            finAnio: toLocalISOString(finAnio)
        });

        anioActual++;
    }

    return anios;
}

function calcularDiasEnRango(inicioSanMS, finSanMS, inicioMesMS, finMesMS) {
    const inicio = Math.max(inicioSanMS, inicioMesMS);
    const fin = Math.min(finSanMS, finMesMS);

    if (fin < inicio) return 0;

    return Math.floor((fin - inicio) / (1000 * 60 * 60 * 24)) + 1;
}


async function procesarHorasFamilia(idFamilia) {
    const horas = await obtenerHorasFamilia(idFamilia);
    const sancionesCompletas = await obtenerSancionesFamilia(idFamilia);
    var datosProcesados = {}

    datosProcesados.DatosSinProcesar = horas;

    var horasTotales = 0;
    var horasTotalesExoneradas = 0;
    var horasTotalesSancion = 0;
    var aportes = [];
    var exoneraciones = [];
    var sanciones = [];
    for (const adulto of horas.adultos) {
        for (const hora of adulto.horas_semanales) {
            horasTotales = horasTotales + hora.cant_horas;
            aportes.push(hora.id_aporte);
        }
        for (const exoneracion of adulto.solicitudes_exoneracion) {
            horasTotalesExoneradas = horasTotalesExoneradas + (calcularSemanas(exoneracion.fecha_inicio, exoneracion.fecha_fin) * 21);
            exoneraciones.push(exoneracion.id);
        }
    }

    for (const sancion of sancionesCompletas.sanciones_adultos) {
        horasTotalesSancion = horasTotalesSancion + Number(sancion.cant_horas);
        sanciones.push(sancion.id)
    }

    for (const sancion of sancionesCompletas.sanciones_familia) {
        horasTotalesSancion = horasTotalesSancion + Number(sancion.cant_horas);
        sanciones.push(sancion.id)
    }

    datosProcesados.horasTotales = horasTotales;
    datosProcesados.horasId = aportes;

    datosProcesados.horasTotalesExoneradas = horasTotalesExoneradas;
    datosProcesados.exoneracionesId = exoneraciones;

    datosProcesados.horasTotalesSancion = horasTotalesSancion;
    datosProcesados.sancionesId = sanciones;

    var sancionesTotalesPagadas = [];

    for (const sancion of datosProcesados.sancionesId) {
        var sancionTest = await verificarSancionPagada(sancion);
        if (sancionTest.pagada) {
            sancionesTotalesPagadas.push(sancionTest)
        }
    }


    datosProcesados.sancionesTotalesPagadas = sancionesTotalesPagadas;

    var adultos = [];
    for (const adulto of horas.adultos) {
        var horasTotalesAdulto = 0;
        var horasTotalesExoneradasAdulto = 0;
        var horasTotalesSancionAdulto = 0;
        adultoActual = {
            cedula: adulto.cedula
        }
        for (const hora of adulto.horas_semanales) {
            horasTotalesAdulto = horasTotalesAdulto + hora.cant_horas;
        }
        for (const exoneracion of adulto.solicitudes_exoneracion) {
            horasTotalesExoneradasAdulto = horasTotalesExoneradasAdulto + (calcularSemanas(exoneracion.fecha_inicio, exoneracion.fecha_fin) * 21);
        }
        for (const sancion of sancionesCompletas.sanciones_adultos) {
            if (Number(sancion.cedula_adulto) === Number(adultoActual.cedula)) {
                horasTotalesSancionAdulto = horasTotalesSancionAdulto + Number(sancion.cant_horas);
            }
        }
        adultoActual.horasTotalesSancion = horasTotalesSancionAdulto;
        adultoActual.horasTotalesAportadas = horasTotalesAdulto;
        adultoActual.horasTotalesExoneradas = horasTotalesExoneradasAdulto;
        adultos.push(adultoActual);
    }

    datosProcesados.adultos = adultos;

    for (const adulto of horas.adultos) {
        var semanas = await obtenerSemanas(datosProcesados.DatosSinProcesar.ultima_evaluacion.fecha)
        for (const semana of semanas) {

            var horasSanciones = 0;
            var sanciones = []

            for (const sancion of sancionesCompletas.sanciones_adultos) {
                if (sancion.cedula_adulto === adulto.cedula) {
                    const inicioExoMS = new Date(sancion.fecha_inicio + "T00:00:00").getTime();
                    const finExoMS = new Date(sancion.fecha_limite + "T23:59:59.999").getTime();

                    const inicioSemanaMS = new Date(semana.inicioSemana).getTime();
                    const finSemanaMS = new Date(semana.finSemana).getTime();

                    const semanasSancion = Math.ceil((diferenciaFechas(finExoMS, inicioExoMS, "restar")) / 7);

                    const horasSemana = Math.ceil(sancion.cant_horas / semanasSancion)

                    if (inicioSemanaMS >= inicioExoMS && finSemanaMS <= finExoMS) {
                        horasSanciones = horasSemana + horasSanciones;
                        sanciones.push(sancion.id);
                    }
                }
            }

            for (const sancion of sancionesCompletas.sanciones_familia) {
                const inicioExoMS = new Date(sancion.fecha_inicio + "T00:00:00").getTime();
                const finExoMS = new Date(sancion.fecha_limite + "T23:59:59.999").getTime();

                const inicioSemanaMS = new Date(semana.inicioSemana).getTime();
                const finSemanaMS = new Date(semana.finSemana).getTime();

                const semanasSancion = Math.ceil((diferenciaFechas(finExoMS, inicioExoMS, "restar")) / 7);

                const horasSemana = Math.ceil(Math.ceil(sancion.cant_horas / semanasSancion) / horas.adultos.length) // aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa

                if (inicioSemanaMS >= inicioExoMS && finSemanaMS <= finExoMS) {
                    horasSanciones = horasSemana + horasSanciones;
                    sanciones.push(sancion.id);
                }
            }


            semana.horasSancion = horasSanciones;
            semana.idSancion = sanciones;

            for (const exoneracion of adulto.solicitudes_exoneracion) {
                const inicioExoMS = new Date(exoneracion.fecha_inicio + "T00:00:00").getTime();
                const finExoMS = new Date(exoneracion.fecha_fin + "T23:59:59.999").getTime();

                const inicioSemanaMS = new Date(semana.inicioSemana).getTime();
                const finSemanaMS = new Date(semana.finSemana).getTime();

                if (inicioSemanaMS >= inicioExoMS && finSemanaMS <= finExoMS) {
                    semana.horasExoneradas = 21;
                    semana.idExoneracion = exoneracion.id;
                }
            }

            var horasTotales = 0;
            var aportes = []
            for (const aporte of adulto.horas_semanales) {
                const fechaAporte = new Date(aporte.fecha_horas).getTime();

                const inicioSemanaMS = new Date(semana.inicioSemana).getTime();
                const finSemanaMS = new Date(semana.finSemana).getTime();

                if (fechaAporte >= inicioSemanaMS && fechaAporte <= finSemanaMS) {
                    horasTotales = horasTotales + aporte.cant_horas;
                    aportes.push(
                        {
                            id_aporte: aporte.id_aporte
                        }
                    )
                }
            }
            semana.horasTotales = horasTotales;
            semana.aportes = aportes;
        }

        for (var adultoProcesado of datosProcesados.adultos) {
            if (adultoProcesado.cedula === adulto.cedula) {
                adultoProcesado.informacionSemanas = semanas;

            }
        }
    }

    for (const adulto of horas.adultos) {
        var meses = await obtenerMeses(datosProcesados.DatosSinProcesar.ultima_evaluacion.fecha)
        for (const mes of meses) {
            for (const exoneracion of adulto.solicitudes_exoneracion) {
                const inicioExoMS = new Date(exoneracion.fecha_inicio + "T00:00:00").getTime();
                const finExoMS = new Date(exoneracion.fecha_fin + "T23:59:59.999").getTime();

                const inicioMesMS = new Date(mes.inicioMes).getTime();
                const finMesMS = new Date(mes.finMes).getTime();

                let dias = 0;

                // 1️⃣ Exoneración completa dentro del mes
                if (inicioExoMS >= inicioMesMS && finExoMS <= finMesMS) {
                    dias = Math.round((finExoMS - inicioExoMS) / (1000 * 60 * 60 * 24));
                }

                // 2️⃣ Exoneración empieza antes del mes y termina dentro
                else if (inicioExoMS < inicioMesMS && finExoMS >= inicioMesMS && finExoMS <= finMesMS) {
                    dias = Math.round((finExoMS - inicioMesMS) / (1000 * 60 * 60 * 24));
                }

                // 3️⃣ Exoneración empieza dentro del mes y termina después
                else if (inicioExoMS >= inicioMesMS && inicioExoMS <= finMesMS && finExoMS > finMesMS) {
                    dias = Math.round((finMesMS - inicioExoMS) / (1000 * 60 * 60 * 24));
                }

                // 4️⃣ El mes completo está dentro de la exoneración
                else if (inicioExoMS < inicioMesMS && finExoMS > finMesMS) {
                    dias = Math.round((finMesMS - inicioMesMS) / (1000 * 60 * 60 * 24));
                }

                // Si corresponde, aplicar resultado
                if (dias > 0) {
                    mes.horasExoneradas = (mes.horasExoneradas || 0) + (dias * 3);

                    // Inicializar la lista si no existe
                    if (!mes.exoneraciones) mes.exoneraciones = [];

                    // Agregar ID a la lista
                    mes.exoneraciones.push({
                        id_exoneracion: exoneracion.id
                    });
                }
            }

            var horasTotales = 0;
            var aportes = []
            for (const aporte of adulto.horas_semanales) {
                const fechaAporte = new Date(aporte.fecha_horas).getTime();

                const inicioMesMS = new Date(mes.inicioMes).getTime();
                const finMesMS = new Date(mes.finMes).getTime();

                if (fechaAporte >= inicioMesMS && fechaAporte <= finMesMS) {
                    horasTotales = horasTotales + aporte.cant_horas;
                    aportes.push(
                        {
                            id_aporte: aporte.id_aporte
                        }
                    )
                }
            }
            mes.horasTotales = horasTotales;
            mes.aportes = aportes;


            const msDia = 1000 * 60 * 60 * 24;

            let horasSancionesMes = 0;
            let sancionesMesIDs = [];

            // --- sanciones por adulto ---
            for (const sancion of sancionesCompletas.sanciones_adultos) {
                if (sancion.cedula_adulto !== adulto.cedula) continue;

                const inicioSancionMS = new Date(sancion.fecha_inicio + "T00:00:00").getTime();
                const finSancionMS = new Date(sancion.fecha_limite + "T23:59:59.999").getTime();

                const inicioMesMS = new Date(mes.inicioMes).getTime();
                const finMesMS = new Date(mes.finMes).getTime();

                // Calcular solapamiento
                const inicioSol = Math.max(inicioMesMS, inicioSancionMS);
                const finSol = Math.min(finMesMS, finSancionMS);

                if (finSol < inicioSol) continue; // No hay solapamiento

                // Días que caen dentro del mes
                const dias = Math.ceil((finSol - inicioSol) / msDia);

                // Horas por día (ya que horas por semana dividido 7)
                const semanasSancion = Math.max(1, Math.ceil((finSancionMS - inicioSancionMS) / (7 * msDia)));
                const horasSemana = Math.ceil(Number(sancion.cant_horas) / semanasSancion);
                const horasPorDia = horasSemana / 7;

                const horasMes = horasPorDia * dias;

                horasSancionesMes += horasMes;
                sancionesMesIDs.push({ id_sancion: sancion.id });
            }

            // --- sanciones por familia ---
            for (const sancion of sancionesCompletas.sanciones_familia) {

                const inicioSancionMS = new Date(sancion.fecha_inicio + "T00:00:00").getTime();
                const finSancionMS = new Date(sancion.fecha_limite + "T23:59:59.999").getTime();

                const inicioMesMS = new Date(mes.inicioMes).getTime();
                const finMesMS = new Date(mes.finMes).getTime();

                const inicioSol = Math.max(inicioMesMS, inicioSancionMS);
                const finSol = Math.min(finMesMS, finSancionMS);

                if (finSol < inicioSol) continue;

                const dias = Math.ceil((finSol - inicioSol) / msDia);

                const semanasSancion = Math.max(1, Math.ceil((finSancionMS - inicioSancionMS) / (7 * msDia)));
                const horasSemana = Math.ceil(Number(sancion.cant_horas) / semanasSancion);

                // Distribuida entre adultos
                const numAdultos = Math.max(1, horas.adultos.length);
                const horasPorDia = (horasSemana / 7) / numAdultos;

                const horasMes = horasPorDia * dias;

                horasSancionesMes += horasMes;
                sancionesMesIDs.push({ id_sancion: sancion.id });
            }

            // Guardar en el mes
            mes.horasSancion = (mes.horasSancion || 0) + Math.ceil(horasSancionesMes);
            mes.sanciones = (mes.sanciones || []).concat(sancionesMesIDs);




        }




        for (var adultoProcesado of datosProcesados.adultos) {
            if (adultoProcesado.cedula === adulto.cedula) {
                adultoProcesado.informacionMeses = meses;
            }
        }
    }

    // ===============================
    // 🧩 NUEVO: Cálculo global de semanas y meses de la familia
    // ===============================

    // 🔹 Semanas globales (todas las aportes/exoneraciones de la familia)
    const semanasFamilia = await obtenerSemanas(datosProcesados.DatosSinProcesar.ultima_evaluacion.fecha);

    // ===============================
    // 🟦 AGREGAR SANCIONES A SEMANAS
    // ===============================

    for (const semana of semanasFamilia) {
        semana.horasSancion = 0;
        semana.idsSanciones = [];
        semana.sancionesPagadas = [];

        const inicioSemanaMS = new Date(semana.inicioSemana).getTime();
        const finSemanaMS = new Date(semana.finSemana).getTime();

        // === SANCIONES DE ADULTOS ===
        for (const sancion of sancionesCompletas.sanciones_adultos) {
            const inicioMS = new Date(sancion.fecha_inicio + "T00:00:00").getTime();
            const finMS = new Date(sancion.fecha_limite + "T23:59:59.999").getTime();

            const semanasSancion = Math.ceil(
                (finMS - inicioMS) / (1000 * 60 * 60 * 24 * 7)
            );

            const horasSemana = Math.ceil(sancion.cant_horas / semanasSancion);

            if (inicioSemanaMS >= inicioMS && finSemanaMS <= finMS) {
                semana.horasSancion += horasSemana;
                semana.idsSanciones.push({ id_sancion: sancion.id });

                var sancionTest = await verificarSancionPagada(sancion.id);
                if (sancionTest.pagada) {
                    semana.sancionesPagadas.push(sancionTest)
                }
            }
        }

        // === SANCIONES DE FAMILIA ===
        for (const sancion of sancionesCompletas.sanciones_familia) {
            const inicioMS = new Date(sancion.fecha_inicio + "T00:00:00").getTime();
            const finMS = new Date(sancion.fecha_limite + "T23:59:59.999").getTime();

            const semanasSancion = Math.ceil(
                (finMS - inicioMS) / (1000 * 60 * 60 * 24 * 7)
            );

            const horasSemana = Math.ceil(
                Math.ceil(sancion.cant_horas / semanasSancion) / horas.adultos.length
            );

            if (inicioSemanaMS >= inicioMS && finSemanaMS <= finMS) {
                semana.horasSancion += horasSemana;
                semana.idsSanciones.push({ id_sancion: sancion.id });

                var sancionTest = await verificarSancionPagada(sancion.id);
                if (sancionTest.pagada) {
                    semana.sancionesPagadas.push(sancionTest)
                }
            }
        }
    }


    for (const semana of semanasFamilia) {
        semana.horasAportadas = 0;
        semana.horasExoneradas = 0;
        semana.idsAportes = [];
        semana.idsExoneraciones = [];

        for (const adulto of horas.adultos) {
            // ✅ Aportes
            for (const aporte of adulto.horas_semanales) {
                const fechaAporte = new Date(aporte.fecha_horas).getTime();
                const inicioSemanaMS = new Date(semana.inicioSemana).getTime();
                const finSemanaMS = new Date(semana.finSemana).getTime();

                if (fechaAporte >= inicioSemanaMS && fechaAporte <= finSemanaMS) {
                    semana.horasAportadas += aporte.cant_horas;
                    semana.idsAportes.push(aporte.id_aporte);
                }
            }

            // ✅ Exoneraciones
            for (const exoneracion of adulto.solicitudes_exoneracion) {
                const inicioExoMS = new Date(exoneracion.fecha_inicio + "T00:00:00").getTime();
                const finExoMS = new Date(exoneracion.fecha_fin + "T23:59:59.999").getTime();
                const inicioSemanaMS = new Date(semana.inicioSemana).getTime();
                const finSemanaMS = new Date(semana.finSemana).getTime();

                // Si toda la semana está dentro de la exoneración
                if (inicioSemanaMS >= inicioExoMS && finSemanaMS <= finExoMS) {
                    semana.horasExoneradas += 21;
                    semana.idsExoneraciones.push(exoneracion.id);
                }
            }

            

        }

    }

    // 🔹 Meses globales (todas las aportes/exoneraciones de la familia)
    const mesesFamilia = await obtenerMeses(datosProcesados.DatosSinProcesar.ultima_evaluacion.fecha);

    // ===============================
    // 🟩 AGREGAR SANCIONES A MESES
    // ===============================

    for (const mes of mesesFamilia) {
        mes.horasSancion = 0;
        mes.idsSanciones = [];
        mes.montoSancion = 0;
        mes.sancionesPagadas = [];

        const inicioMesMS = new Date(mes.inicioMes).getTime();
        const finMesMS = new Date(mes.finMes).getTime();

        // === SANCIONES DE ADULTOS ===
        for (const sancion of sancionesCompletas.sanciones_adultos) {
            const inicioMS = new Date(sancion.fecha_inicio + "T00:00:00").getTime();
            const finMS = new Date(sancion.fecha_limite + "T23:59:59.999").getTime();

            const diasMes = calcularDiasEnRango(inicioMS, finMS, inicioMesMS, finMesMS);

            if (diasMes > 0) {
                const totalDiasSancion = Math.ceil((finMS - inicioMS) / (1000 * 60 * 60 * 24));
                const horasPorDia = sancion.cant_horas / totalDiasSancion;
                const horasMes = Math.ceil(horasPorDia * diasMes);

                mes.horasSancion += horasMes;
                mes.idsSanciones.push({ id_sancion: sancion.id });

                var sancionTest = await verificarSancionPagada(sancion.id);
                if (sancionTest.pagada) {
                    mes.sancionesPagadas.push(sancionTest)
                }
            }
        }

        // === SANCIONES DE FAMILIA ===
        for (const sancion of sancionesCompletas.sanciones_familia) {
            const inicioMS = new Date(sancion.fecha_inicio + "T00:00:00").getTime();
            const finMS = new Date(sancion.fecha_limite + "T23:59:59.999").getTime();

            const diasMes = calcularDiasEnRango(inicioMS, finMS, inicioMesMS, finMesMS);

            if (diasMes > 0) {
                const totalDiasSancion = Math.ceil((finMS - inicioMS) / (1000 * 60 * 60 * 24));
                const horasPorDia = sancion.cant_horas / totalDiasSancion;
                const horasMes = Math.ceil((horasPorDia * diasMes) / horas.adultos.length);

                mes.horasSancion += horasMes;
                mes.idsSanciones.push({ id_sancion: sancion.id });
                mes.montoSancion += Number(sancion.monto);

                var sancionTest = await verificarSancionPagada(sancion.id);
                if (sancionTest.pagada) {
                    mes.sancionesPagadas.push(sancionTest)
                }

            }
        }
    }




    for (const mes of mesesFamilia) {
        mes.horasAportadas = 0;
        mes.horasExoneradas = 0;
        mes.idsAportes = [];
        mes.idsExoneraciones = [];

        for (const adulto of horas.adultos) {
            // ✅ Aportes
            for (const aporte of adulto.horas_semanales) {
                const fechaAporte = new Date(aporte.fecha_horas).getTime();
                const inicioMesMS = new Date(mes.inicioMes).getTime();
                const finMesMS = new Date(mes.finMes).getTime();

                if (fechaAporte >= inicioMesMS && fechaAporte <= finMesMS) {
                    mes.horasAportadas += aporte.cant_horas;
                    mes.idsAportes.push(aporte.id_aporte);
                }
            }

            // ✅ Exoneraciones (mismo cálculo de los 4 casos)
            for (const exoneracion of adulto.solicitudes_exoneracion) {
                const inicioExoMS = new Date(exoneracion.fecha_inicio + "T00:00:00").getTime();
                const finExoMS = new Date(exoneracion.fecha_fin + "T23:59:59.999").getTime();
                const inicioMesMS = new Date(mes.inicioMes).getTime();
                const finMesMS = new Date(mes.finMes).getTime();

                let dias = 0;

                if (inicioExoMS >= inicioMesMS && finExoMS <= finMesMS) {
                    dias = Math.floor((finExoMS - inicioExoMS) / (1000 * 60 * 60 * 24)) + 1;
                } else if (inicioExoMS < inicioMesMS && finExoMS >= inicioMesMS && finExoMS <= finMesMS) {
                    dias = Math.floor((finExoMS - inicioMesMS) / (1000 * 60 * 60 * 24)) + 1;
                } else if (inicioExoMS >= inicioMesMS && inicioExoMS <= finMesMS && finExoMS > finMesMS) {
                    dias = Math.floor((finMesMS - inicioExoMS) / (1000 * 60 * 60 * 24)) + 1;
                } else if (inicioExoMS < inicioMesMS && finExoMS > finMesMS) {
                    dias = Math.floor((finMesMS - inicioMesMS) / (1000 * 60 * 60 * 24)) + 1;
                }

                if (dias > 0) {
                    mes.horasExoneradas += (dias * 3);
                    mes.idsExoneraciones.push(exoneracion.id);
                }
            }
        }
    }




    // ✅ Guardamos en datosProcesados
    datosProcesados.resumenSemanas = semanasFamilia;
    datosProcesados.resumenMeses = mesesFamilia;







    console.log(datosProcesados)
    return datosProcesados;
}

async function procesarPagosFamilia(idFamilia) {
    const pagosData = await obtenerPagosFamilia(idFamilia);
    console.log(pagosData)
    if (!pagosData) return null;

    const datosProcesados = {};
    datosProcesados.DatosSinProcesar = pagosData;

    const comprobantes = pagosData.comprobantes_aprobados || [];

    // Totales generales
    datosProcesados.cedulaTitular = pagosData.titular?.cedula || null;
    datosProcesados.idsPagos = comprobantes.map((p, i) => ({ index: i, id: p.id }));
    datosProcesados.totalPagos = comprobantes.reduce((acc, p) => acc + Number(p.monto || 0), 0);

    // --- Determinar fecha base ---
    let fechaBase = null;
    if (pagosData.ultima_evaluacion?.fecha) {
        fechaBase = pagosData.ultima_evaluacion.fecha;
    } else if (comprobantes.length > 0) {
        const fechas = comprobantes.map(p => p.fecha);
        fechaBase = fechas.sort()[0];
    } else {
        fechaBase = new Date().toISOString().split("T")[0];
    }

    // --- Obtener meses y años ---
    console.log(fechaBase)
    const meses = await obtenerMeses(fechaBase);
    console.log(meses)
    const anios = await obtenerAnios(fechaBase);
    console.log(anios)

    // --- Procesar pagos por mes ---
    const resumenMeses = meses.map((m, idx) => ({
        index: idx,
        inicioMes: m.inicioMes,
        finMes: m.finMes,
        cantidadPagos: 0,
        totalPagado: 0,
        idsPagos: []
    }));

    for (let i = 0; i < comprobantes.length; i++) {
        const pago = comprobantes[i];
        const fechaPago = new Date(pago.fecha + "T00:00:00").getTime();
        for (let j = 0; j < resumenMeses.length; j++) {
            const mes = resumenMeses[j];
            const inicio = new Date(mes.inicioMes).getTime();
            const fin = new Date(mes.finMes).getTime();
            if (fechaPago >= inicio && fechaPago <= fin) {
                mes.cantidadPagos++;
                mes.totalPagado += Number(pago.monto || 0);
                mes.idsPagos.push({ index: i, id: pago.id });
                break;
            }
        }
    }

    // --- Procesar pagos por año ---
    const resumenAnios = anios.map((a, idx) => ({
        index: idx,
        inicioAnio: a.inicioAnio,
        finAnio: a.finAnio,
        cantidadPagos: 0,
        totalPagado: 0,
        idsPagos: []
    }));

    for (let i = 0; i < comprobantes.length; i++) {
        const pago = comprobantes[i];
        const fechaPago = new Date(pago.fecha + "T00:00:00").getTime();
        for (let j = 0; j < resumenAnios.length; j++) {
            const anio = resumenAnios[j];
            const inicio = new Date(anio.inicioAnio).getTime();
            const fin = new Date(anio.finAnio).getTime();
            if (fechaPago >= inicio && fechaPago <= fin) {
                anio.cantidadPagos++;
                anio.totalPagado += Number(pago.monto || 0);
                anio.idsPagos.push({ index: i, id: pago.id });
                break;
            }
        }
    }

    // --- Resultado final ---
    datosProcesados.resumenMeses = resumenMeses;
    datosProcesados.resumenAnios = resumenAnios;

    return datosProcesados;
}

