// Obtener los parámetros de la URL actual
const params = new URLSearchParams(window.location.search);

// Leer el valor del parámetro "datos"
const datos = params.get("datos");
const c = params.get("datos");
const id_familia = params.get("datos");

console.log(datos); // Muestra "123"

async function obtenerDatosSolicitud(id_solicitud) {
    console.log(id_solicitud)
    try {
        const formData = new FormData();
        formData.append('id_solicitud', id_solicitud);

        const response = await fetch('../php/obtener_datos_solicitud_registro.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error(`HTTP error: ${response.status}`);

        const datos = await response.json();
        return datos;

    } catch (error) {
        console.error("Error al obtener datos de la solicitud:", error);
        return null;
    }
}



async function acomodarPagina() {

    if (datos === (usuario.id_familia)) {
        document.getElementById("lista-familiares").classList.add("familia-propia")
        document.getElementById("sancionar").remove()
        document.getElementById("expulsar").remove()
        document.getElementById("botones-sancion-expulsar").remove()
    }



    const solicitud = await obtenerDatosSolicitud(datos)
    const familiares = solicitud.personas
    const titular = familiares.find(titular => titular.rol === "titular");

    document.getElementById("nombre-familia").querySelector("p").innerHTML += titular.nombre + " " + titular.primer_apellido + " " + titular.segundo_apellido

    console.log(familiares)

    for (familiar of familiares) {
        document.getElementById("lista-familiares").insertAdjacentHTML('afterbegin', `
            <div class="familiar" onclick="window.location ='../html/lista-familiares-familiar.html?familiar=${familiar.cedula}&titular=${encodeURIComponent(`${titular.nombre} ${titular.primer_apellido} ${titular.segundo_apellido}`)}&id_familia=${id_familia}'">
                <div class="foto-familiar">
                    <img src="../archivos/familias/${familiar.id_familia}/${familiar.cedula}/${familiar.foto}" alt="">
                </div>
                <div class="nombre-familiar">
                    <p>${familiar.nombre} ${familiar.primer_apellido} ${familiar.segundo_apellido}</p>
                </div>
            </div>     
            `);

    }



}

acomodarPagina();

