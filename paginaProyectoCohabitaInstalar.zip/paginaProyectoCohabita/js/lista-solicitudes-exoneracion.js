
var parametros = [];

/*

var parametros = {
  ordenar: {
    orden: "mayor",                     // "mayor" o "menor"
    variableOrden: "titular.nombre"     // propiedad del objeto (puede ser anidada)
  },
  cantidad: {
    cantidad: 3,                        // valor exacto a filtrar
    variableCantidad: "cant_familiares" // propiedad del objeto
  },
  estado: {
    estado: "aprobado",                 // valor a comparar (ej. "aprobado", "rechazado")
    variableEstado: "estado"            // propiedad del objeto
  },
  buscar: {
    buscar: ["ju", "pe"],               // palabras a buscar (no distingue mayúsculas/minúsculas)
    variablesBuscar: [
      "titular.nombre",
      "titular.primer_apellido",
      "titular.segundo_apellido"
    ]                                   // propiedades en las que buscar
  }
};

*/

function actualizarParametros() {
    console.log(" estos son los parametros originales", parametros)
    var parametrosActualizados = {};

    var orden = {
        orden: "",
        variableOrden: ""
    }
    var cantidad = {
        cantidad: "",
        variableCantidad: ""
    }

    var estado = {
        estado: "",
        variableEstado: ""
    }

    var buscar = {
        buscar: [""],
        variablesBuscar: [""]
    }

    switch (document.getElementById('orden').querySelector("select").value) {
        case '1':
            orden.orden = 'menor';
            orden.variableOrden = 'fecha';
            parametrosActualizados.orden = orden;
            break;

        case '2':
            orden.orden = 'mayor';
            orden.variableOrden = 'fecha';
            parametrosActualizados.orden = orden;
            break;

        case '4':
            orden.orden = 'menor';
            orden.variableOrden = 'cant_horas';
            parametrosActualizados.orden = orden;
            break;

        case '3':
            orden.orden = 'mayor';
            orden.variableOrden = 'cant_horas';
            parametrosActualizados.orden = orden;
            break;

    }

    if (document.getElementById("cant-integrantes").value !== "0") {
        cantidad.cantidad = Number(document.getElementById("cant-integrantes").value);
        cantidad.variableCantidad = "cant_horas";
        parametrosActualizados.cantidad = cantidad;
    }

    switch (document.getElementById('estado').querySelector("select").value) {
        case '2':
            estado.estado = 'aprobado';
            estado.variableEstado = 'estado';
            parametrosActualizados.estado = estado;
            break;

        case '3':
            estado.estado = 'rechazado';
            estado.variableEstado = 'estado';
            parametrosActualizados.estado = estado;
            break;

        case '4':
            estado.estado = 'pendiente';
            estado.variableEstado = 'estado';
            parametrosActualizados.estado = estado;
            break;

    }

    if (document.getElementById("buscador").value.length > 0) {
        buscar.buscar = document.getElementById("buscador").value.split(" ");
        buscar.variablesBuscar = ["nombre", "primer_apellido", "segundo_apellido"];
        parametrosActualizados.buscar = buscar;
    }

    parametros = parametrosActualizados;
    console.log(" estos son los parametros actualizados", parametros)
}




// Función para traer todas las solicitudes con su titular
async function obtenerSolicitudes() {
    if (usuario.rol === "admin") {
        try {
            // Llamamos al PHP que genera el JSON
            const response = await fetch('../php/obtener_solicitudes_exoneracion.php', {
                method: 'GET'
            });

            if (!response.ok) {
                throw new Error(`Error HTTP: ${response.status}`);
            }

            // Parseamos el JSON
            const datos = await response.json();

            // Retornamos el arreglo de solicitudes
            return datos;


        } catch (error) {
            console.error("Error al obtener solicitudes:", error);
            return []; // Retornamos un arreglo vacío en caso de error
        }
    } else {
        try {
            // Llamamos al PHP que genera el JSON
            const response = await fetch(`../php/obtener_solicitudes_exoneracion_familia.php?id_familia=${usuario.id_familia}`, {
                method: 'GET'
            });

            if (!response.ok) {
                throw new Error(`Error HTTP: ${response.status}`);
            }

            // Parseamos el JSON
            const datos = await response.json();

            // Retornamos el arreglo de aportes
            return datos;

        } catch (error) {
            console.error("Error al obtener aportes:", error);
            return []; // Retornamos un arreglo vacío en caso de error
        }
    }
}



async function cargarSolicitudes() {
    aportes = await filtrarYOrdenar(await obtenerSolicitudes(), parametros); // Llama al PHP y obtiene los datos

    console.log("cosa pedorra")

    if (aportes.length > 7) {
        console.log("mas de 7 solis")
        listaAportes = dividirListaEnPaginas(aportes); // Divide en páginas
    } else {
        listaAportes = aportes;
        console.log("menos de 7 solis")
    }
    // Ahora que los datos están listos, podemos listar la primera página
    listarPaginas(0, listaAportes);
    acomodarControlesLista(dividirListaEnPaginas(aportes));

}
// Llamamos a la función
cargarSolicitudes();
async function listarPagina(num) {
    soli = await filtrarYOrdenar(await obtenerSolicitudes(), parametros); // Llama al PHP y obtiene los datos

    listaSolicitudes = dividirListaEnPaginas(soli); // Divide en páginas

    listarPaginas(num, listaAportes);
}

function listarPaginas(num, listar) {
    var lista = document.querySelector(".lista-real");

    lista.innerHTML = "";
    if (listar[num][0] !== undefined) {
        listar = listar[num];
    } else {
        listar = listar;
    }

    for (var i = 0; i < listar.length; i++) {
        switch (listar[i].estado) {
            case "aprobado":
                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha}</p>
                        </div>

                        <div class="separador"></div> 

                        <div class="nombreTitular">
                            <p>${listar[i].nombre.toUpperCase()} ${listar[i].primer_apellido.toUpperCase()} ${listar[i].segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].cant_horas}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">Aprobado</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_aprobado" onclick="mostrarDatosAporte(${listar[i].id})">
                            Ver solicitud
                        </button>

                    </div>
                `);
                break;
            case "rechazado":
                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="nombreTitular">
                            <p>${listar[i].nombre.toUpperCase()} ${listar[i].primer_apellido.toUpperCase()} ${listar[i].segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].cant_horas}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">Rechazado</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_rechazado" onclick="mostrarDatosAporte(${listar[i].id})">
                            Ver solicitud
                        </button>

                    </div>
                `);
                break;

            case "pendiente":
                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="nombreTitular">
                            <p>${listar[i].nombre.toUpperCase()} ${listar[i].primer_apellido.toUpperCase()} ${listar[i].segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].cant_horas}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">Pendiente</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_pendiente" onclick="mostrarDatosAporte(${listar[i].id})">
                            Evaluar
                        </button>

                    </div>
                `);
                break;

            case "en_votacion":

                //existen 2 estados falta diferenciarlos

                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="nombreTitular">
                            <p>${listar[i].nombre.toUpperCase()} ${listar[i].primer_apellido.toUpperCase()} ${listar[i].segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].cant_horas}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">En votacion ${listar[i].evaluaciones}/${listar[i].admins}</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_en_votacion" onclick="mostrarDatosAporte(${listar[i].id})">
                            Votar / Voto emitido
                        </button>

                    </div>
                `);
                break;
        }
    }
}

function accederEvaluacionSolicitud(idsolicitud) {
    console.log(idsolicitud + " esta es la solicitud")
}



async function mostrarDatosAporte(id_solicitud) {
    sessionStorage.setItem("id_solicitud", JSON.stringify(id_solicitud));
    window.location = "../html/evaluar-solicitud-exoneracion.html";
}