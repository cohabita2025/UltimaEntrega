

async function obtenerDatosSolicitud(id_solicitud){
    try{
        const formData = new FormData();
        formData.append('id_solicitud', id_solicitud);

        const response = await fetch('../php/obtener_datos_solicitud_registro.php', {
            method: 'POST',
            body: formData
        });

        if(!response.ok) throw new Error(`HTTP error: ${response.status}`);

        const datos = await response.json();
        return datos;

    } catch(error){
        console.error("Error al obtener datos de la solicitud:", error);
        return null;
    }
}

var idsolicitud;

// Función para enviar datos a otra página
async function mostrarDatosSolicitud(id_solicitud){
    const datosSolicitud = await obtenerDatosSolicitud(id_solicitud);
    if(datosSolicitud){
        // Crear un objeto con ambos datos
        const payload = {
            datosSolicitud: datosSolicitud,
            id_solicitud: id_solicitud
        };

        // Codificar como string y ponerlo en la URL
        const datosJSON = encodeURIComponent(JSON.stringify(payload));
        window.location = `../html/evaluar-solicitud-registro.html?datos=${datosJSON}`;
    }
}


// -------------------------------
// En la página evaluar-solicitud-registro.html
// -------------------------------
const params = new URLSearchParams(window.location.search);
const payload = JSON.parse(params.get('datos'));

// Acceder a los datos
const datosSolicitud = payload.datosSolicitud;
const id_solicitud = payload.id_solicitud;

const input_conclusion = document.getElementById('conclusion')

const botones = document.querySelector(".botones");
if(datosSolicitud.solicitud.estado !== "pendiente"){
    botones.style.display="none";
    const conclusion_final =document.querySelector(".conclusion-final")
    switch(datosSolicitud.solicitud.estado){
        case "aprobado":
            conclusion_final.innerHTML="Esta solicitud fue Aprobada";
            conclusion_final.classList.add('aceptar');

            for (var i=0;  i < datosSolicitud.evaluaciones.length; i++){
                if(datosSolicitud.evaluaciones[i].cedula === usuario.cedula){
                        input_conclusion.disabled=true;
        
                        if(datosSolicitud.evaluaciones[i].razon_conclusion !== ""){
                            input_conclusion.value = datosSolicitud.evaluaciones[i].razon_conclusion;
                        }else{
                            input_conclusion.value = "No escribiste una conclusion";
                        }
                }
            }
            

        break;
        case "rechazado":
            conclusion_final.innerHTML="Esta solicitud fue Rechazada";
            conclusion_final.classList.add('rechazar');

            for (var i=0;  i < datosSolicitud.evaluaciones.length; i++){
                if(datosSolicitud.evaluaciones[i].cedula === usuario.cedula){
                        input_conclusion.disabled=true;
        
                        if(datosSolicitud.evaluaciones[i].razon_conclusion !== ""){
                            input_conclusion.value = datosSolicitud.evaluaciones[i].razon_conclusion;
                        }else{
                            input_conclusion.value = "No escribiste una conclusion";
                        }
                }
            }

        break;
        case "en_votacion":
            var votaste=false;
            for (var i=0;  i < datosSolicitud.evaluaciones.length; i++){
                if(datosSolicitud.evaluaciones[i].cedula === usuario.cedula){
                    votaste=true;
                    switch(datosSolicitud.evaluaciones[i].conclusion){
                        case "aprobado":
        
                        conclusion_final.innerHTML="Tu decicion fue : Aprobada";
                        conclusion_final.classList.add('aceptar');
                        input_conclusion.disabled=true;
        
                        if(datosSolicitud.evaluaciones[i].razon_conclusion !== ""){
                            input_conclusion.value = datosSolicitud.evaluaciones[i].razon_conclusion;
                        }else{
                            input_conclusion.value = "No escribiste una conclusion";
                        }

                        break;
        
                        case "rechazado":
        
                        conclusion_final.innerHTML="Tu decicion fue : Rechazada";
                        conclusion_final.classList.add('rechazar');

                        input_conclusion.disabled=true;
                        if(datosSolicitud.evaluaciones[i].razon_conclusion !== ""){
                            input_conclusion.value = datosSolicitud.evaluaciones[i].razon_conclusion;
                        }else{
                            input_conclusion.value = "No escribiste una conclusion";
                        }

                        break;

                        case "pendiente":
                            console.log("no voto nada")
                            botones.style.display="flex";
                            document.querySelector(".conclusion-final").style.display='none';
                            break;
                    }
                    
                }
                
            }
            /*
            if(!votaste){
                console.log("no voto")
                
            }else{
                console.log("voto")
                botones.style.display="none";
                document.querySelector(".conclusion-final").style.display='flex';
            }*/
        break;
    }
}

for (var i=0 ; i <datosSolicitud.personas.length ;i++){
    document.querySelector(".integrantes").insertAdjacentHTML('beforeend', `
        <div class="integrante">
            <div class="datos">
                <img src="../archivos/familias/${datosSolicitud.solicitud.id_familia}/${datosSolicitud.personas[i].cedula}/${datosSolicitud.personas[i].foto}" alt="">
                    <div class="nombreIntegrante">
                        <p>${datosSolicitud.personas[i].nombre} ${datosSolicitud.personas[i].primer_apellido} ${datosSolicitud.personas[i].segundo_apellido}</p>
                        </div>
                    </div>
                    <button class="verIntegrante" onclick='mostrarPersona(${JSON.stringify(datosSolicitud.personas[i])})'>
                        Ver Familiar
                    </button>

                </div>
    `);
}

for (var i=0 ; i <datosSolicitud.evaluaciones.length ;i++){
    if( datosSolicitud.evaluaciones[i].conclusion === "pendiente"){
        document.querySelector(".conclusiones").insertAdjacentHTML('beforeend', `
            <div class="conclusion-admin">
                <div class="nombre-admin">
                     <p>${datosSolicitud.evaluaciones[i].nombre} ${datosSolicitud.evaluaciones[i].primer_apellido} ${datosSolicitud.evaluaciones[i].segundo_apellido}</p>
                </div>
                <div class="conclusion pendiente">
                    <p>Pendiente</p>
                </div>                           
                </div>
            `);
    }else if(datosSolicitud.evaluaciones[i].conclusion === "aprobado"){
        if(datosSolicitud.evaluaciones[i].razon_conclusion === ""){
            document.querySelector(".conclusiones").insertAdjacentHTML('beforeend', `
                <div class="conclusion-admin">
                    <div class="nombre-admin">
                        <p>${datosSolicitud.evaluaciones[i].nombre} ${datosSolicitud.evaluaciones[i].primer_apellido} ${datosSolicitud.evaluaciones[i].segundo_apellido}</p>
                    </div>
                    <div class="conclusion aceptada">
                        <p>Aceptada</p>
                    </div>                           
                        <div class="ver-conclusion">
                             <p>Ver conclusion</p>
                            <div class="razon-conclusion">
                                <p> El admin no escribio una conclusion </p>
                            </div>
                        </div>
                    </div>
                `);
        }else{
            document.querySelector(".conclusiones").insertAdjacentHTML('beforeend', `
                <div class="conclusion-admin">
                    <div class="nombre-admin">
                        <p>${datosSolicitud.evaluaciones[i].nombre} ${datosSolicitud.evaluaciones[i].primer_apellido} ${datosSolicitud.evaluaciones[i].segundo_apellido}</p>
                    </div>
                    <div class="conclusion aceptada">
                        <p>Aceptada</p>
                    </div>                           
                        <div class="ver-conclusion">
                             <p>Ver conclusion</p>
                            <div class="razon-conclusion">
                                <p> ${datosSolicitud.evaluaciones[i].razon_conclusion} </p>
                            </div>
                        </div>
                    </div>
                `);
        }
    }else{
        if(datosSolicitud.evaluaciones[i].razon_conclusion === ""){
            document.querySelector(".conclusiones").insertAdjacentHTML('beforeend', `
                <div class="conclusion-admin">
                    <div class="nombre-admin">
                        <p>${datosSolicitud.evaluaciones[i].nombre} ${datosSolicitud.evaluaciones[i].primer_apellido} ${datosSolicitud.evaluaciones[i].segundo_apellido}</p>
                    </div>
                    <div class="conclusion rechazada">
                        <p>Aceptada</p>
                    </div>                           
                        <div class="ver-conclusion">
                             <p>Ver conclusion</p>
                            <div class="razon-conclusion">
                                <p> El admin no escribio una conclusion </p>
                            </div>
                        </div>
                    </div>
                `);
        }else{
            document.querySelector(".conclusiones").insertAdjacentHTML('beforeend', `
                <div class="conclusion-admin">
                    <div class="nombre-admin">
                        <p>${datosSolicitud.evaluaciones[i].nombre} ${datosSolicitud.evaluaciones[i].primer_apellido} ${datosSolicitud.evaluaciones[i].segundo_apellido}</p>
                    </div>
                    <div class="conclusion rechazada">
                        <p>Rechazada</p>
                    </div>                           
                        <div class="ver-conclusion">
                             <p>Ver conclusion</p>
                            <div class="razon-conclusion">
                                <p> ${datosSolicitud.evaluaciones[i].razon_conclusion} </p>
                            </div>
                        </div>
                    </div>
                `);
        }
    }
}

/*

<div class="conclusion-admin">
    <div class="nombre-admin">
        <p></p>
    </div>
    <div class="conclusion pendiente">
        <p></p>
    </div>                           
    <div class="ver-conclusion">
    <p>Ver conclusion</p>
        <div class="razon-conclusion">
            <p></p>
        </div>
    </div>
</div>

*/

var faltan =datosSolicitud.evaluaciones.length;

console.log("estos son los datos de solicitud" , datosSolicitud)

if(datosSolicitud.solicitud.estado === "en_votacion"){
    if(usuario.rol !== 'admin'){
        window.location.href="../html/acceso-denegado.html"
    }
    console.log("en votacion")
    for(var i = 0; i < datosSolicitud.evaluaciones.length; i++){
        console.log("entra al for")
        if(datosSolicitud.evaluaciones[i].conclusion === 'pendiente'){
            console.log("entra al if")
            faltan= faltan - 1 ;
        }
    }
    console.log("despues del for")
    document.getElementById("admins-restantes").innerHTML= "Admins faltantes : " + faltan + "/" + datosSolicitud.evaluaciones.length; 

}else if(datosSolicitud.solicitud.estado === "pendiente"){
    if(usuario.rol !== 'admin'){
        window.location.href="../html/acceso-denegado.html"
    }
    console.log("pendiente")
    document.querySelector(".conclusion-final").style.display='none';
    document.getElementById("admins-restantes").innerHTML= "Admins faltantes : " + datosSolicitud.evaluaciones.length + "/" + datosSolicitud.evaluaciones.length; 
}else{
    console.log("rechazada o aceptada")
    document.getElementById("admins-restantes").innerHTML= "Admins faltantes : " + "0" + "/" + datosSolicitud.evaluaciones.length; 
    
}

function validacionDatos(){
    var datosValidos=true;
    const inputConclusion = document.getElementById('conclusion');
    if(!inputConclusion.checkValidity()){
        datosValidos=false;            
        if (!inputConclusion.parentNode.classList.contains("invalido")){
            inputConclusion.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una conclusion valida.</p>');
            inputConclusion.parentNode.classList.add("invalido");
        }
    }else{
        if (inputConclusion.parentNode.querySelector("p.mensaje-error") !== null){
            inputConclusion.parentNode.classList.remove("invalido");
            inputConclusion.parentNode.querySelector("p.mensaje-error").remove();
        }
    }
    return datosValidos;
}

// Función que se llama al click
async function evaluarSolicitudRegistro(conclusion, razon_conclusion) {
    if (validacionDatos()) {
        if (await confirmarAccion('¿Enviar?')) {

            try {
                const formData = new FormData();
                formData.append("id_solicitud", id_solicitud);
                formData.append("id_admin", usuario.cedula);
                formData.append("conclusion", conclusion);
                formData.append("razon_conclusion", razon_conclusion);

                const response = await fetch("../php/evaluar_solicitud_registro.php", {
                    method: "POST",
                    body: formData
                });

                // ✅ No intentamos parsear JSON
                if (response.ok) {
                    window.location.href = "../html/lista-solicitudes-registro.html";
                } else {
                    alert("Error del servidor: " + response.status);
                }

            } catch (error) {
                console.error("Error en evaluarSolicitudRegistro:", error);
                alert("No se pudo enviar la evaluación.");
            }
        }
    }
}
