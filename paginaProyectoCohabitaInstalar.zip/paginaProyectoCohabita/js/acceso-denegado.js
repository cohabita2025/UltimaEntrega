function redirigirAcceso(){
    const usuario = obtenerFamiliarGuardado();
    if (usuario === null) { 
    window.location.href = "../html/index.html";
}else{ 
    window.location.href = "../html/pagina-principal.html";
}
}


console.log("a s")