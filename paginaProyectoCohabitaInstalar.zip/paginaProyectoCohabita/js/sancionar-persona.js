const params = new URLSearchParams(window.location.search);

// Leer el valor del parámetro "datos"
const cedula_adulto = params.get("cedula_adulto");
const familia_sancionar = params.get("id_familia");


async function obtenerTitularFamilia(idFamilia) {
    try {
        const formData = new FormData();
        formData.append("id_familia", idFamilia);

        const response = await fetch("../php/obtener_titular_familia.php", {
            method: "POST",
            body: formData,
        });

        const text = await response.text();

        let data;
        try {
            data = JSON.parse(text);
        } catch (err) {
            console.error("⚠️ La respuesta no es JSON válido:", err);
            return { error: "Respuesta inválida del servidor" };
        }

        if (!response.ok) {
            console.error("❌ Error HTTP:", response.status, data);
            return { error: data.error || "Error desconocido del servidor" };
        }

        return data;

    } catch (error) {
        return { error: "No se pudo conectar con el servidor" };
    }
}

async function acomodarPagina() {
    const tituloSancion = document.getElementById("titulo-sancion")
    var titular;
    var adulto;
    if (cedula_adulto) {
        adulto = await obtenerFamiliar(cedula_adulto)
        tituloSancion.innerHTML = "Sancionar a " + adulto.nombre + " " + adulto.primer_apellido + " " + adulto.segundo_apellido
        console.log(adulto)
        document.getElementById("monto").disabled = true;
    } else if (familia_sancionar) {
        titular = await obtenerTitularFamilia(familia_sancionar)
        console.log(titular)
        tituloSancion.innerHTML = "Sancionar Familia de " + titular.nombre + " " + titular.primer_apellido + " " + titular.segundo_apellido

        console.log(titular)
    }


}

acomodarPagina();

var cantidadPruebas = 0;

function agregarArchivo() {
    const inputTrucho = document.getElementById("input-file-falso");
    const listaPruebas = document.getElementById("pruebas-archivos");

    if (inputTrucho.files.length === 0) return;

    const archivoTrucho = inputTrucho.files[0];

    // Revisar si ya existe un input con el mismo archivo
    const pruebas = document.getElementsByClassName("prueba");
    for (const actual of pruebas) {
        if (actual.files.length === 0) continue; // prevención
        const archivoActual = actual.files[0];
        if (
            archivoActual.name === archivoTrucho.name &&
            archivoActual.size === archivoTrucho.size &&
            archivoActual.type === archivoTrucho.type
        ) {
            console.log("Archivo ya agregado, no se repite");
            return; // salir si ya existe
        }
    }

    // Incrementar contador
    cantidadPruebas++;

    // Crear div contenedor
    const nuevoDiv = document.createElement("div");
    nuevoDiv.classList.add("input-archivo");
    nuevoDiv.id = `div-prueba${cantidadPruebas}`;

    // Crear input file y asignarle el archivo usando DataTransfer
    const dt = new DataTransfer();
    dt.items.add(archivoTrucho);

    const nuevoInput = document.createElement("input");
    nuevoInput.type = "file";
    nuevoInput.classList.add("prueba");
    nuevoInput.id = `prueba${cantidadPruebas}`;
    nuevoInput.files = dt.files;

    // Crear párrafo con nombre de archivo
    const p = document.createElement("p");
    p.classList.add("nombre-archivo");
    p.textContent = archivoTrucho.name;

    // Crear botón de borrar
    const btn = document.createElement("button");
    btn.type = "button";
    btn.innerHTML = `<img src="../archivos/imagenes/SimboloTachar.svg" alt="">`;
    btn.onclick = () => nuevoDiv.remove();

    // Agregar todo al div
    nuevoDiv.appendChild(nuevoInput);
    nuevoDiv.appendChild(p);
    nuevoDiv.appendChild(btn);

    // Agregar el div al inicio de la lista
    listaPruebas.prepend(nuevoDiv);
}

async function validarDatos() {
    var datosValidos = true;

    var SaSmesFin = document.getElementById("mesInputFin").value;

    var SaSdiaFin = document.getElementById("dia_fin").value;

    var SaSanioFin = document.getElementById("anio_fin").value;



    if (SaSdiaFin.length === 1) {
        SaSdiaFin = "0" + SaSdiaFin
    }

    if (SaSmesFin.length === 1) {
        SaSmesFin = "0" + SaSmesFin
    }
    const fecha_fin = (SaSanioFin + '-' + SaSmesFin + '-' + SaSdiaFin);



    const conclusion = document.getElementById("conclusion");
    const pruebas = document.getElementsByClassName("prueba");
    const listaPruebas = document.getElementById("pruebas-archivos");
    const monto = document.getElementById("monto");
    const cant_horas = document.getElementById("cant-horas")
    const mesFin = document.getElementById("mesInputFin");
    const diaFin = document.getElementById("dia_fin");
    const anioFin = document.getElementById("anio_fin");

    if (!monto.checkValidity()) {

        datosValidos = false;

        if (!monto.classList.contains("invalido")) {
            monto.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes agregar un monto.</p>');
            monto.classList.add("invalido");
        }
    } else {
        if (monto.parentNode.querySelector("p.mensaje-error") !== null) {
            monto.classList.remove("invalido");
            monto.parentNode.querySelector("p.mensaje-error").remove();
        }
    }

    if (!cant_horas.checkValidity()) {

        datosValidos = false;

        if (!cant_horas.classList.contains("invalido")) {
            cant_horas.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes agregar horas .</p>');
            cant_horas.classList.add("invalido");
        }
    } else {
        if (cant_horas.parentNode.querySelector("p.mensaje-error") !== null) {
            cant_horas.classList.remove("invalido");
            cant_horas.parentNode.querySelector("p.mensaje-error").remove();
        }
    }

    if (!conclusion.checkValidity()) {

        datosValidos = false;

        if (!conclusion.parentNode.classList.contains("invalido")) {
            conclusion.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una razon valida.</p>');
            conclusion.parentNode.classList.add("invalido");
        }
    } else {
        if (conclusion.parentNode.querySelector("p.mensaje-error") !== null) {
            conclusion.parentNode.classList.remove("invalido");
            conclusion.parentNode.querySelector("p.mensaje-error").remove();
        }
    }

    if (pruebas.length === 0) {

        datosValidos = false;

        if (!listaPruebas.classList.contains("invalido")) {
            listaPruebas.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar pruebas..</p>');
            listaPruebas.classList.add("invalido");
        }
    } else {
        if (listaPruebas.parentNode.querySelector("p.mensaje-error") !== null) {
            listaPruebas.classList.remove("invalido");
            listaPruebas.parentNode.querySelector("p.mensaje-error").remove();
        }
    }

    if (!mesFin.checkValidity()) {
        datosValidos = false;
        if (!mesFin.parentNode.parentNode.parentNode.classList.contains("invalido")) {
            mesFin.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un mes valido.</p>');
            mesFin.parentNode.parentNode.parentNode.classList.add("invalido");
        }
    } else {
        const fechaFin = new Date(anioFin.value, mesFin.value - 1, diaFin.value);
        if (fechaFin.getDay() !== 0) {
            datosValidos = false;
            if (!mesFin.parentNode.parentNode.parentNode.classList.contains("invalido")) {
                mesFin.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">La fecha de Fin debe ser domingo.</p>');
                mesFin.parentNode.parentNode.parentNode.classList.add("invalido");
            } else {
                mesFin.parentNode.parentNode.parentNode.classList.remove("invalido");
                mesFin.parentNode.parentNode.parentNode.querySelector("p.mensaje-error").remove();
                mesFin.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">La fecha de Fin debe ser domingo .</p>');
                mesFin.parentNode.parentNode.parentNode.classList.add("invalido");
            }
        } else {
            if (diferenciaFechas(fecha_fin, await obtenerProximoDia(0), "restar") < 7) {
                datosValidos = false;
                if (!mesFin.parentNode.parentNode.parentNode.classList.contains("invalido")) {
                    mesFin.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">La fecha es muy cercana.</p>');
                    mesFin.parentNode.parentNode.parentNode.classList.add("invalido");
                } else {
                    mesFin.parentNode.parentNode.parentNode.classList.remove("invalido");
                    mesFin.parentNode.parentNode.parentNode.querySelector("p.mensaje-error").remove();
                    mesFin.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">La fecha es muy cercana.</p>');
                    mesFin.parentNode.parentNode.parentNode.classList.add("invalido");
                }
            } else {
                if (mesFin.parentNode.parentNode.parentNode.querySelector("p.mensaje-error") !== null) {
                    mesFin.parentNode.parentNode.parentNode.classList.remove("invalido");
                    mesFin.parentNode.parentNode.parentNode.querySelector("p.mensaje-error").remove();
                }
            }
        }
    }
    return datosValidos;
}

async function recolectarDatos() {
    var datos = {};
    var pruebas = [];

    var mesFin = document.getElementById("mesInputFin").value;

    var diaFin = document.getElementById("dia_fin").value;

    const anioFin = document.getElementById("anio_fin").value;



    if (diaFin.length === 1) {
        diaFin = "0" + diaFin
    }


    if (mesFin.length === 1) {
        mesFin = "0" + mesFin
    }


    datos.fecha_inicio = await obtenerProximoDia(1);
    datos.fecha_fin = (anioFin + '-' + mesFin + '-' + diaFin);
    datos.cedula_admin = usuario.cedula
    datos.motivo = document.getElementById("conclusion").value;
    datos.cant_horas = document.getElementById("cant-horas").value;
    datos.monto = document.getElementById("monto").value;

    const pruebasDivs = document.getElementsByClassName("input-archivo");

    for (const actual of pruebasDivs) {
        pruebas.push(actual.querySelector("input").files[0]);
    }

    datos.pruebas = pruebas;

    return datos;
}

async function enviarSolicitudExoneracion() {
    if (await validarDatos()) {
        if (await confirmarAccion('¿Enviar sanción?')) {
            const datos = await recolectarDatos(); // tu función que devuelve cant_horas, monto, motivo, fecha_limite, cedula_admin, etc.

            const formData = new FormData();
            formData.append("motivo", datos.motivo);
            formData.append("fecha_limite", datos.fecha_fin);
            formData.append("fecha_inicio", datos.fecha_inicio);
            formData.append("cedula_admin", datos.cedula_admin);
            formData.append("cant_horas", datos.cant_horas);
            formData.append("monto", datos.monto);

            // si es sanción a un adulto
            if (cedula_adulto) {
                console.log(" adulto xd - ", cedula_adulto, familia_sancionar)
                formData.append("cedula_adulto", cedula_adulto);
                formData.append("id_familia", familia_sancionar);
            }
            // si es sanción a una familia
            else if (familia_sancionar) {
                formData.append("id_familia", familia_sancionar);
            }

            // agregar archivos
            datos.pruebas.forEach(archivo => formData.append("pruebas[]", archivo));

            try {
                const respuesta = await fetch("../php/sancionar.php", {
                    method: "POST",
                    body: formData
                });

                const text = await respuesta.text();
                console.log("🔍 Respuesta cruda del servidor:", text);

                let result;
                try {
                    result = JSON.parse(text);
                } catch (err) {
                    console.error("⚠️ La respuesta no es JSON válido:", err);
                    return;
                }

                console.log("===== DEBUG SANCIÓN =====");
                console.log(result);

                if (result.status === "ok") {
                    window.location.href = "../html/pagina-principal.html";
                } else {
                    alert("❌ Error: " + (result.mensaje || "Error desconocido"));
                }

            } catch (err) {
                console.error("🔥 Error al enviar sanción:", err);
                alert("Error de conexión con el servidor.");
            }
        }
    }
}
