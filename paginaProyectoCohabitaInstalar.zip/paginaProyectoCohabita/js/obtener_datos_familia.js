

async function obtenerDatosSolicitud(id_solicitud) {
    console.log(id_solicitud)
    try {
        const formData = new FormData();
        formData.append('id_solicitud', id_solicitud);

        const response = await fetch('../php/obtener_datos_solicitud_registro.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error(`HTTP error: ${response.status}`);

        const datos = await response.json();
        return datos;

    } catch (error) {
        console.error("Error al obtener datos de la solicitud:", error);
        return null;
    }
}

var idsolicitud;

// Función para enviar datos a otra página
async function mostrarDatosSolicitud(id_solicitud) {
    const datosSolicitud = await obtenerDatosSolicitud(id_solicitud);
    if (datosSolicitud) {
        // Crear un objeto con ambos datos
        const payload = {
            datosSolicitud: datosSolicitud,
            id_solicitud: id_solicitud
        };

        // Codificar como string y ponerlo en la URL
        const datosJSON = encodeURIComponent(JSON.stringify(payload));
        window.location = `../html/estadisticas-familia.html?datos=${datosJSON}`;
    }
}


// -------------------------------
// En la página evaluar-solicitud-registro.html
// -------------------------------
const params = new URLSearchParams(window.location.search);
const payload = JSON.parse(params.get('datos'));

// Acceder a los datos
const datosSolicitud = payload.datosSolicitud;
const c = payload.id_solicitud;

async function acomodarPagina() {
    const familia = await obtenerDatosSolicitud(c);
    const titular = familia.personas.find(titular => titular.rol === "titular");

    document.getElementById("nombre-familia").querySelector("p").innerHTML += titular.nombre + " " + titular.primer_apellido + " " + titular.segundo_apellido

    const horasFamilia = await procesarHorasFamilia(c);

    document.getElementById("cantidad-aportes-semana").innerHTML += horasFamilia.resumenSemanas[horasFamilia.resumenSemanas.length - 1].idsAportes.length
    document.getElementById("cantidad-horas-semana").innerHTML += horasFamilia.resumenSemanas[horasFamilia.resumenSemanas.length - 1].horasAportadas + "hs"

    document.getElementById("cantidad-aportes-mes").innerHTML += horasFamilia.resumenMeses[horasFamilia.resumenMeses.length - 1].idsAportes.length
    document.getElementById("cantidad-horas-mes").innerHTML += horasFamilia.resumenMeses[horasFamilia.resumenMeses.length - 1].horasAportadas + "hs"

    document.getElementById("cantidad-aportes-total").innerHTML += horasFamilia.horasId.length
    document.getElementById("cantidad-horas-total").innerHTML += horasFamilia.horasTotales + "hs"


    if (horasFamilia.resumenSemanas[horasFamilia.resumenSemanas.length - 1].horasExoneradas !== 0) {
        document.getElementById("semana-actual-exonerada").innerHTML += "Si";
    } else {
        document.getElementById("semana-actual-exonerada").innerHTML += "No"
    }
    document.getElementById("cantidad-exoneraciones-mes").innerHTML += horasFamilia.resumenMeses[horasFamilia.resumenMeses.length - 1].idsExoneraciones.length
    document.getElementById("horas-exoneradas-mes").innerHTML += horasFamilia.resumenMeses[horasFamilia.resumenMeses.length - 1].horasExoneradas + "hs"

    document.getElementById("cantidad-exoneraciones-total").innerHTML += horasFamilia.exoneracionesId.length
    document.getElementById("horas-exoneradas-total").innerHTML += horasFamilia.horasTotalesExoneradas + "hs"

    var horasSancionSemana = 0;
    var horasSancionMes = 0;
    var horasSancionTotal = 0;

    var montoSancionSemana = 0;
    var montoSancionMes = 0;
    var montoSancionTotal = 0;

    for (const sancionSemana of horasFamilia.resumenSemanas[horasFamilia.resumenSemanas.length - 1].sancionesPagadas) {
        horasSancionSemana += sancionSemana.detalle.cant_horas_sancion;
        if (sancionSemana.tipo === "familia") {
            montoSancionSemana += sancionSemana.detalle.monto_sancion;
        }
    }

    for (const sancionSemana of horasFamilia.resumenMeses[horasFamilia.resumenMeses.length - 1].sancionesPagadas) {
        horasSancionMes += sancionSemana.detalle.cant_horas_sancion;
        if (sancionSemana.tipo === "familia") {
            montoSancionMes += sancionSemana.detalle.monto_sancion;
        }
    }

    for (const sancionSemana of horasFamilia.sancionesTotalesPagadas) {
        horasSancionTotal += sancionSemana.detalle.cant_horas_sancion;
        if (sancionSemana.tipo === "familia") {
            montoSancionTotal += sancionSemana.detalle.monto_sancion;
        }
    }

    document.getElementById("cantidad-sanciones-semana").innerHTML += horasFamilia.resumenSemanas[horasFamilia.resumenSemanas.length - 1].idsSanciones.length
    document.getElementById("cantidad-sanciones-pagadas-semana").innerHTML += horasFamilia.resumenSemanas[horasFamilia.resumenSemanas.length - 1].sancionesPagadas.length + " - " + horasSancionSemana + "hs - " + montoSancionSemana + "usd"

    document.getElementById("cantidad-sanciones-mes").innerHTML += horasFamilia.resumenMeses[horasFamilia.resumenMeses.length - 1].idsSanciones.length
    document.getElementById("cantidad-sanciones-pagadas-mes").innerHTML += horasFamilia.resumenMeses[horasFamilia.resumenMeses.length - 1].sancionesPagadas.length + " - " + horasSancionMes + "hs - " + montoSancionMes + "usd"

    document.getElementById("cantidad-sanciones-total").innerHTML += horasFamilia.sancionesId.length
    document.getElementById("cantidad-sanciones-pagadas-total").innerHTML += horasFamilia.sancionesTotalesPagadas.length + " - " + horasSancionTotal + "hs - " + montoSancionTotal + "usd"

    const pagosFamilia = await procesarPagosFamilia(c);

    document.getElementById("cantidad-pagos-mes").innerHTML += pagosFamilia.resumenMeses[pagosFamilia.resumenMeses.length - 1].idsPagos.length
    document.getElementById("monto-mes").innerHTML += pagosFamilia.resumenMeses[pagosFamilia.resumenMeses.length - 1].totalPagado + "hs"

    document.getElementById("cantidad-pagos-anio").innerHTML += pagosFamilia.resumenAnios[pagosFamilia.resumenAnios.length - 1].idsPagos.length
    document.getElementById("monto-anio").innerHTML += pagosFamilia.resumenAnios[pagosFamilia.resumenAnios.length - 1].totalPagado + "hs"

    document.getElementById("cantidad-pagos-total").innerHTML += pagosFamilia.idsPagos.length
    document.getElementById("monto-total").innerHTML += pagosFamilia.totalPagos + "hs"

    console.log((c,usuario.id_familia) , (c === usuario.id_familia))
    if(c === Number(usuario.id_familia) || (c === usuario.id_familia)){
        console.log("trmened")
        document.getElementById("sancionar").remove()
        document.getElementById("expulsar").remove()
        document.getElementById("botones-sancion-expulsar").remove()
        document.getElementById("estadisticas-familia").classList.add("familia-propia")
    }
}

acomodarPagina();

// 757