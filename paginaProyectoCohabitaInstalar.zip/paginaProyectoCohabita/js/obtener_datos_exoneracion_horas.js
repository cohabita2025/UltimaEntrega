if((usuario.rol !== 'admin') && (usuario.rol !== 'titular')){
    window.location.href="../html/acceso-denegado.html"
}

let id_solicitud = sessionStorage.getItem("id_solicitud");
console.log(id_solicitud)

async function cargarAporteSeleccionado() {
    let id_solicitud = sessionStorage.getItem("id_solicitud");

    if (!id_solicitud) {
        console.log("No hay id_solicitud en sessionStorage");
        return null;
    }

    id_solicitud = JSON.parse(id_solicitud);

    try {
        const response = await fetch(`../php/obtener_solicitud_exoneracion.php?id_solicitud=${id_solicitud}`);
        
        if (!response.ok) {
            throw new Error("Error en la respuesta del servidor");
        }

        const data = await response.json();
        console.log(data)
        return data; // 🔹 Devuelve directamente el array recibido del PHP

        console.log(data)
    } catch (error) {
        console.error("Error al obtener los datos:", error);
        return null;
    }
}

async function acomodarPagina(){
    const datosAporte = await cargarAporteSeleccionado();

    const nombreArchivo = window.location.pathname.split("/").pop();

    if( (nombreArchivo === "evaluar-solicitud-exoneracion.html") && ((Number(usuario.id_familia) !== Number(datosAporte.solicitud_exoneracion.id_familia)) && (usuario.rol !== 'admin')) ){
        window.location.href="../html/acceso-denegado.html"
    }

    document.getElementById("nombre").innerHTML= datosAporte.solicitud_exoneracion.nombre + " " + datosAporte.solicitud_exoneracion.primer_apellido + " " + datosAporte.solicitud_exoneracion.segundo_apellido;

    document.getElementById("hora-entrada-salida").innerHTML= pasarFechaNumeroTexto(new Date(datosAporte.solicitud_exoneracion.fecha_inicio)) + " al " + pasarFechaNumeroTexto(new Date(datosAporte.solicitud_exoneracion.fecha_fin));

    document.getElementById("fecha_solicitud").innerHTML= pasarFechaNumeroTexto(new Date(datosAporte.solicitud_exoneracion.fecha));

    document.getElementById("actividad").innerHTML=datosAporte.solicitud_exoneracion.motivo;

    document.getElementById("pruebas").onclick = async () => {
        if(await confirmarAccion('¿Descargar archivos?')){
        await descargarVariosArchivos(`../archivos/solicitudes de exoneracion de horas/${datosAporte.solicitud_exoneracion.cedula}/${datosAporte.solicitud_exoneracion.pruebas}`);
        }
    };

    
    document.getElementById("pruebas-exoneracion").innerHTML= `${datosAporte.solicitud_exoneracion.pruebas}`;

    const input_conclusion = document.getElementById('conclusion');
    const botones = document.querySelector(".botones");

    if(datosAporte.solicitud_exoneracion.estado !== "pendiente"){
        botones.style.display="none";
        const conclusion_final =document.querySelector(".conclusion-final");
        const nombreEvaluador = datosAporte.tramitaciones[0].nombre + " " + datosAporte.tramitaciones[0].primer_apellido + " " + datosAporte.tramitaciones[0].segundo_apellido 
        const pNombreEvaluador = document.getElementById("evaluador_p");
        pNombreEvaluador.innerHTML="Admin que evaluo  : "+nombreEvaluador.toUpperCase();
        pNombreEvaluador.style.display="flex";
        const conclusion = document.getElementById("conclusion");
        conclusion.value = datosAporte.tramitaciones[0].razon_conclusion;

        conclusion.disabled=true;
        switch(datosAporte.solicitud_exoneracion.estado){
            case "aprobado":
            console.log("aprobadonson")
            conclusion_final.innerHTML="Esta solicitud fue Aprobada";
            conclusion_final.classList.add('aceptar');
            conclusion_final.style.display="flex";
            break;
            case "rechazado":
            conclusion_final.innerHTML="Esta solicitud fue Rechazada";
            conclusion_final.classList.add('rechazar');
            conclusion_final.style.display="flex";
            break;
        }
    }else{
        if(((usuario.rol !== 'admin') && (usuario.rol !== 'titular')) || ((Number(usuario.id_familia) === Number(datosAporte.solicitud_exoneracion.id_familia)) && (datosAporte.solicitud_exoneracion.estado === "pendiente"))){
            window.location.href="../html/acceso-denegado.html"
        }
    }


}

acomodarPagina();

function validacionDatos(){
    var datosValidos=true;
    const inputConclusion = document.getElementById('conclusion');
    if(!inputConclusion.checkValidity()){
        datosValidos=false;            
        if (!inputConclusion.parentNode.classList.contains("invalido")){
            inputConclusion.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una conclusion valida.</p>');
            inputConclusion.parentNode.classList.add("invalido");
        }
    }else{
        if (inputConclusion.parentNode.querySelector("p.mensaje-error") !== null){
            inputConclusion.parentNode.classList.remove("invalido");
            inputConclusion.parentNode.querySelector("p.mensaje-error").remove();
        }
    }
    return datosValidos;
}

// Función que se llama al click
async function evaluarAporteHoras(conclusion, razon_conclusion) {
    if (validacionDatos()) {
        if(await confirmarAccion('¿Enviar?')){
            try {
                const formData = new FormData();
                formData.append("id_solicitud", id_solicitud);
                formData.append("id_admin", usuario.cedula);
                formData.append("conclusion", conclusion);
                formData.append("razon_conclusion", razon_conclusion);

                const response = await fetch("../php/evaluar_solicitud_exoneracion.php", {
                    method: "POST",
                    body: formData
                });

                if (response.ok) {
                    location.reload();
                } else {
                    alert("Error al enviar la evaluación");
                }

            } catch (error) {
                console.error("Error en evaluarAporteHoras:", error);
                alert("No se pudo enviar la evaluación.");
            }
    
        }
    }
}


