const params = new URLSearchParams(window.location.search);

// Leer el valor del parámetro "datos"
const cedula_familiar = params.get("familiar");
const nombre_titular = params.get("titular");
const id_familia = params.get("id_familia");

document.getElementById("nombre-familia").querySelector("p").innerHTML += nombre_titular;

async function acomodarPagina() {
    const persona = await obtenerFamiliar(cedula_familiar);


    document.getElementById("foto-persona").src = `../archivos/familias/${persona.id_familia}/${persona.cedula}/${persona.foto}`;

    document.getElementById("nombre-completo").innerHTML = persona.nombre + " " + persona.primer_apellido + " " + persona.segundo_apellido;
    document.getElementById("cedula").innerHTML = persona.cedula;

    if (persona.genero === "M") { document.getElementById("genero").innerHTML = "Masculino" } else { document.getElementById("genero").innerHTML = "Femenino" }

    document.getElementById("fecha-nacimiento").innerHTML = persona.fecha_nacimiento;
    document.getElementById("rol-familia").innerHTML = persona.rol_familia;

    document.getElementById("copia-cedula").href = `../archivos/familias/${persona.id_familia}/${persona.cedula}/${persona.copia_cedula}`;
    document.getElementById("copia-cedula").download = `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido} copia cedula`;
    document.getElementById("copia-cedula-nombre").innerHTML = `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido} copia cedula`;

    if (persona.telefono) {
        document.getElementById("gmail").innerHTML = persona.correo;
        document.getElementById("numero").innerHTML = persona.telefono;
        if (persona.rol === 'titular') {
            document.getElementById("rol-coperativa").innerHTML = "Titular";
        } else if (persona.rol === 'admin') {
            document.getElementById("rol-coperativa").innerHTML = "Admin";
        } else {
            document.getElementById("rol-coperativa").innerHTML = "No tiene rango"
        }

        document.getElementById("comprobante-ingresos").href = `../archivos/familias/${persona.id_familia}/${persona.cedula}/${persona.recibo_sueldo}`;
        document.getElementById("comprobante-ingresos").download = `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido} comprobante ingresos`;
        document.getElementById("comprobante-ingresos-nombre").innerHTML = `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido} comprobante ingresos`;


        document.getElementById("declaracion-no-vivienda").href = `../archivos/familias/${persona.id_familia}/${persona.cedula}/${persona.declaracion_no_vivienda}`;
        document.getElementById("declaracion-no-vivienda").download = `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido}  declaracion no vivienda`;
        document.getElementById("declaracion-no-vivienda-nombre").innerHTML = `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido} declaracion no vivienda`;

    } else {
        console.log("muy jodida eh")
        const tapar = document.getElementsByClassName("adulto");
        console.log(tapar);
        for (var i = 0; i < tapar.length; i++) {
            console.log(tapar[i]);
            tapar[i].style.display = "none";
        }
    }


}

if (id_familia === (usuario.id_familia)) {
    document.getElementById("informacion-familiar").classList.add("familia-propia")
    document.getElementById("sancionar-familiar").remove()
    document.getElementById("sancionar").remove()
    document.getElementById("expulsar").remove()
    document.getElementById("botones-sancion-expulsar").remove()
}

acomodarPagina();