

// Función para traer todas las solicitudes con su titular
async function obtenerAportesAprobados(idFamilia) {
    try {
        const respuesta = await fetch(`../php/obtener_aportes_familiares.php?id_familia=${usuario.id_familia}`);
        
        if (!respuesta.ok) {
            throw new Error("Error en la respuesta del servidor");
        }

        const datos = await respuesta.json();

        if (datos.error) {
            console.error("Error:", datos.error);
            return [];
        }

        console.log("✅ Datos obtenidos:", datos);
        return datos;

    } catch (error) {
        console.error("❌ Error al obtener los aportes:", error);
        return [];
    }
}


async function cargarSolicitudes() {
    aportes = await obtenerAportesAprobados(); // Llama al PHP y obtiene los datos

    console.log("cosa pedorra")

    if(aportes.length > 7){
        console.log("mas de 7 solis")
        listaAportes = dividirListaEnPaginas(aportes); // Divide en páginas
    }else{
        listaAportes = aportes;
        console.log("menos de 7 solis")
    }
    // Ahora que los datos están listos, podemos listar la primera página
    listarPaginas(0 ,listaAportes);
    acomodarControlesLista(dividirListaEnPaginas(aportes));

}
// Llamamos a la función
cargarSolicitudes();
async function listarPagina (num) {
    soli = await filtrarYOrdenar(await obtenerSolicitudes(), parametros); // Llama al PHP y obtiene los datos

    listaSolicitudes = dividirListaEnPaginas(soli); // Divide en páginas

    listarPaginas(num ,listaAportes);
}

function listarPaginas(num , listar){
    var lista= document.querySelector(".lista-real");
    
    lista.innerHTML = "";
    if(listar[num][0] !== undefined){
        listar=listar[num];
    }else{
        listar=listar;
    }
    
    for(var i = 0; i < listar.length ; i++){
        switch(listar[i].estado){
            case "aprobado":
                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha_aporte}</p>
                        </div>

                        <div class="separador"></div> 

                        <div class="nombreTitular">
                            <p>${listar[i].adulto.nombre.toUpperCase()} ${listar[i].adulto.primer_apellido.toUpperCase()} ${listar[i].adulto.segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].cant_horas}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">Aprobado</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_aprobado" onclick="mostrarDatosAporte(${listar[i].id_aporte})">
                            Ver solicitud
                        </button>

                    </div>
                `);
                break;
            case "rechazado":
                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha_aporte}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="nombreTitular">
                            <p>${listar[i].adulto.nombre.toUpperCase()} ${listar[i].adulto.primer_apellido.toUpperCase()} ${listar[i].adulto.segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].cant_horas}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">Rechazado</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_rechazado" onclick="mostrarDatosAporte(${listar[i].id_aporte})">
                            Ver solicitud
                        </button>

                    </div>
                `);
                break;

            case "pendiente":
                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha_aporte}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="nombreTitular">
                            <p>${listar[i].adulto.nombre.toUpperCase()} ${listar[i].adulto.primer_apellido.toUpperCase()} ${listar[i].adulto.segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].cant_horas}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">Pendiente</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_pendiente" onclick="mostrarDatosAporte(${listar[i].id_aporte})">
                            Evaluar
                        </button>

                    </div>
                `);
                break;

            case "en_votacion":

            //existen 2 estados falta diferenciarlos

                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha_aporte}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="nombreTitular">
                            <p>${listar[i].nombre.toUpperCase()} ${listar[i].primer_apellido.toUpperCase()} ${listar[i].segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].cant_horas}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">En votacion ${listar[i].evaluaciones}/${listar[i].admins}</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_en_votacion" onclick="mostrarDatosAporte(${listar[i].id_aporte})">
                            Votar / Voto emitido
                        </button>

                    </div>
                `);
                break;
        }
    }
}

