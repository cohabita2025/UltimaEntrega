<?php
// Depuración activa
error_reporting(E_ALL);
ini_set("display_errors", 1);

// IDs de ejemplo
$idFamilia = 123;
$cedulas = ['11111111','22222222','33333333'];

// Carpeta base de pruebas
$baseDir = __DIR__ . '/../archivos/familias/'; // ajustá si es necesario

// Crear carpeta de la familia
$dirFamilia = $baseDir . $idFamilia . '/';
if (!file_exists($dirFamilia)) {
    if (!mkdir($dirFamilia, 0777, true)) {
        die("Error creando carpeta de la familia: $dirFamilia");
    } else {
        echo "Carpeta de familia creada: $dirFamilia<br>";
    }
}

// Crear carpeta de cada persona
foreach ($cedulas as $cedula) {
    $dirPersona = $dirFamilia . $cedula . '/';
    if (!file_exists($dirPersona)) {
        if (!mkdir($dirPersona, 0777, true)) {
            echo "Error creando carpeta de persona: $dirPersona<br>";
        } else {
            echo "Carpeta de persona creada: $dirPersona<br>";
        }
    }
}

echo "<br>✅ Test completado";
?>
