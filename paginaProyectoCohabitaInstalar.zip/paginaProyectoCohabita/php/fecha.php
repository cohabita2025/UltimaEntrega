<?php
require_once 'config.php';

// En config.php
date_default_timezone_set('America/Montevideo');

echo json_encode(['hoy' => date('Y-m-d')]);
?>
