<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

if (!isset($_GET['id_familia'])) {
    http_response_code(400);
    echo json_encode(["error" => "Falta el parámetro id_familia"]);
    exit;
}

$idFamilia = intval($_GET['id_familia']);

// 1️⃣ Traer todas las cédulas de la familia
$stmt = $mysqli->prepare("
    SELECT cedula_persona
    FROM persona_integra_familia
    WHERE id_familia = ?
");
$stmt->bind_param("i", $idFamilia);
$stmt->execute();
$resultCedulas = $stmt->get_result();

$cedulas = [];
while ($row = $resultCedulas->fetch_assoc()) {
    $cedulas[] = $row['cedula_persona'];
}
$stmt->close();

// Si la familia no tiene personas → devolver vacío
if (empty($cedulas)) {
    echo json_encode([], JSON_PRETTY_PRINT);
    exit;
}

// 2️⃣ Convertir cédulas en lista para SQL IN (?,?,?,...)
$placeholders = implode(',', array_fill(0, count($cedulas), '?'));

$query = "
    SELECT * 
    FROM horas_semanales
    WHERE cedula_adulto IN ($placeholders)
";

$stmt = $mysqli->prepare($query);
$stmt->bind_param(str_repeat('s', count($cedulas)), ...$cedulas);
$stmt->execute();
$resultAportes = $stmt->get_result();

$aportes = [];

while ($aporte = $resultAportes->fetch_assoc()) {
    $idAporte = $aporte['id_aporte'];
    $cedulaAdulto = $aporte['cedula_adulto'];

    // 3️⃣ Buscar datos del adulto
    $stmtAdulto = $mysqli->prepare("
        SELECT p.cedula, p.nombre, p.primer_apellido, p.segundo_apellido, 
               a.correo, a.telefono, f.rol AS rol_familia
        FROM persona p
        LEFT JOIN adulto a ON a.cedula = p.cedula
        LEFT JOIN persona_integra_familia f ON f.cedula_persona = p.cedula
        WHERE p.cedula = ?
        LIMIT 1
    ");
    $stmtAdulto->bind_param("s", $cedulaAdulto);
    $stmtAdulto->execute();
    $adulto = $stmtAdulto->get_result()->fetch_assoc();
    $stmtAdulto->close();

    // 4️⃣ Contar cuántos admins evaluaron el aporte
    $stmtEval = $mysqli->prepare("
        SELECT COUNT(*) AS total
        FROM admin_valida_horas_semanales
        WHERE id_aporte = ?
    ");
    $stmtEval->bind_param("i", $idAporte);
    $stmtEval->execute();
    $evaluaciones = $stmtEval->get_result()->fetch_assoc()['total'];
    $stmtEval->close();

    // 5️⃣ Total de admins del sistema
    $resultAdmins = $mysqli->query("SELECT COUNT(*) AS total FROM adulto");
    $cantAdmins = $resultAdmins->fetch_assoc()['total'];

    // 6️⃣ Armar el objeto
    $aportes[] = [
        'id_aporte'       => $idAporte,
        'fecha_aporte'    => $aporte['fecha_aporte'],
        'tarea'           => $aporte['tarea'],
        'cedula_adulto'   => $cedulaAdulto,
        'estado'          => $aporte['estado'],
        'cant_horas'      => (int)$aporte['cant_horas'],
        'fecha_horas'     => $aporte['fecha_horas'],
        'adulto'          => $adulto,
        'evaluaciones'    => (int)$evaluaciones,
        'total_admins'    => (int)$cantAdmins
    ];
}

header('Content-Type: application/json');
echo json_encode($aportes, JSON_PRETTY_PRINT);
?>
