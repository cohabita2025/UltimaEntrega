<?php
header('Content-Type: application/json; charset=utf-8');

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

// Validar método
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// --- Obtener datos ---
$monto = $_POST['monto'] ?? null;
$fecha = $_POST['fecha'] ?? null;
$fecha_envio = $_POST['fecha_envio_comprobante'] ?? null;
$cedula_emisor = $_POST['cedula_emisor'] ?? null;
$cedula_titular = $_POST['cedula_titular'] ?? null;

// Validaciones básicas
if (!$monto || !$fecha || !$fecha_envio || !$cedula_emisor || !$cedula_titular || !isset($_FILES['archivo_comprobante'])) {
    echo json_encode(['error' => 'Faltan datos']);
    exit;
}

// --- Insertar registro inicial ---
$estado = "pendiente"; // Por defecto
$stmt = $conn->prepare("INSERT INTO comprobante_pago (estado, monto, fecha, fecha_envio_comprobante, archivo_comprobante, cedula_emisor, cedula_titular) 
                        VALUES (?, ?, ?, ?, '', ?, ?)");
$stmt->bind_param("sdssss", $estado, $monto, $fecha, $fecha_envio, $cedula_emisor, $cedula_titular);

if (!$stmt->execute()) {
    echo json_encode(['error' => 'Error al insertar: ' . $stmt->error]);
    exit;
}

$id = $stmt->insert_id;
$stmt->close();

// --- Manejo del archivo ---
$uploadDir = "../archivos/comprobantes de pago/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$ext = pathinfo($_FILES['archivo_comprobante']['name'], PATHINFO_EXTENSION);
$filename = "comprobante_de_pago_" . $id . "." . $ext;
$destino = $uploadDir . $filename;

if (!move_uploaded_file($_FILES['archivo_comprobante']['tmp_name'], $destino)) {
    echo json_encode(['error' => 'Error al mover el archivo']);
    exit;
}

// --- Actualizar nombre del archivo en la DB ---
$update = $conn->prepare("UPDATE comprobante_pago SET archivo_comprobante = ? WHERE id = ?");
$update->bind_param("si", $filename, $id);
$update->execute();
$update->close();

$conn->close();

echo json_encode(['success' => true, 'mensaje' => 'Comprobante registrado con éxito', 'id' => $id, 'archivo' => $filename]);
?>
