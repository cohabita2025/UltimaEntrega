<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

if (!isset($_GET["id_familia"])) {
    http_response_code(400);
    echo json_encode(["error" => "Falta id_familia"]);
    exit;
}

$idFamilia = intval($_GET["id_familia"]);
$comprobantes = [];

/* 1️⃣ Obtener todas las cédulas de esa familia */
$stmt = $mysqli->prepare("
    SELECT cedula_persona 
    FROM persona_integra_familia 
    WHERE id_familia = ?
");
$stmt->bind_param("i", $idFamilia);
$stmt->execute();
$resCedulas = $stmt->get_result();

$cedulas = [];
while ($row = $resCedulas->fetch_assoc()) {
    $cedulas[] = $row["cedula_persona"];
}
$stmt->close();

if (empty($cedulas)) {
    echo json_encode([]); 
    exit;
}

// Preparar IN (?,?,?,...)
$placeholders = implode(",", array_fill(0, count($cedulas), "?"));

/* 2️⃣ Buscar comprobantes de pago de cualquier miembro de la familia */
$query = "
    SELECT * 
    FROM comprobante_pago
    WHERE cedula_titular IN ($placeholders)
";

$stmt = $mysqli->prepare($query);
$stmt->bind_param(str_repeat("s", count($cedulas)), ...$cedulas);
$stmt->execute();
$result = $stmt->get_result();

/* 3️⃣ Procesar cada comprobante */
while ($comprobante = $result->fetch_assoc()) {
    $idComprobante = $comprobante['id'];
    $cedulaTitular = $comprobante['cedula_titular'];

    // 4️⃣ Datos del adulto
    $stmtAdulto = $mysqli->prepare("
        SELECT p.cedula, p.nombre, p.primer_apellido, p.segundo_apellido,
               a.correo, a.telefono, f.rol AS rol_familia
        FROM persona p
        LEFT JOIN adulto a ON a.cedula = p.cedula
        LEFT JOIN persona_integra_familia f ON f.cedula_persona = p.cedula
        WHERE p.cedula = ?
        LIMIT 1
    ");
    $stmtAdulto->bind_param("s", $cedulaTitular);
    $stmtAdulto->execute();
    $adulto = $stmtAdulto->get_result()->fetch_assoc();
    $stmtAdulto->close();

    // 5️⃣ Contar evaluaciones
    $stmtEval = $mysqli->prepare("
        SELECT COUNT(*) AS total
        FROM admin_valida_comprobante_pago
        WHERE id_comprobante_pago = ?
    ");
    $stmtEval->bind_param("i", $idComprobante);
    $stmtEval->execute();
    $evaluaciones = $stmtEval->get_result()->fetch_assoc()['total'];
    $stmtEval->close();

    // 6️⃣ Contar admins
    $resultAdmins = $mysqli->query("SELECT COUNT(*) AS total FROM adulto WHERE rol = 'admin'");
    $cantAdmins = $resultAdmins->fetch_assoc()['total'];

    // 7️⃣ HTML final
    $comprobantes[] = [
        'id'              => $idComprobante,
        'estado'          => $comprobante['estado'],
        'monto'           => (float)$comprobante['monto'],
        'fecha'           => $comprobante['fecha'],
        'fecha_envio'     => $comprobante['fecha_envio_comprobante'],
        'archivo'         => $comprobante['archivo_comprobante'],
        'cedula_emisor'   => $comprobante['cedula_emisor'],
        'cedula_titular'  => $cedulaTitular,
        'adulto'          => $adulto,
        'evaluaciones'    => (int)$evaluaciones,
        'total_admins'    => (int)$cantAdmins
    ];
}

header('Content-Type: application/json');
echo json_encode($comprobantes, JSON_PRETTY_PRINT);
?>
