<?php
error_reporting(E_ALL);
ini_set('display_errors',1);

require_once "config.php"; // ruta según tu proyecto

if (!$conn) {
    echo json_encode(['ok'=>false,'msg'=>'$conn es null']);
    exit;
}

if ($conn->connect_error) {
    echo json_encode(['ok'=>false,'msg'=>'Connect error: '.$conn->connect_error]);
    exit;
}

$res = $conn->query("SHOW TABLES");
$tables = [];
if ($res) {
    while($r = $res->fetch_row()) $tables[] = $r[0];
}
echo json_encode(['ok'=>true,'tables'=>$tables], JSON_PRETTY_PRINT);
