<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

if (!isset($_GET["id_familia"])) {
    http_response_code(400);
    echo json_encode(["error" => "Falta id_familia"]);
    exit;
}

$idFamilia = intval($_GET["id_familia"]);

// 1️⃣ Obtener todas las cédulas de la familia
$stmt = $mysqli->prepare("
    SELECT cedula_persona
    FROM persona_integra_familia
    WHERE id_familia = ?
");
$stmt->bind_param("i", $idFamilia);
$stmt->execute();
$resCedulas = $stmt->get_result();

$cedulas = [];
while ($row = $resCedulas->fetch_assoc()) {
    $cedulas[] = $row["cedula_persona"];
}
$stmt->close();

if (empty($cedulas)) {
    echo json_encode([]);
    exit;
}

// Crear placeholders (?, ?, ?, ...)
$placeholders = implode(",", array_fill(0, count($cedulas), "?"));

// 2️⃣ Traer solicitudes de esas cédulas
$sql = "
    SELECT 
        s.id,
        s.fecha,
        s.motivo,
        s.estado,
        s.pruebas,
        s.fecha_inicio,
        s.fecha_fin,
        p.nombre,
        p.primer_apellido,
        p.segundo_apellido,
        s.cedula_adulto
    FROM solicitud_exoneracion_horas s
    LEFT JOIN adulto a ON a.cedula = s.cedula_adulto
    LEFT JOIN persona p ON p.cedula = a.cedula
    WHERE s.cedula_adulto IN ($placeholders)
";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param(str_repeat("s", count($cedulas)), ...$cedulas);
$stmt->execute();
$result = $stmt->get_result();

$solicitudes = [];

while ($row = $result->fetch_assoc()) {

    // 3️⃣ Calcular cantidad de horas según semanas completas
    $fecha_inicio = new DateTime($row['fecha_inicio']);
    $fecha_fin = new DateTime($row['fecha_fin']);

    $dias = $fecha_inicio->diff($fecha_fin)->days + 1;  // incluir ambos días
    $semanas = ceil($dias / 7); // semanas completas
    $row['cant_horas'] = $semanas * 21; // 21 horas por semana

    $solicitudes[] = $row;
}

header('Content-Type: application/json');
echo json_encode($solicitudes, JSON_PRETTY_PRINT);
?>
