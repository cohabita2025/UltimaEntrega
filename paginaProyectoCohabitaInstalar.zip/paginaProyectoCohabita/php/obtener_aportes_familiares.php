<?php
header('Content-Type: application/json; charset=utf-8');
require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}
$id_familia = $_GET['id_familia'] ?? $_POST['id_familia'] ?? null;
if (!$id_familia) {
    echo json_encode(["error" => "Falta id_familia"]);
    exit;
}

/* 🔹 HORAS SEMANALES APROBADAS */
$sql_horas = "
SELECT 
    'horas' AS tipo,
    p.nombre,
    p.primer_apellido,
    p.segundo_apellido,
    hs.fecha_aporte AS fecha,
    hs.cant_horas
FROM horas_semanales hs
JOIN adulto a ON hs.cedula_adulto = a.cedula
JOIN persona p ON p.cedula = a.cedula
WHERE p.id_familia = ? AND hs.estado = 'aprobado'
";

/* 🔹 COMPROBANTES DE PAGO APROBADOS */
$sql_pagos = "
SELECT 
    'pago' AS tipo,
    p.nombre,
    p.primer_apellido,
    p.segundo_apellido,
    cp.fecha AS fecha,
    cp.monto
FROM comprobante_pago cp
JOIN adulto a ON cp.cedula_titular = a.cedula
JOIN persona p ON p.cedula = a.cedula
WHERE p.id_familia = ? AND cp.estado = 'aprobado'
";

/* 🔹 SOLICITUDES DE EXONERACIÓN HORAS APROBADAS */
$sql_exoneraciones = "
SELECT 
    'exoneracion' AS tipo,
    p.nombre,
    p.primer_apellido,
    p.segundo_apellido,
    se.fecha AS fecha,
    se.fecha_inicio,
    se.fecha_fin
FROM solicitud_exoneracion_horas se
JOIN adulto a ON se.cedula_adulto = a.cedula
JOIN persona p ON p.cedula = a.cedula
WHERE p.id_familia = ? AND se.estado = 'aprobado'
";

/* 🔹 Ejecutar todas las consultas */
function obtenerDatos($conn, $sql, $id_familia) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_familia);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

$horas = obtenerDatos($conn, $sql_horas, $id_familia);
$pagos = obtenerDatos($conn, $sql_pagos, $id_familia);
$exoneraciones = obtenerDatos($conn, $sql_exoneraciones, $id_familia);

/* 🔹 Unir todos los resultados */
$datos = array_merge($horas, $pagos, $exoneraciones);

/* 🔹 Ordenar por fecha descendente */
usort($datos, function ($a, $b) {
    return strtotime($b['fecha']) - strtotime($a['fecha']);
});

/* 🔹 Enviar JSON */
echo json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
