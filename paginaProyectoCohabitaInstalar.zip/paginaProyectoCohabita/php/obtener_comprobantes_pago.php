<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}
$comprobantes = [];

// 1️⃣ Traer todos los comprobantes de pago
$result = $mysqli->query("SELECT * FROM comprobante_pago");

while ($comprobante = $result->fetch_assoc()) {
    $idComprobante = $comprobante['id'];
    $cedulaTitular = $comprobante['cedula_titular'];

    // 2️⃣ Buscar los datos del adulto que registró el comprobante
    $stmt = $mysqli->prepare("
        SELECT p.cedula, p.nombre, p.primer_apellido, p.segundo_apellido, 
               a.correo, a.telefono, f.rol AS rol_familia
        FROM persona p
        LEFT JOIN adulto a ON a.cedula = p.cedula
        LEFT JOIN persona_integra_familia f ON f.cedula_persona = p.cedula
        WHERE p.cedula = ?
        LIMIT 1
    ");
    $stmt->bind_param("s", $cedulaTitular);
    $stmt->execute();
    $adulto = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // 3️⃣ Contar cuántos admins evaluaron este comprobante
    $stmtEval = $mysqli->prepare("
        SELECT COUNT(*) AS total
        FROM admin_valida_comprobante_pago
        WHERE id_comprobante_pago = ?
    ");
    $stmtEval->bind_param("i", $idComprobante);
    $stmtEval->execute();
    $evaluaciones = $stmtEval->get_result()->fetch_assoc()['total'];
    $stmtEval->close();

    // 4️⃣ Contar cuántos adultos existen en total
    $resultAdmins = $mysqli->query("SELECT COUNT(*) AS total FROM adulto");
    $cantAdmins = $resultAdmins->fetch_assoc()['total'];

    // 5️⃣ Crear objeto del comprobante con adulto + evaluaciones + total de admins
    $comprobantes[] = [
        'id'              => $idComprobante,
        'estado'          => $comprobante['estado'],
        'monto'           => (float)$comprobante['monto'],
        'fecha'           => $comprobante['fecha'],
        'fecha_envio'     => $comprobante['fecha_envio_comprobante'],
        'archivo'         => $comprobante['archivo_comprobante'],
        'cedula_emisor'   => $comprobante['cedula_emisor'],
        'cedula_titular'  => $cedulaTitular,
        'adulto'          => $adulto, // puede ser null
        'evaluaciones'    => (int)$evaluaciones,
        'total_admins'    => (int)$cantAdmins
    ];
}

// 6️⃣ Mostrar resultado como JSON
header('Content-Type: application/json');
echo json_encode($comprobantes, JSON_PRETTY_PRINT);
?>
