<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}
// Traer solicitudes + solo nombre y apellidos del adulto
$sql = "
    SELECT 
        s.id,
        s.fecha,
        s.motivo,
        s.estado,
        s.pruebas,
        s.fecha_inicio,
        s.fecha_fin,
        a.nombre,
        a.primer_apellido,
        a.segundo_apellido
    FROM solicitud_exoneracion_horas s
    LEFT JOIN adulto ad ON ad.cedula = s.cedula_adulto
    LEFT JOIN persona a ON a.cedula = ad.cedula
";

$result = $mysqli->query($sql);
$solicitudes = [];

while ($row = $result->fetch_assoc()) {
    // Calcular cantidad de horas según semanas completas
    $fecha_inicio = new DateTime($row['fecha_inicio']);
    $fecha_fin = new DateTime($row['fecha_fin']);

    // Diferencia en días + 1 para incluir ambos extremos
    $dias = $fecha_inicio->diff($fecha_fin)->days + 1;

    // Calcular semanas completas redondeando hacia arriba
    $semanas = ceil($dias / 7);

    // Cantidad de horas: 21 por semana
    $row['cant_horas'] = $semanas * 21;

    $solicitudes[] = $row;
}

header('Content-Type: application/json');
echo json_encode($solicitudes, JSON_PRETTY_PRINT);
?>
