<?php
header('Content-Type: application/json');

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Error de conexión a la base de datos"]);
    exit;
}

// --- RECIBIR ID FAMILIA ---
$id_familia = isset($_GET['id_familia']) ? intval($_GET['id_familia']) : 0;
if ($id_familia <= 0) {
    echo json_encode(['error' => 'ID familia inválido']);
    exit;
}

// --- OBTENER CÉDULA DEL TITULAR ---
$sql_titular = "
    SELECT a.cedula, p.nombre, p.primer_apellido, p.segundo_apellido
    FROM persona p
    JOIN adulto a ON p.cedula = a.cedula
    WHERE p.id_familia = ? AND a.rol = 'titular'
    LIMIT 1
";
$stmt = $conn->prepare($sql_titular);
$stmt->bind_param("i", $id_familia);
$stmt->execute();
$result = $stmt->get_result();
$titular = $result->fetch_assoc();
$stmt->close();

if (!$titular) {
    echo json_encode(['error' => 'No se encontró titular para la familia']);
    exit;
}

// --- OBTENER COMPROBANTES DE PAGO APROBADOS DEL TITULAR ---
$sql_pagos = "
    SELECT *
    FROM comprobante_pago
    WHERE cedula_titular = ? AND estado = 'aprobado'
    ORDER BY fecha DESC
";
$stmt = $conn->prepare($sql_pagos);
$stmt->bind_param("s", $titular['cedula']);
$stmt->execute();
$result = $stmt->get_result();
$pagos = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// --- ULTIMA EVALUACION ---
$sql_eval = "
    SELECT aesr.fecha, aesr.id_admin AS admin, aesr.conclusion
    FROM admin_evalua_solicitud_registro aesr
    JOIN solicitud_registro sr ON aesr.id_solicitud_registro = sr.id
    WHERE sr.id_familia = ?
    ORDER BY aesr.fecha DESC
    LIMIT 1
";
$stmt = $conn->prepare($sql_eval);
$stmt->bind_param("i", $id_familia);
$stmt->execute();
$eval_result = $stmt->get_result();
$ultima_eval = $eval_result->fetch_assoc();
$stmt->close();

// --- SI NO HAY EVALUACION, TOMAR FECHA DE LA SOLICITUD ---
if (!$ultima_eval) {
    $sql_solicitud = "
        SELECT fecha 
        FROM solicitud_registro 
        WHERE id_familia = ? 
        ORDER BY fecha DESC 
        LIMIT 1
    ";
    $stmt = $conn->prepare($sql_solicitud);
    $stmt->bind_param("i", $id_familia);
    $stmt->execute();
    $res_sol = $stmt->get_result();
    $solicitud = $res_sol->fetch_assoc();
    $stmt->close();

    if ($solicitud) {
        $ultima_eval = [
            'fecha' => $solicitud['fecha'],
            'admin' => null,
            'conclusion' => null
        ];
    } else {
        $ultima_eval = null;
    }
}

// --- RESPUESTA JSON ---
echo json_encode([
    'titular' => $titular,
    'comprobantes_aprobados' => $pagos,
    'ultima_evaluacion' => $ultima_eval
], JSON_PRETTY_PRINT);

$conn->close();
?>
