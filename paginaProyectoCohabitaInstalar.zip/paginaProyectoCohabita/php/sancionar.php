<?php
header('Content-Type: application/json; charset=utf-8');
require_once "config.php";

$mysqli->set_charset("utf8mb4");

$response = [];

// ==============================
// 1️⃣ Recibir datos del formulario
// ==============================
$motivo = $_POST['motivo'] ?? null;
$fecha_inicio = $_POST['fecha_inicio'] ?? null;
$fecha_limite = $_POST['fecha_limite'] ?? null;
$cedula_admin = $_POST['cedula_admin'] ?? null;
$cedula_adulto = $_POST['cedula_adulto'] ?? null;
$id_familia = $_POST['id_familia'] ?? null;
$cant_horas = $_POST['cant_horas'] ?? 0;
$monto = $_POST['monto'] ?? 0;
$archivos = $_FILES['pruebas'] ?? null;

// --- Validación básica ---
if (!$motivo || !$fecha_inicio || !$fecha_limite || !$cedula_admin || (!$cedula_adulto && !$id_familia)) {
    echo json_encode([
        "status" => "error",
        "mensaje" => "Faltan datos obligatorios"
    ]);
    exit;
}

// ==============================
// 2️⃣ Insertar en la base de datos
// ==============================
$fechaActual = date("Y-m-d");

$stmt = $mysqli->prepare("
    INSERT INTO admin_sanciona_adulto 
    (id_admin, cedula_adulto, id_familia, cant_horas, monto, fecha_inicio, fecha_limite, fecha, motivo, pruebas)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, '')
");

$stmt->bind_param(
    "ssiidssss",
    $cedula_admin,
    $cedula_adulto,
    $id_familia,
    $cant_horas,
    $monto,
    $fecha_inicio,
    $fecha_limite,
    $fechaActual,
    $motivo
);

if (!$stmt->execute()) {
    echo json_encode([
        "status" => "error",
        "mensaje" => "Error al insertar en DB: " . $stmt->error
    ]);
    exit;
}

$id_sancion = $mysqli->insert_id;
$response['id_sancion'] = $id_sancion;

// ==============================
// 3️⃣ Crear carpeta para las sanciones
// ==============================
$baseDir = __DIR__ . '/../archivos/sanciones/';
if (!file_exists($baseDir)) {
    mkdir($baseDir, 0777, true);
}

// 🔹 Carpeta base de la familia
$dirFamilia = $baseDir . "familia_" . $id_familia . "/";
if (!file_exists($dirFamilia)) {
    mkdir($dirFamilia, 0777, true);
}

if ($cedula_adulto) {
    // 🧍‍♂️ Sanción a un adulto
    $dirAdulto = $dirFamilia . $cedula_adulto . "/";
    if (!file_exists($dirAdulto)) {
        mkdir($dirAdulto, 0777, true);
    }
    $dirSancion = $dirAdulto . "sancion_" . $id_sancion . "/";
} else {
    // 👨‍👩‍👧‍👦 Sanción a la familia
    $dirSancion = $dirFamilia . "sancion_" . $id_sancion . "/";
}

if (!mkdir($dirSancion, 0777, true)) {
    echo json_encode([
        "status" => "error",
        "mensaje" => "No se pudo crear la carpeta de la sanción"
    ]);
    exit;
}

// ==============================
// 4️⃣ Mover archivos adjuntos
// ==============================
$archivosGuardados = [];
if ($archivos && count($archivos['name']) > 0) {
    foreach ($archivos['tmp_name'] as $i => $tmpName) {
        if (file_exists($tmpName)) {
            $nombreDestino = basename($archivos['name'][$i]);
            if (move_uploaded_file($tmpName, $dirSancion . $nombreDestino)) {
                $archivosGuardados[] = $nombreDestino;
            }
        }
    }
}

// ==============================
// 5️⃣ Actualizar campo "pruebas"
// ==============================
$nombreCarpeta = "sancion_" . $id_sancion;
$stmt = $mysqli->prepare("UPDATE admin_sanciona_adulto SET pruebas=? WHERE id=?");
$stmt->bind_param("si", $nombreCarpeta, $id_sancion);
$stmt->execute();

// ==============================
// 6️⃣ Respuesta final
// ==============================
$response['status'] = "ok";
$response['carpeta_sancion'] = $nombreCarpeta;
$response['archivos_guardados'] = $archivosGuardados;
$response['mensaje'] = "Sanción registrada correctamente";

echo json_encode($response, JSON_PRETTY_PRINT);
?>
