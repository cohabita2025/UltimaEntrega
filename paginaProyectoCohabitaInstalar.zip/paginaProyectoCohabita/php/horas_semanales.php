<?php
header('Content-Type: application/json; charset=utf-8');

// Datos de conexión a la base
require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

// Recibir datos del POST
$fecha_aporte = $_POST['fecha_aporte'] ?? null;
$tarea = $_POST['tarea'] ?? null;
$cedula_adulto = $_POST['cedula_adulto'] ?? null;
$cant_horas = $_POST['cant_horas'] ?? null;
$fecha_horas = $_POST['fecha_horas'] ?? null;

if (!$fecha_aporte || !$tarea || !$cedula_adulto || !$cant_horas || !$fecha_horas) {
    echo json_encode(['error' => 'Faltan datos obligatorios'], JSON_UNESCAPED_UNICODE);
    exit;
}

// Insertar en la base de datos
$stmt = $conn->prepare("INSERT INTO horas_semanales (fecha_aporte, tarea, cedula_adulto, estado, cant_horas, fecha_horas) VALUES (?, ?, ?, 'pendiente', ?, ?)");
$stmt->bind_param("sssds", $fecha_aporte, $tarea, $cedula_adulto, $cant_horas, $fecha_horas);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'id_aporte' => $stmt->insert_id], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['error' => 'Error al insertar: ' . $stmt->error], JSON_UNESCAPED_UNICODE);
}

$stmt->close();
$conn->close();
?>
