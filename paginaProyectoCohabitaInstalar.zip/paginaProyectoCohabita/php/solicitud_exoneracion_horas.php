<?php
header('Content-Type: application/json; charset=utf-8');

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

$mysqli->set_charset("utf8mb4");

$response = [];

// --- DEBUG: mostrar lo que llega ---
error_log("POST:");
error_log(print_r($_POST, true));
error_log("FILES:");
error_log(print_r($_FILES, true));

// 1️⃣ Recibir datos y archivos
$fecha_inicio = $_POST['fecha_inicio'] ?? null;
$fecha_fin = $_POST['fecha_fin'] ?? null;
$motivo = $_POST['motivo'] ?? null;
$cedula_adulto = $_POST['cedula_adulto'] ?? null;
$archivos = $_FILES['pruebas'] ?? null;

if(!$fecha_inicio || !$fecha_fin || !$motivo || !$cedula_adulto || !$archivos || count($archivos['name'])===0){
    echo json_encode(["status"=>"error","mensaje"=>"Faltan datos o archivos"]);
    exit;
}

// 2️⃣ Insertar en DB con pruebas vacío temporalmente
$fechaActual = date("Y-m-d");
$stmt = $mysqli->prepare("
    INSERT INTO solicitud_exoneracion_horas 
    (fecha, motivo, estado, fecha_inicio, fecha_fin, cedula_adulto, pruebas) 
    VALUES (?, ?, 'pendiente', ?, ?, ?, '')
");
$stmt->bind_param("sssss", $fechaActual, $motivo, $fecha_inicio, $fecha_fin, $cedula_adulto);

if(!$stmt->execute()){
    echo json_encode(["status"=>"error","mensaje"=>"Error al insertar en DB: ".$stmt->error]);
    exit;
}
$id_solicitud = $mysqli->insert_id;
$response['id_solicitud'] = $id_solicitud;

// 3️⃣ Crear carpeta de la familia (usamos la cédula del adulto)
$baseDir = __DIR__ . '/../archivos/solicitudes de exoneracion de horas/';
$dirFamilia = $baseDir . $cedula_adulto . '/';
if(!file_exists($dirFamilia)){
    if(!mkdir($dirFamilia,0777,true)){
        echo json_encode(["status"=>"error","mensaje"=>"No se pudo crear la carpeta de la familia"]);
        exit;
    }
}

// 4️⃣ Crear carpeta de la solicitud
$dirSolicitud = $dirFamilia . "solicitud_exoneracion_horas_$id_solicitud/";
if(!mkdir($dirSolicitud,0777,true)){
    echo json_encode(["status"=>"error","mensaje"=>"No se pudo crear la carpeta de la solicitud"]);
    exit;
}

// 5️⃣ Mover archivos a la carpeta
$archivosGuardados = [];
foreach($archivos['tmp_name'] as $i => $tmpName){
    if(file_exists($tmpName)){
        $nombreDestino = $archivos['name'][$i];
        if(move_uploaded_file($tmpName, $dirSolicitud . $nombreDestino)){
            $archivosGuardados[] = $nombreDestino;
        }
    }
}

// 6️⃣ Actualizar DB con el nombre de la carpeta de la solicitud
$nombreCarpetaSolicitud = "solicitud_exoneracion_horas_$id_solicitud";
$stmt = $mysqli->prepare("UPDATE solicitud_exoneracion_horas SET pruebas=? WHERE id=?");
$stmt->bind_param("si", $nombreCarpetaSolicitud, $id_solicitud);

if(!$stmt->execute()){
    echo json_encode(["status"=>"error","mensaje"=>"Error al actualizar DB: ".$stmt->error]);
    exit;
}

// 7️⃣ Respuesta JSON final
$response['status'] = "ok";
$response['carpeta_solicitud'] = $nombreCarpetaSolicitud;
$response['archivos_guardados'] = $archivosGuardados;
$response['mensaje'] = "Solicitud de exoneración de horas creada correctamente";

echo json_encode($response, JSON_PRETTY_PRINT);
?>
