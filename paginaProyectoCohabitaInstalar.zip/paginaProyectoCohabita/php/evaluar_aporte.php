<?php
// --- DATOS DE CONEXIÓN ---
require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

// Validar POST y parámetros
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405); // Método no permitido
    exit;
}

$id_aporte = $_POST['id_aporte'] ?? null;
$id_admin = $_POST['id_admin'] ?? null;
$conclusion = $_POST['conclusion'] ?? null;
$razon = $_POST['razon_conclusion'] ?? null;

if (!$id_aporte || !$id_admin || !$conclusion || !$razon) {
    http_response_code(400); // Bad request
    exit;
}

$id_aporte = intval($id_aporte);

// 1️⃣ Actualizar estado de horas_semanales
$update = $conn->prepare("UPDATE horas_semanales SET estado = ? WHERE id_aporte = ?");
$update->bind_param("si", $conclusion, $id_aporte);
$update->execute();
$update->close();

// 2️⃣ Insertar validación del admin
$insert = $conn->prepare("
    INSERT INTO admin_valida_horas_semanales 
    (id_aporte, id_admin, fecha, conclusion, razon_conclusion)
    VALUES (?, ?, CURDATE(), ?, ?)
");
$insert->bind_param("isss", $id_aporte, $id_admin, $conclusion, $razon);
$insert->execute();
$insert->close();

$conn->close();

// ✅ Todo salió bien, no devolvemos JSON
http_response_code(200);
exit;
?>
