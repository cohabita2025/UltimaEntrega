<?php
header('Content-Type: application/json; charset=utf-8');
require_once "config.php";

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Error en la conexión a la base de datos']);
    exit;
}

$id_familia = isset($_POST['id_familia']) ? intval($_POST['id_familia']) : 0;

if ($id_familia <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'ID de familia inválido']);
    exit;
}

$sql = "
    SELECT p.cedula, p.nombre, p.primer_apellido, p.segundo_apellido
    FROM persona p
    INNER JOIN adulto a ON p.cedula = a.cedula
    WHERE p.id_familia = ?
      AND (a.rol = 'titular' OR a.rol LIKE '%titular%')
    LIMIT 1
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => 'Error preparando la consulta']);
    exit;
}

$stmt->bind_param("i", $id_familia);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $titular = $result->fetch_assoc();
    echo json_encode($titular, JSON_UNESCAPED_UNICODE);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Familiar no encontrado']);
}

$stmt->close();
$conn->close();
?>
