<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

// Arreglo final
$solicitudes = [];

// 1️⃣ Traer todas las solicitudes de registro
$result = $mysqli->query("SELECT * FROM solicitud_registro");

while ($sol = $result->fetch_assoc()) {
    $idSolicitud = $sol['id'];
    $idFamilia = $sol['id_familia'];

    // 2️⃣ Buscar el titular de la familia
    $stmt = $mysqli->prepare("
        SELECT a.cedula, p.nombre, p.primer_apellido, p.segundo_apellido, a.correo, a.telefono
        FROM adulto a
        INNER JOIN persona p ON a.cedula = p.cedula
        WHERE a.rol = 'titular' AND a.cedula IN (
            SELECT cedula_persona FROM persona_integra_familia WHERE id_familia = ?
        )
        LIMIT 1
    ");
    $stmt->bind_param("i", $idFamilia);
    $stmt->execute();
    $titular = $stmt->get_result()->fetch_assoc();

    // 3️⃣ Contar cuántos admin evaluaron esta solicitud
    $stmtEval = $mysqli->prepare("
        SELECT COUNT(*) AS total
        FROM admin_evalua_solicitud_registro
        WHERE id_solicitud_registro = ?
    ");
    $stmtEval->bind_param("i", $idSolicitud);
    $stmtEval->execute();
    $evaluaciones = $stmtEval->get_result()->fetch_assoc()['total'];

    // 4️⃣ Contar cuántos familiares tiene la familia
    $stmtFam = $mysqli->prepare("
        SELECT COUNT(*) AS total
        FROM persona_integra_familia
        WHERE id_familia = ?
    ");
    $stmtFam->bind_param("i", $idFamilia);
    $stmtFam->execute();
    $cantFamiliares = $stmtFam->get_result()->fetch_assoc()['total'];

    // 5️⃣ Contar cuántos adultos tienen el rol 'admin'
    $resultAdmins = $mysqli->query("
        SELECT COUNT(*) AS total
        FROM adulto
        WHERE rol = 'admin'
    ");
    $cantAdmins = $resultAdmins->fetch_assoc()['total'];

    // 6️⃣ Crear objeto de solicitud con titular + evaluaciones + familiares + admins
    $solicitudes[] = [
        'id_solicitud'   => $idSolicitud,
        'fecha'          => $sol['fecha'],
        'estado'         => $sol['estado'],
        'id_familia'     => $idFamilia,
        'titular'        => $titular, // puede ser null
        'evaluaciones'   => (int)$evaluaciones,
        'cant_familiares'=> (int)$cantFamiliares,
        'admins'         => (int)$cantAdmins
    ];
}

// 7️⃣ Mostrar resultado como JSON
header('Content-Type: application/json');
echo json_encode($solicitudes, JSON_PRETTY_PRINT);
?>
