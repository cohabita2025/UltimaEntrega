<?php
header('Content-Type: application/json; charset=utf-8');
require_once "config.php"; // debe definir $conn (mysqli)

// ----------------- helpers -----------------
function dias_inclusive(DateTime $a, DateTime $b) {
    if ($a > $b) return 0;
    $diff = $a->diff($b);
    return (int)$diff->days + 1;
}

function overlap_range_days(DateTime $start1, DateTime $end1, DateTime $start2, DateTime $end2) {
    $s = $start1 > $start2 ? $start1 : $start2;
    $e = $end1 < $end2 ? $end1 : $end2;
    if ($s > $e) return 0;
    return dias_inclusive($s, $e);
}

function respond_error($msg, $code = 400) {
    http_response_code($code);
    echo json_encode(["ok" => false, "error" => $msg], JSON_PRETTY_PRINT);
    exit;
}

function sumar_aportes_en_rango($conn, $cedula_adulto, DateTime $inicio, DateTime $fin) {
    $inicioSQL = $inicio->format('Y-m-d') . " 00:00:00";
    $finSQL = $fin->format('Y-m-d') . " 23:59:59";
    $sql = "SELECT COALESCE(SUM(cant_horas),0) as suma 
            FROM horas_semanales 
            WHERE cedula_adulto = ? AND estado = 'aprobado' 
            AND fecha_horas >= ? AND fecha_horas <= ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return 0.0;
    $stmt->bind_param("sss", $cedula_adulto, $inicioSQL, $finSQL);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return floatval($r['suma'] ?? 0.0);
}

function sumar_exoneraciones_en_rango($conn, $cedula_adulto, DateTime $inicio, DateTime $fin) {
    $sql = "SELECT fecha_inicio, fecha_fin FROM solicitud_exoneracion_horas WHERE cedula_adulto = ? AND estado = 'aprobado'";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return 0.0;
    $stmt->bind_param("s", $cedula_adulto);
    $stmt->execute();
    $res = $stmt->get_result();
    $totalHoras = 0.0;
    while ($row = $res->fetch_assoc()) {
        try {
            $exInicio = new DateTime($row['fecha_inicio']);
            $exFin = new DateTime($row['fecha_fin']);
        } catch (Exception $e) { continue; }
        $dias = overlap_range_days($inicio, $fin, $exInicio, $exFin);
        if ($dias > 0) $totalHoras += $dias * 3.0;
    }
    $stmt->close();
    return $totalHoras;
}

function obtener_adultos_familia($conn, $id_familia) {
    $sql = "SELECT a.cedula FROM adulto a JOIN persona p ON a.cedula = p.cedula WHERE p.id_familia = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return [];
    $stmt->bind_param("i", $id_familia);
    $stmt->execute();
    $res = $stmt->get_result();
    $arr = [];
    while ($r = $res->fetch_assoc()) $arr[] = $r['cedula'];
    $stmt->close();
    return $arr;
}

function obtener_titular_familia($conn, $id_familia) {
    $sql = "SELECT a.cedula FROM adulto a JOIN persona p ON a.cedula = p.cedula WHERE p.id_familia = ? AND a.rol = 'titular' LIMIT 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return null;
    $stmt->bind_param("i", $id_familia);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $res['cedula'] ?? null;
}

function sumar_pagos_en_rango($conn, $cedula_titular, DateTime $inicio, DateTime $fin) {
    $inicioSQL = $inicio->format('Y-m-d') . " 00:00:00";
    $finSQL = $fin->format('Y-m-d') . " 23:59:59";
    $sql = "SELECT COALESCE(SUM(monto),0) as total FROM comprobante_pago 
            WHERE cedula_titular = ? AND estado = 'aprobado' AND fecha >= ? AND fecha <= ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return 0.0;
    $stmt->bind_param("sss", $cedula_titular, $inicioSQL, $finSQL);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return floatval($r['total'] ?? 0.0);
}

// ----------------- input -----------------
$id = isset($_POST['id']) ? intval($_POST['id']) : null;
if (!$id) respond_error("Falta id de sanción (POST 'id').");

// ----------------- obtener sanción -----------------
$sql = "SELECT * FROM admin_sanciona_adulto WHERE id = ? AND estado = 'activa' LIMIT 1";
$stmt = $conn->prepare($sql);
if (!$stmt) respond_error("Error prepare: " . $conn->error, 500);
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
if (!$res || $res->num_rows === 0) respond_error("Sanción no encontrada o no está activa.", 404);
$sancion = $res->fetch_assoc();
$stmt->close();

try {
    $fecha_inicio = new DateTime($sancion['fecha_inicio']);
    $fecha_limite = new DateTime($sancion['fecha_limite']);
} catch (Exception $e) {
    respond_error("Fechas de sanción inválidas.");
}

$cant_horas_sancion = floatval($sancion['cant_horas'] ?? 0);
$monto_sancion = floatval($sancion['monto'] ?? 0);
$tipo = !empty($sancion['cedula_adulto']) ? 'adulto' : 'familia';

$result = [
    "ok" => true,
    "id" => $id,
    "tipo" => $tipo,
    "pagada" => false,
    "detalle" => []
];

// ----------------- sanción a adulto -----------------
if ($tipo === 'adulto') {
    $ced = $sancion['cedula_adulto'];
    $aportes = sumar_aportes_en_rango($conn, $ced, $fecha_inicio, $fecha_limite);
    $horasExo = sumar_exoneraciones_en_rango($conn, $ced, $fecha_inicio, $fecha_limite);
    $diasPeriodo = dias_inclusive($fecha_inicio, $fecha_limite);
    $semanasPeriodo = (int) ceil($diasPeriodo / 7.0);
    $obligacion_base = 21 * $semanasPeriodo;
    $obligacion_effectiva = max(0.0, $obligacion_base - $horasExo);
    $horasSobrantes = max(0.0, $aportes - $obligacion_effectiva);
    $horas_realizadas = min($horasSobrantes, $cant_horas_sancion);
    $horas_faltantes = max(0.0, $cant_horas_sancion - $horas_realizadas);

    // pagos
    $sql_familia = "SELECT id_familia FROM persona p JOIN adulto a ON a.cedula = p.cedula WHERE a.cedula = ?";
    $stmt = $conn->prepare($sql_familia);
    $stmt->bind_param("s", $ced);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $id_familia = $res['id_familia'] ?? null;
    $cedula_titular = obtener_titular_familia($conn, $id_familia);
    $total_pagos_realizados = $cedula_titular ? sumar_pagos_en_rango($conn, $cedula_titular, $fecha_inicio, $fecha_limite) : 0.0;
    $pagos_suficientes = ($total_pagos_realizados >= $monto_sancion);

    $result['pagada'] = ($horas_realizadas >= $cant_horas_sancion) && $pagos_suficientes;
    $result['detalle'] = [
        "cedula_adulto" => $ced,
        "cant_horas_sancion" => $cant_horas_sancion,
        "monto_sancion" => $monto_sancion,
        "horas_realizadas" => $horas_realizadas,
        "horas_faltantes" => $horas_faltantes,
        "aportes" => $aportes,
        "horas_exoneracion" => $horasExo,
        "dias_periodo" => $diasPeriodo,
        "semanas_periodo" => $semanasPeriodo,
        "total_pagos_realizados" => $total_pagos_realizados,
        "pagos_suficientes" => $pagos_suficientes
    ];
    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

// ----------------- sanción a familia -----------------
if ($tipo === 'familia') {
    $id_familia = intval($sancion['id_familia']);
    $adultos = obtener_adultos_familia($conn, $id_familia);
    if (empty($adultos)) {
        $result['detalle'] = [
            "warning" => "Familia sin adultos registrados.",
            "cant_horas_sancion" => $cant_horas_sancion,
            "monto_sancion" => $monto_sancion,
            "horas_realizadas" => 0.0,
            "horas_faltantes" => $cant_horas_sancion,
            "total_pagos_realizados" => 0.0,
            "pagos_suficientes" => false
        ];
        echo json_encode($result, JSON_PRETTY_PRINT);
        exit;
    }

    $diasPeriodo = dias_inclusive($fecha_inicio, $fecha_limite);
    $semanasPeriodo = (int) ceil($diasPeriodo / 7.0);
    $obligacion_base_por_adulto = 21 * $semanasPeriodo;
    $suma_horas_sobrantes = 0.0;
    $detalle_adultos = [];

    $cedula_titular = obtener_titular_familia($conn, $id_familia);
    $total_pagos_realizados = $cedula_titular ? sumar_pagos_en_rango($conn, $cedula_titular, $fecha_inicio, $fecha_limite) : 0.0;
    $pagos_suficientes = ($total_pagos_realizados >= $monto_sancion);

    foreach ($adultos as $ced) {
        $aportes = sumar_aportes_en_rango($conn, $ced, $fecha_inicio, $fecha_limite);
        $horasExo = sumar_exoneraciones_en_rango($conn, $ced, $fecha_inicio, $fecha_limite);
        $horasSobrantesAdulto = max(0.0, $aportes + $horasExo - $obligacion_base_por_adulto);
        $suma_horas_sobrantes += $horasSobrantesAdulto;
        $detalle_adultos[] = [
            "cedula" => $ced,
            "aportes" => $aportes,
            "horas_exoneracion" => $horasExo,
            "obligacion_base" => $obligacion_base_por_adulto,
            "horas_sobrantes_adulto" => $horasSobrantesAdulto
        ];
    }

    $horas_realizadas = min($suma_horas_sobrantes, $cant_horas_sancion);
    $horas_faltantes = max(0.0, $cant_horas_sancion - $horas_realizadas);
    $result['pagada'] = ($horas_realizadas >= $cant_horas_sancion) && $pagos_suficientes;

    $result['detalle'] = [
        "id_familia" => $id_familia,
        "cant_horas_sancion" => $cant_horas_sancion,
        "monto_sancion" => $monto_sancion,
        "horas_realizadas" => $horas_realizadas,
        "horas_faltantes" => $horas_faltantes,
        "adultos" => $detalle_adultos,
        "suma_horas_sobrantes_adultos" => $suma_horas_sobrantes,
        "dias_periodo" => $diasPeriodo,
        "semanas_periodo" => $semanasPeriodo,
        "total_pagos_realizados" => $total_pagos_realizados,
        "pagos_suficientes" => $pagos_suficientes
    ];

    echo json_encode($result, JSON_PRETTY_PRINT);
    exit;
}

respond_error("Tipo no reconocido.");
