<?php
header('Content-Type: application/json; charset=utf-8');

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

$id_aporte = $_POST['id_aporte'] ?? null;
if (!$id_aporte) {
    echo json_encode(['error' => 'No se proporcionó id_aporte'], JSON_UNESCAPED_UNICODE);
    exit;
}

/* 1) Datos del aporte */
$stmt = $conn->prepare("
    SELECT id_aporte, fecha_aporte, tarea, cedula_adulto, estado, cant_horas, fecha_horas
    FROM horas_semanales
    WHERE id_aporte = ?
");
$stmt->bind_param("i", $id_aporte);
$stmt->execute();
$aporte = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$aporte) {
    echo json_encode(['error' => 'Aporte no encontrado'], JSON_UNESCAPED_UNICODE);
    exit;
}

/* 2) Datos del adulto/familia relacionado */
$stmt = $conn->prepare("
    SELECT 
        p.id_familia, 
        p.cedula, 
        p.nombre, 
        p.primer_apellido, 
        p.segundo_apellido, 
        p.genero, 
        p.fecha_nacimiento, 
        p.copia_cedula, 
        p.foto, 
        a.declaracion_no_vivienda, 
        a.recibo_sueldo, 
        a.correo, 
        a.telefono, 
        a.rol, 
        f.rol AS rol_familia
    FROM persona p
    LEFT JOIN adulto a ON a.cedula = p.cedula
    LEFT JOIN persona_integra_familia f ON f.cedula_persona = p.cedula AND f.id_familia = p.id_familia
    WHERE p.cedula = ?
");
$stmt->bind_param("s", $aporte['cedula_adulto']);
$stmt->execute();
$adulto = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* 3) Admins + evaluaciones de este aporte */
$stmt = $conn->prepare("
    SELECT
        a.cedula,
        p.nombre,
        p.primer_apellido,
        p.segundo_apellido,
        p.id_familia, 
        COALESCE(e.conclusion, 'pendiente') AS conclusion,
        e.razon_conclusion
    FROM adulto a
    JOIN persona p ON a.cedula = p.cedula
    LEFT JOIN admin_valida_horas_semanales e
        ON e.id_admin = a.cedula AND e.id_aporte = ?
    WHERE a.rol = 'admin'
");
$stmt->bind_param("i", $id_aporte);
$stmt->execute();
$evaluaciones = [];
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    if (empty($row['razon_conclusion'])) {
        $row['razon_conclusion'] = "";
    }
    $evaluaciones[] = $row;
}
$stmt->close();

/* 4) Respuesta final */
echo json_encode([
    'horas_semanales' => [
        'id_aporte' => $aporte['id_aporte'],
        'fecha_aporte' => $aporte['fecha_aporte'],
        'tarea' => $aporte['tarea'],
        'cedula' => $adulto['cedula'],
        'nombre' => $adulto['nombre'],
        'primer_apellido' => $adulto['primer_apellido'],
        'segundo_apellido' => $adulto['segundo_apellido'],
        'genero' => $adulto['genero'],
        'estado_horas' => $aporte['estado'],
        'cant_horas' => $aporte['cant_horas'],
        'fecha_horas' => $aporte['fecha_horas'],
        'correo' => $adulto['correo'],
        'telefono' => $adulto['telefono'],
        'rol' => $adulto['rol'],
        'id_familia' => $adulto['id_familia'] // ✅ agregado aquí
    ],
    'validaciones' => $evaluaciones
], JSON_UNESCAPED_UNICODE);

$conn->close();
