<?php
header("Content-Type: application/json; charset=UTF-8");

// Configuración de la BD
require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

// Validar si recibimos el parámetro
if (!isset($_GET['id_aporte'])) {
    echo json_encode(["error" => "Falta el parámetro id_aporte"]);
    exit;
}

$id_aporte = intval($_GET['id_aporte']);

// 1. Traer datos de horas_semanales + adulto
$sql = "
    SELECT hs.id_aporte, hs.fecha_aporte, hs.tarea, hs.estado AS estado_horas, 
           hs.cant_horas, hs.fecha_horas,
           a.cedula, a.correo, a.telefono, a.rol, p.id_familia,
           p.nombre, p.primer_apellido, p.segundo_apellido, p.genero
    FROM horas_semanales hs
    INNER JOIN adulto a ON hs.cedula_adulto = a.cedula
    INNER JOIN persona p ON a.cedula = p.cedula
    WHERE hs.id_aporte = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_aporte);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["error" => "No se encontró el aporte con id $id_aporte"]);
    exit;
}

$horas = $result->fetch_assoc();

// 2. Buscar validación de admin_valida_horas_semanales
$sqlVal = "
    SELECT avhs.id_admin, avhs.fecha, avhs.conclusion, avhs.razon_conclusion,
           p.nombre, p.primer_apellido, p.segundo_apellido
    FROM admin_valida_horas_semanales avhs
    INNER JOIN adulto a ON avhs.id_admin = a.cedula
    INNER JOIN persona p ON a.cedula = p.cedula
    WHERE avhs.id_aporte = ?
";

$stmt2 = $conn->prepare($sqlVal);
$stmt2->bind_param("i", $id_aporte);
$stmt2->execute();
$result2 = $stmt2->get_result();

$validaciones = [];
while ($row = $result2->fetch_assoc()) {
    $validaciones[] = $row;
}

// Armar respuesta final
$respuesta = [
    "horas_semanales" => $horas,
    "validaciones" => $validaciones
];

echo json_encode($respuesta, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
