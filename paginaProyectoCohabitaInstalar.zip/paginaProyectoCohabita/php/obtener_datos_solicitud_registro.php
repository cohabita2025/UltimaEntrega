<?php
header('Content-Type: application/json; charset=utf-8');

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}
$id_solicitud = $_POST['id_solicitud'] ?? null;
if (!$id_solicitud) {
    echo json_encode(['error' => 'No se proporcionó id_solicitud'], JSON_UNESCAPED_UNICODE);
    exit;
}

/* 1) Datos de la solicitud */
$stmt = $conn->prepare("
    SELECT id_familia, fecha, estado
    FROM solicitud_registro
    WHERE id = ?
");
$stmt->bind_param("i", $id_solicitud);
$stmt->execute();
$solicitud = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$solicitud) {
    echo json_encode(['error' => 'Solicitud no encontrada'], JSON_UNESCAPED_UNICODE);
    exit;
}

$id_familia = (int)$solicitud['id_familia'];

/* 2) Todas las personas de la familia (adultos y no adultos) */
$stmt = $conn->prepare("
    SELECT 
        p.id_familia, 
        p.cedula, 
        p.nombre, 
        p.primer_apellido, 
        p.segundo_apellido, 
        p.genero, 
        p.fecha_nacimiento, 
        p.copia_cedula, 
        p.foto, 
        a.declaracion_no_vivienda, 
        a.recibo_sueldo, 
        a.correo, 
        a.telefono, 
        a.rol, 
        f.rol AS rol_familia
    FROM persona p
    LEFT JOIN adulto a ON a.cedula = p.cedula
    LEFT JOIN persona_integra_familia f ON f.cedula_persona = p.cedula AND f.id_familia = p.id_familia
    WHERE p.id_familia = ?
");
$stmt->bind_param("i", $id_familia);
$stmt->execute();
$personas = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();


/* 3) Admins + evaluaciones (mezclados en una sola lista) */
$stmt = $conn->prepare("
    SELECT
        a.cedula,
        p.nombre,
        p.primer_apellido,
        p.segundo_apellido,
        COALESCE(e.conclusion, 'pendiente') AS conclusion,
        e.razon_conclusion
    FROM adulto a
    JOIN persona p ON a.cedula = p.cedula
    LEFT JOIN admin_evalua_solicitud_registro e
        ON e.id_admin = a.cedula AND e.id_solicitud_registro = ?
    WHERE a.rol = 'admin'
");
$stmt->bind_param("i", $id_solicitud);
$stmt->execute();
$evaluaciones = [];
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    // Asegurar que razon_conclusion exista siempre
    if (empty($row['razon_conclusion'])) {
        $row['razon_conclusion'] = "";
    }
    $evaluaciones[] = $row;
}
$stmt->close();

/* 4) Respuesta final */
echo json_encode([
    'solicitud' => $solicitud,
    'personas' => $personas,
    'evaluaciones' => $evaluaciones
], JSON_UNESCAPED_UNICODE);

$conn->close();
