<?php
$_POST['motivo'] = 'asdasd';
$_POST['fecha_limite'] = '2026-01-25';
$_POST['cedula_admin'] = '00000004';
$_POST['cedula_adulto'] = '00000011';
$_POST['id_familia'] = '5';
$_POST['cant_horas'] = '122';
$_POST['monto'] = '';

include "../php/sancionar.php";
