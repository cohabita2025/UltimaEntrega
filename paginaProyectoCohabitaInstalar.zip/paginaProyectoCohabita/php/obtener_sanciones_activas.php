<?php
header('Content-Type: application/json');
require_once "config.php";
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Error de conexión a la base de datos"]);
    exit;
}

$id_familia = $_POST['id_familia'] ?? $_GET['id_familia'] ?? null;

if (!$id_familia) {
    echo json_encode(["error" => "No se proporcionó id_familia"]);
    exit;
}

$id_familia = $conn->real_escape_string($id_familia);

try {
    $sql = "
        SELECT 
            a.id,
            a.id_admin,
            a.cedula_adulto,
            a.id_familia,
            a.cant_horas,
            a.monto,
            a.fecha_limite,
            a.fecha,
            a.motivo,
            a.pruebas,
            a.estado
        FROM admin_sanciona_adulto a
        LEFT JOIN persona p ON a.cedula_adulto = p.cedula
        WHERE a.id_familia = '$id_familia' AND a.estado = 'activa'
        ORDER BY a.fecha DESC
    ";

    $res = $conn->query($sql);

    $adultos = [];
    $familiares = [];

    if ($res && $res->num_rows > 0) {
        while ($row = $res->fetch_assoc()) {
            if (!empty($row['cedula_adulto'])) {
                $adultos[] = $row;
            } else {
                $familiares[] = $row;
            }
        }
    }

    echo json_encode([
        "familiares" => $familiares,
        "adultos" => $adultos
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}

$conn->close();
?>
