<?php
// --------------------
// Conexión
// --------------------
require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

// --------------------
// Validación de entrada
// --------------------
$cedula = $_POST['cedula'] ?? '';
$contrasenia = $_POST['contrasenia'] ?? '';

if (empty($cedula) || empty($contrasenia)) {
    echo "0"; exit;
}
if (!preg_match('/^[0-9]{8}$/', $cedula)) {
    echo "0"; exit;
}
if (strlen($contrasenia) < 8 || strlen($contrasenia) > 30) {
    echo "0"; exit;
}

// --------------------
// 1️⃣ Buscar persona
// --------------------
$stmt = $conn->prepare("SELECT cedula, id_familia, fecha_nacimiento FROM persona WHERE cedula = ?");
$stmt->bind_param("s", $cedula);
$stmt->execute();
$result = $stmt->get_result();
$persona = $result->fetch_assoc();

if (!$persona) {
    echo "0"; exit; // cedula no existe
}

// --------------------
// 2️⃣ Revisar estado de familia
// --------------------
$stmt = $conn->prepare("SELECT estado FROM familia WHERE id = ?");
$stmt->bind_param("i", $persona['id_familia']);
$stmt->execute();
$result = $stmt->get_result();
$familia = $result->fetch_assoc();

if (!$familia) {
    echo "0"; exit;
}

switch ($familia['estado']) {
    case 'rechazado':
        echo "1"; exit;
    case 'pendiente':
        echo "2"; exit;
    case 'aprobado':
        break; // sigue
    default:
        echo "0"; exit;
}

// --------------------
// 3️⃣ Revisar si es adulto
// --------------------
$fechaNacimiento = new DateTime($persona['fecha_nacimiento']);
$hoy = new DateTime();
$edad = $hoy->diff($fechaNacimiento)->y;

if ($edad < 18) {
    echo "3"; exit; // no es adulto
}

// --------------------
// 4️⃣ Revisar credenciales en adulto
// --------------------
$stmt = $conn->prepare("SELECT contrasenia FROM adulto WHERE cedula = ?");
$stmt->bind_param("s", $cedula);
$stmt->execute();
$result = $stmt->get_result();
$adulto = $result->fetch_assoc();

if (!$adulto || is_null($adulto['contrasenia'])) {
    echo "4"; exit;
}

if ($adulto['contrasenia'] !== $contrasenia) {
    echo "5"; exit;
}

// --------------------
// 5️⃣ Login correcto
// --------------------
echo "6";
// Aquí podés agregar scripts a ejecutar cuando inicia sesión correctamente


$conn->close();
?>
