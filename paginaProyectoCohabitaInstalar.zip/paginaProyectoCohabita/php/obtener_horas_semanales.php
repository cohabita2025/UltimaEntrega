<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}
$aportes = [];

// 1️⃣ Traer todos los aportes de horas semanales
$result = $mysqli->query("SELECT * FROM horas_semanales");

while ($aporte = $result->fetch_assoc()) {
    $idAporte = $aporte['id_aporte'];
    $cedulaAdulto = $aporte['cedula_adulto'];

    // 2️⃣ Buscar los datos del adulto que registró la hora
    $stmt = $mysqli->prepare("
        SELECT p.cedula, p.nombre, p.primer_apellido, p.segundo_apellido, 
               a.correo, a.telefono, f.rol AS rol_familia
        FROM persona p
        LEFT JOIN adulto a ON a.cedula = p.cedula
        LEFT JOIN persona_integra_familia f ON f.cedula_persona = p.cedula
        WHERE p.cedula = ?
        LIMIT 1
    ");
    $stmt->bind_param("s", $cedulaAdulto);
    $stmt->execute();
    $adulto = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // 3️⃣ Contar cuántos admins evaluaron este aporte
    $stmtEval = $mysqli->prepare("
        SELECT COUNT(*) AS total
        FROM admin_valida_horas_semanales
        WHERE id_aporte = ?
    ");
    $stmtEval->bind_param("i", $idAporte);
    $stmtEval->execute();
    $evaluaciones = $stmtEval->get_result()->fetch_assoc()['total'];
    $stmtEval->close();

    // 4️⃣ Contar cuántos adultos existen en total
    $resultAdmins = $mysqli->query("
        SELECT COUNT(*) AS total
        FROM adulto
    ");
    $cantAdmins = $resultAdmins->fetch_assoc()['total'];

    // 5️⃣ Crear objeto de aporte con adulto + evaluaciones + total de admins
    $aportes[] = [
        'id_aporte'       => $idAporte,
        'fecha_aporte'    => $aporte['fecha_aporte'],
        'tarea'           => $aporte['tarea'],
        'cedula_adulto'   => $cedulaAdulto,
        'estado'          => $aporte['estado'],
        'cant_horas'      => (int)$aporte['cant_horas'],
        'fecha_horas'     => $aporte['fecha_horas'],
        'adulto'          => $adulto, // puede ser null
        'evaluaciones'    => (int)$evaluaciones,
        'total_admins'    => (int)$cantAdmins
    ];
}

// 6️⃣ Mostrar resultado como JSON
header('Content-Type: application/json');
echo json_encode($aportes, JSON_PRETTY_PRINT);
?>
