<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json; charset=utf-8');

require_once "config.php";

if ($conn->connect_error) {
    echo json_encode(["error" => "Error de conexión a la base de datos"]);
    exit;
}

$id_familia = $_POST['id_familia'] ?? $_GET['id_familia'] ?? null;

if (empty($id_familia)) {
    echo json_encode(["error" => "No se recibió id_familia"]);
    exit;
}

$id_familia = intval($id_familia);

try {
    $sql = "SELECT 
                id,
                id_admin,
                cedula_adulto,
                id_familia,
                cant_horas,
                monto,
                fecha_inicio,
                fecha_limite,
                fecha,
                motivo,
                pruebas,
                estado
            FROM admin_sanciona_adulto
            WHERE id_familia = $id_familia
            ORDER BY fecha DESC";

    $res = $conn->query($sql);

    if (!$res) {
        echo json_encode(["error_sql" => $conn->error, "query" => $sql]);
        exit;
    }

    $sanciones_familia = [];
    $sanciones_adultos = [];

    while ($row = $res->fetch_assoc()) {
        if ($row['cedula_adulto'] !== null && $row['cedula_adulto'] !== "") {
            $sanciones_adultos[] = $row;
        } else {
            $sanciones_familia[] = $row;
        }
    }

    echo json_encode([
        "sanciones_familia" => $sanciones_familia,
        "sanciones_adultos" => $sanciones_adultos
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
