<?php
if (!isset($_POST['ruta'])) {
    http_response_code(400);
    exit(json_encode(["error" => "Falta la ruta de la carpeta"]));
}

$rutaRelativa = $_POST['ruta'];

// Carpeta base del proyecto
$baseDir = realpath(__DIR__ . "/..");

// Limpiar posibles '../' al inicio
$rutaRelativa = ltrim($rutaRelativa, "/\\"); 
$rutaRelativa = preg_replace('/^\.\.(\/|\\\\)+/', '', $rutaRelativa);

// Ruta absoluta
$folderPath = realpath($baseDir . '/' . $rutaRelativa);

if ($folderPath === false || !is_dir($folderPath)) {
    http_response_code(404);
    exit(json_encode(["error" => "Carpeta no encontrada"]));
}

// Seguridad: no salir del proyecto
if (strpos($folderPath, $baseDir) !== 0) {
    http_response_code(403);
    exit(json_encode(["error" => "Acceso denegado fuera del proyecto"]));
}

// Recorrer archivos
$archivos = [];
$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($folderPath)
);

foreach ($iterator as $file) {
    if ($file->isFile()) {
        // Guardamos ruta relativa a la carpeta base
        $archivos[] = substr($file->getRealPath(), strlen($folderPath) + 1);
    }
}

// Devolver JSON
header('Content-Type: application/json');
echo json_encode($archivos);
exit();
?>
