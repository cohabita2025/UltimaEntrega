<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

// Validar parámetro
if (!isset($_GET['id_familia'])) {
    echo json_encode(["error" => "Falta id_familia"]);
    exit;
}

$idFamilia = intval($_GET['id_familia']);
$solicitudes = [];

// 1️⃣ Traer la solicitud de esa familia
$stmtSol = $mysqli->prepare("
    SELECT *
    FROM solicitud_registro
    WHERE id_familia = ?
    LIMIT 1
");
$stmtSol->bind_param("i", $idFamilia);
$stmtSol->execute();
$sol = $stmtSol->get_result()->fetch_assoc();
$stmtSol->close();

if (!$sol) {
    echo json_encode([]);
    exit;
}

$idSolicitud = $sol['id'];

// 2️⃣ Buscar el titular de la familia
$stmt = $mysqli->prepare("
    SELECT a.cedula, p.nombre, p.primer_apellido, p.segundo_apellido, 
           a.correo, a.telefono
    FROM adulto a
    INNER JOIN persona p ON a.cedula = p.cedula
    WHERE a.rol = 'titular'
      AND a.cedula IN (
            SELECT cedula_persona 
            FROM persona_integra_familia 
            WHERE id_familia = ?
      )
    LIMIT 1
");
$stmt->bind_param("i", $idFamilia);
$stmt->execute();
$titular = $stmt->get_result()->fetch_assoc();
$stmt->close();

// 3️⃣ Contar evaluaciones
$stmtEval = $mysqli->prepare("
    SELECT COUNT(*) AS total
    FROM admin_evalua_solicitud_registro
    WHERE id_solicitud_registro = ?
");
$stmtEval->bind_param("i", $idSolicitud);
$stmtEval->execute();
$evaluaciones = $stmtEval->get_result()->fetch_assoc()['total'];
$stmtEval->close();

// 4️⃣ Contar familiares
$stmtFam = $mysqli->prepare("
    SELECT COUNT(*) AS total
    FROM persona_integra_familia
    WHERE id_familia = ?
");
$stmtFam->bind_param("i", $idFamilia);
$stmtFam->execute();
$cantFamiliares = $stmtFam->get_result()->fetch_assoc()['total'];
$stmtFam->close();

// 5️⃣ Contar admins del sistema
$resultAdmins = $mysqli->query("
    SELECT COUNT(*) AS total
    FROM adulto
    WHERE rol = 'admin'
");
$cantAdmins = $resultAdmins->fetch_assoc()['total'];

// 6️⃣ Armar objeto final
$solicitudes[] = [
    'id_solicitud'    => $idSolicitud,
    'fecha'           => $sol['fecha'],
    'estado'          => $sol['estado'],
    'id_familia'      => $idFamilia,
    'titular'         => $titular,
    'evaluaciones'    => (int)$evaluaciones,
    'cant_familiares' => (int)$cantFamiliares,
    'admins'          => (int)$cantAdmins
];

// 7️⃣ Devolver JSON
header('Content-Type: application/json');
echo json_encode($solicitudes, JSON_PRETTY_PRINT);
?>
