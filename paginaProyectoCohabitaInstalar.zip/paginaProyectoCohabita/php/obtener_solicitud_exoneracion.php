<?php
header('Content-Type: application/json; charset=utf-8');

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}
$id_solicitud = $_GET['id_solicitud'] ?? null;
if (!$id_solicitud) {
    echo json_encode(['error' => 'No se proporcionó id_solicitud'], JSON_UNESCAPED_UNICODE);
    exit;
}

/* 1) Datos de la solicitud de exoneración */
$stmt = $conn->prepare("
    SELECT id, fecha, motivo, estado, pruebas, fecha_inicio, fecha_fin, cedula_adulto
    FROM solicitud_exoneracion_horas
    WHERE id = ?
");
$stmt->bind_param("i", $id_solicitud);
$stmt->execute();
$solicitud = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$solicitud) {
    echo json_encode(['error' => 'Solicitud no encontrada'], JSON_UNESCAPED_UNICODE);
    exit;
}

/* 2) Datos del adulto relacionado */
$stmt = $conn->prepare("
    SELECT 
        p.id_familia, 
        p.cedula, 
        p.nombre, 
        p.primer_apellido, 
        p.segundo_apellido, 
        p.genero, 
        p.fecha_nacimiento, 
        p.copia_cedula, 
        p.foto, 
        a.declaracion_no_vivienda, 
        a.recibo_sueldo, 
        a.correo, 
        a.telefono, 
        a.rol
    FROM persona p
    LEFT JOIN adulto a ON a.cedula = p.cedula
    WHERE p.cedula = ?
");
$stmt->bind_param("s", $solicitud['cedula_adulto']);
$stmt->execute();
$adulto = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* 3) Admins + tramitaciones de esta solicitud (solo aprobadas o rechazadas) */
$stmt = $conn->prepare("
    SELECT
        a.cedula,
        p.nombre,
        p.primer_apellido,
        p.segundo_apellido,
        p.id_familia,
        t.conclusion,
        t.razon_conclusion
    FROM adulto a
    JOIN persona p ON a.cedula = p.cedula
    LEFT JOIN admin_tramita_exoneracion_horas t
        ON t.id_admin = a.cedula AND t.id_solicitud_exoneracion = ?
    WHERE a.rol = 'admin'
");
$stmt->bind_param("i", $id_solicitud);
$stmt->execute();
$tramitaciones = [];
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    // Solo agregar si hay conclusion válida (aprobado o rechazado)
    if (!empty($row['conclusion']) && $row['conclusion'] !== 'pendiente') {
        if (empty($row['razon_conclusion'])) {
            $row['razon_conclusion'] = "";
        }
        $tramitaciones[] = $row;
    }
}
$stmt->close();

/* 4) Respuesta final */
echo json_encode([
    'solicitud_exoneracion' => [
        'id' => $solicitud['id'],
        'fecha' => $solicitud['fecha'],
        'motivo' => $solicitud['motivo'],
        'estado' => $solicitud['estado'],
        'pruebas' => $solicitud['pruebas'],
        'fecha_inicio' => $solicitud['fecha_inicio'],
        'fecha_fin' => $solicitud['fecha_fin'],
        'cedula' => $adulto['cedula'],
        'nombre' => $adulto['nombre'],
        'primer_apellido' => $adulto['primer_apellido'],
        'segundo_apellido' => $adulto['segundo_apellido'],
        'genero' => $adulto['genero'],
        'correo' => $adulto['correo'],
        'telefono' => $adulto['telefono'],
        'rol' => $adulto['rol'],
        'id_familia' => $adulto['id_familia']
    ],
    'tramitaciones' => $tramitaciones
], JSON_UNESCAPED_UNICODE);

$conn->close();
?>
