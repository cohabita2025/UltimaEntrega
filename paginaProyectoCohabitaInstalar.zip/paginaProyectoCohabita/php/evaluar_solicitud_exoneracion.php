<?php
// --- DATOS DE CONEXIÓN ---
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'cohabita';

// Crear conexión
require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

// Validar POST y parámetros
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405); // Método no permitido
    exit;
}

$id_solicitud = $_POST['id_solicitud'] ?? null;
$id_admin = $_POST['id_admin'] ?? null;
$conclusion = $_POST['conclusion'] ?? null;
$razon = $_POST['razon_conclusion'] ?? null;

if (!$id_solicitud || !$id_admin || !$conclusion || !$razon) {
    http_response_code(400); // Bad request
    exit;
}

$id_solicitud = intval($id_solicitud);

// 1️⃣ Actualizar estado de la solicitud
$update = $conn->prepare("
    UPDATE solicitud_exoneracion_horas
    SET estado = ?
    WHERE id = ?
");
$update->bind_param("si", $conclusion, $id_solicitud);
$update->execute();
$update->close();

// 2️⃣ Insertar registro en admin_tramita_exoneracion_horas
$insert = $conn->prepare("
    INSERT INTO admin_tramita_exoneracion_horas
    (id_solicitud_exoneracion, id_admin, fecha, conclusion, razon_conclusion)
    VALUES (?, ?, CURDATE(), ?, ?)
");
$insert->bind_param("isss", $id_solicitud, $id_admin, $conclusion, $razon);
$insert->execute();
$insert->close();

$conn->close();

// ✅ Todo salió bien
http_response_code(200);
exit;
?>
