<?php
header('Content-Type: application/json');

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

// --- RECIBIR ID FAMILIA ---
$id_familia = isset($_GET['id_familia']) ? intval($_GET['id_familia']) : 0;
if ($id_familia <= 0) {
    echo json_encode(['error' => 'ID familia inválida']);
    exit;
}

// --- TRAER PERSONAS (ADULTOS) ---
$sql_adultos = "SELECT p.nombre, p.primer_apellido, p.segundo_apellido, a.cedula
                FROM persona p
                JOIN adulto a ON p.cedula = a.cedula
                WHERE p.id_familia = ?";
$stmt = $conn->prepare($sql_adultos);
$stmt->bind_param("i", $id_familia);
$stmt->execute();
$result = $stmt->get_result();

$adultos = [];

while ($adulto = $result->fetch_assoc()) {
    $cedula = $adulto['cedula'];

    // --- HORAS SEMANALES APROBADAS (toda info) ---
    $sql_horas = "SELECT * 
                  FROM horas_semanales 
                  WHERE cedula_adulto = ? AND estado = 'aprobado'";
    $stmt_horas = $conn->prepare($sql_horas);
    $stmt_horas->bind_param("s", $cedula);
    $stmt_horas->execute();
    $horas_result = $stmt_horas->get_result();
    $horas = $horas_result->fetch_all(MYSQLI_ASSOC);
    $stmt_horas->close();

    // --- SOLICITUDES EXONERACION APROBADAS (toda info) ---
    $sql_exon = "SELECT * 
                 FROM solicitud_exoneracion_horas 
                 WHERE cedula_adulto = ? AND estado = 'aprobado'";
    $stmt_exon = $conn->prepare($sql_exon);
    $stmt_exon->bind_param("s", $cedula);
    $stmt_exon->execute();
    $exon_result = $stmt_exon->get_result();
    $solicitudes = $exon_result->fetch_all(MYSQLI_ASSOC);
    $stmt_exon->close();

    $adultos[] = [
        'nombre' => $adulto['nombre'],
        'primer_apellido' => $adulto['primer_apellido'],
        'segundo_apellido' => $adulto['segundo_apellido'],
        'cedula' => $cedula,
        'horas_semanales' => $horas,
        'solicitudes_exoneracion' => $solicitudes
    ];
}
$stmt->close();

// --- ULTIMA EVALUACION ---
$sql_eval = "SELECT aesr.fecha, aesr.id_admin AS admin, aesr.conclusion
             FROM admin_evalua_solicitud_registro aesr
             JOIN solicitud_registro sr ON aesr.id_solicitud_registro = sr.id
             WHERE sr.id_familia = ?
             ORDER BY aesr.fecha DESC
             LIMIT 1";
$stmt_eval = $conn->prepare($sql_eval);
$stmt_eval->bind_param("i", $id_familia);
$stmt_eval->execute();
$eval_result = $stmt_eval->get_result();
$ultima_eval = $eval_result->fetch_assoc();
$stmt_eval->close();

// --- SI NO HAY EVALUACION, TOMAR FECHA DE LA SOLICITUD ---
if (!$ultima_eval) {
    $sql_solicitud = "SELECT fecha 
                       FROM solicitud_registro 
                       WHERE id_familia = ? 
                       ORDER BY fecha DESC 
                       LIMIT 1";
    $stmt_sol = $conn->prepare($sql_solicitud);
    $stmt_sol->bind_param("i", $id_familia);
    $stmt_sol->execute();
    $res_sol = $stmt_sol->get_result();
    $solicitud = $res_sol->fetch_assoc();
    $stmt_sol->close();

    if ($solicitud) {
        $ultima_eval = [
            'fecha' => $solicitud['fecha'],
            'admin' => null,
            'conclusion' => null
        ];
    } else {
        $ultima_eval = null;
    }
}

echo json_encode([
    'adultos' => $adultos,
    'ultima_evaluacion' => $ultima_eval
], JSON_PRETTY_PRINT);

$conn->close();
?>
