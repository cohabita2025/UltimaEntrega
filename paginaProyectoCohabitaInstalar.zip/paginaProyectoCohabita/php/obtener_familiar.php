<?php
// Mostrar errores para depuración
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

require_once "config.php";
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

// Recibir cedula
$cedula = $_POST['cedula'] ?? '';

if (empty($cedula)) {
    echo json_encode(["error" => "No se recibió cédula"]);
    exit;
}

// Evitar inyección
$cedula = $conn->real_escape_string($cedula);

try {
    // Buscar en persona
    $sql = "SELECT * FROM persona WHERE cedula = '$cedula'";
    $res = $conn->query($sql);

    if (!$res || $res->num_rows === 0) {
        echo json_encode(["error" => "Familiar no encontrado"]);
        exit;
    }

    $persona = $res->fetch_assoc();

    // Buscar en adulto
    $sql = "SELECT cedula, declaracion_no_vivienda, recibo_sueldo, correo, telefono, rol 
            FROM adulto WHERE cedula = '$cedula'";
    $res = $conn->query($sql);

    if ($res && $res->num_rows > 0) {
        $adulto = $res->fetch_assoc();
        $familiar = array_merge($persona, $adulto);
    } else {
        $familiar = $persona;
    }

    // 🔹 Obtener rol_familia desde persona_integra_familia
    $sql = "SELECT rol FROM persona_integra_familia WHERE cedula_persona = '$cedula' LIMIT 1";
    $res = $conn->query($sql);
    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $familiar['rol_familia'] = $row['rol'];
    } else {
        $familiar['rol_familia'] = null;
    }

    // ================================================
    // 🔹 Calcular fecha_ingreso
    // ================================================
    $fecha_ingreso = null;

    if (!empty($familiar['id_familia'])) {
        $id_familia = $familiar['id_familia'];

        // Buscar la solicitud de registro más reciente para esa familia
        $sql = "SELECT id, fecha FROM solicitud_registro 
                WHERE id_familia = $id_familia 
                ORDER BY fecha DESC LIMIT 1";
        $res = $conn->query($sql);

        if ($res && $res->num_rows > 0) {
            $solicitud = $res->fetch_assoc();
            $id_solicitud = $solicitud['id'];
            $fecha_solicitud = $solicitud['fecha'];

            // Buscar evaluación asociada
            $sqlEval = "SELECT fecha FROM admin_evalua_solicitud_registro 
                        WHERE id_solicitud_registro = $id_solicitud 
                        ORDER BY fecha DESC LIMIT 1";
            $resEval = $conn->query($sqlEval);

            if ($resEval && $resEval->num_rows > 0) {
                $eval = $resEval->fetch_assoc();
                $fecha_ingreso = $eval['fecha']; // usar fecha de evaluación
            } else {
                $fecha_ingreso = $fecha_solicitud; // usar fecha de solicitud
            }
        }
    }

    $familiar['fecha_ingreso'] = $fecha_ingreso;

    // ================================================
    // 🔹 Enviar respuesta final
    // ================================================
    echo json_encode($familiar, JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
