<?php
// obtener_acciones_familiares.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "config.php";

// elegir conexión disponible
$db = null;
if (isset($conn) && $conn instanceof mysqli) $db = $conn;
elseif (isset($mysqli) && $mysqli instanceof mysqli) $db = $mysqli;
else {
    http_response_code(500);
    echo json_encode(["ok" => false, "error" => "No DB connection"]);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

$id_familia = isset($_GET['id_familia']) ? intval($_GET['id_familia']) : null;
if (!$id_familia) {
    http_response_code(400);
    echo json_encode(["ok" => false, "error" => "Falta id_familia"]);
    exit;
}

$acciones = [];

// helper: obtener nombre de una persona
function nombre_persona($db, $cedula) {
    $out = ["nombre" => null, "primer_apellido" => null, "segundo_apellido" => null];
    if (!$cedula) return $out;

    $sql = "SELECT nombre, primer_apellido, segundo_apellido FROM persona WHERE cedula = ? LIMIT 1";
    $stmt = $db->prepare($sql);
    if (!$stmt) return $out;

    $stmt->bind_param("s", $cedula);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($row = $res->fetch_assoc()) {
        $out = [
            "nombre" => $row['nombre'],
            "primer_apellido" => $row['primer_apellido'],
            "segundo_apellido" => $row['segundo_apellido']
        ];
    }
    $stmt->close();

    return $out;
}

/* ============================================================
   1) APORTES – ENVÍO
   ============================================================ */
$sql = "
    SELECT hs.id_aporte, hs.fecha_aporte, hs.estado, hs.cant_horas, hs.cedula_adulto
    FROM horas_semanales hs
    WHERE hs.cedula_adulto IN (
        SELECT cedula_persona FROM persona_integra_familia WHERE id_familia = ?
    )
";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $id_familia);
$stmt->execute();
$res = $stmt->get_result();

while ($row = $res->fetch_assoc()) {
    $persona = nombre_persona($db, $row['cedula_adulto']);

    $acciones[] = [
        "tipoAccion" => "aporte de horas",
        "tipo" => "envio",
        "fecha" => $row['fecha_aporte'],

        "nombre" => $persona['nombre'],
        "primer_apellido" => $persona['primer_apellido'],
        "segundo_apellido" => $persona['segundo_apellido'],

        "cant_horas" => (int)$row['cant_horas'],
        "estado" => $row['estado'],
        "monto" => null,
        "conclusion" => null,
        "tipoSancion" => null
    ];
}
$stmt->close();

/* ============================================================
   1b) APORTES – EVALUACIÓN
   ============================================================ */
$sql = "
    SELECT avh.id_aporte, avh.id_admin, avh.fecha, avh.conclusion,
           hs.cant_horas, hs.cedula_adulto
    FROM admin_valida_horas_semanales avh
    JOIN horas_semanales hs ON avh.id_aporte = hs.id_aporte
    WHERE hs.cedula_adulto IN (
        SELECT cedula_persona FROM persona_integra_familia WHERE id_familia = ?
    )
";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $id_familia);
$stmt->execute();
$res = $stmt->get_result();

while ($row = $res->fetch_assoc()) {
    $admin = nombre_persona($db, $row['id_admin']);
    $familiar = nombre_persona($db, $row['cedula_adulto']);

    $acciones[] = [
        "tipoAccion" => "aporte de horas",
        "tipo" => "evaluacion",
        "fecha" => $row['fecha'],

        "nombre_admin" => $admin['nombre'],
        "primer_apellido_admin" => $admin['primer_apellido'],
        "segundo_apellido_admin" => $admin['segundo_apellido'],

        "nombre_familiar" => $familiar['nombre'],
        "primer_apellido_familiar" => $familiar['primer_apellido'],
        "segundo_apellido_familiar" => $familiar['segundo_apellido'],

        "cant_horas" => (int)$row['cant_horas'],
        "estado" => null,
        "monto" => null,
        "conclusion" => $row['conclusion'],
        "tipoSancion" => null
    ];
}
$stmt->close();

/* ============================================================
   2) COMPROBANTES – ENVÍO
   ============================================================ */
$sql = "
    SELECT c.id, c.estado, c.monto, c.fecha_envio_comprobante, c.cedula_titular
    FROM comprobante_pago c
    WHERE c.cedula_titular IN (
        SELECT cedula_persona FROM persona_integra_familia WHERE id_familia = ?
    )
";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $id_familia);
$stmt->execute();
$res = $stmt->get_result();

while ($row = $res->fetch_assoc()) {
    $titular = nombre_persona($db, $row['cedula_titular']);

    $acciones[] = [
        "tipoAccion" => "comprobante de pago",
        "tipo" => "envio",
        "fecha" => $row['fecha_envio_comprobante'],

        "nombre" => $titular['nombre'],
        "primer_apellido" => $titular['primer_apellido'],
        "segundo_apellido" => $titular['segundo_apellido'],

        "cant_horas" => null,
        "estado" => $row['estado'],
        "monto" => (float)$row['monto'],
        "conclusion" => null,
        "tipoSancion" => null
    ];
}
$stmt->close();

/* ============================================================
   2b) COMPROBANTES – EVALUACIÓN
   ============================================================ */
$sql = "
    SELECT avc.id_comprobante_pago, avc.id_admin, avc.fecha, avc.conclusion,
           c.monto, c.cedula_titular
    FROM admin_valida_comprobante_pago avc
    JOIN comprobante_pago c ON avc.id_comprobante_pago = c.id
    WHERE c.cedula_titular IN (
        SELECT cedula_persona FROM persona_integra_familia WHERE id_familia = ?
    )
";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $id_familia);
$stmt->execute();

$res = $stmt->get_result();

while ($row = $res->fetch_assoc()) {
    $admin = nombre_persona($db, $row['id_admin']);
    $familiar = nombre_persona($db, $row['cedula_titular']);

    $acciones[] = [
        "tipoAccion" => "comprobante de pago",
        "tipo" => "evaluacion",
        "fecha" => $row['fecha'],

        "nombre_admin" => $admin['nombre'],
        "primer_apellido_admin" => $admin['primer_apellido'],
        "segundo_apellido_admin" => $admin['segundo_apellido'],

        "nombre_familiar" => $familiar['nombre'],
        "primer_apellido_familiar" => $familiar['primer_apellido'],
        "segundo_apellido_familiar" => $familiar['segundo_apellido'],

        "cant_horas" => null,
        "estado" => null,
        "monto" => (float)$row['monto'],
        "conclusion" => $row['conclusion'],
        "tipoSancion" => null
    ];
}
$stmt->close();

/* ============================================================
   3) EXONERACIONES – ENVÍO
   ============================================================ */
$sql = "
    SELECT s.id, s.fecha, s.estado, s.cedula_adulto, s.fecha_inicio, s.fecha_fin
    FROM solicitud_exoneracion_horas s
    WHERE s.cedula_adulto IN (
        SELECT cedula_persona FROM persona_integra_familia WHERE id_familia = ?
    )
";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $id_familia);
$stmt->execute();

$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {

    $fechaInicio = new DateTime($row['fecha_inicio']);
    $fechaFin = new DateTime($row['fecha_fin']);
    $dias = $fechaInicio->diff($fechaFin)->days + 1;
    $cantHoras = $dias * 3;

    $persona = nombre_persona($db, $row['cedula_adulto']);

    $acciones[] = [
        "tipoAccion" => "exoneracion de horas",
        "tipo" => "envio",
        "fecha" => $row['fecha'],

        "nombre" => $persona['nombre'],
        "primer_apellido" => $persona['primer_apellido'],
        "segundo_apellido" => $persona['segundo_apellido'],

        "cant_horas" => $cantHoras,
        "estado" => $row['estado'],
        "monto" => null,
        "conclusion" => null,
        "tipoSancion" => null
    ];
}
$stmt->close();

/* ============================================================
   3b) EXONERACIONES – EVALUACIÓN
   ============================================================ */
$sql = "
    SELECT at.id_solicitud_exoneracion, at.id_admin, at.fecha, at.conclusion,
           s.cedula_adulto, s.fecha_inicio, s.fecha_fin
    FROM admin_tramita_exoneracion_horas at
    JOIN solicitud_exoneracion_horas s ON at.id_solicitud_exoneracion = s.id
    WHERE s.cedula_adulto IN (
        SELECT cedula_persona FROM persona_integra_familia WHERE id_familia = ?
    )
";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $id_familia);
$stmt->execute();

$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {

    $fechaInicio = new DateTime($row['fecha_inicio']);
    $fechaFin = new DateTime($row['fecha_fin']);
    $dias = $fechaInicio->diff($fechaFin)->days + 1;
    $cantHoras = $dias * 3;

    $admin = nombre_persona($db, $row['id_admin']);
    $familiar = nombre_persona($db, $row['cedula_adulto']);

    $acciones[] = [
        "tipoAccion" => "exoneracion de horas",
        "tipo" => "evaluacion",
        "fecha" => $row['fecha'],

        "nombre_admin" => $admin['nombre'],
        "primer_apellido_admin" => $admin['primer_apellido'],
        "segundo_apellido_admin" => $admin['segundo_apellido'],

        "nombre_familiar" => $familiar['nombre'],
        "primer_apellido_familiar" => $familiar['primer_apellido'],
        "segundo_apellido_familiar" => $familiar['segundo_apellido'],

        "cant_horas" => $cantHoras,
        "estado" => null,
        "monto" => null,
        "conclusion" => $row['conclusion'],
        "tipoSancion" => null
    ];
}
$stmt->close();

/* ============================================================
   4) SANCIONES – ENVÍO
   ============================================================ */
$sql = "
    SELECT s.id, s.id_admin, s.cedula_adulto, s.cant_horas, s.monto,
           s.fecha, s.estado
    FROM admin_sanciona_adulto s
    WHERE s.id_familia = ?
";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $id_familia);
$stmt->execute();

$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {

    $admin = nombre_persona($db, $row['id_admin']);
    $tipoSancion = (!empty($row['cedula_adulto'])) ? "adulto" : "familia";

    $acciones[] = [
        "tipoAccion" => "sancion",
        "tipo" => "envio",
        "fecha" => $row['fecha'],

        "nombre" => $admin['nombre'],
        "primer_apellido" => $admin['primer_apellido'],
        "segundo_apellido" => $admin['segundo_apellido'],

        // ⬇️  CORRECCIÓN: ahora ambos valores se envían si vienen de la DB
        "cant_horas" => (int)$row['cant_horas'], 
        "monto" => (float)$row['monto'],

        "estado" => $row['estado'],
        "conclusion" => null,
        "tipoSancion" => $tipoSancion
    ];
}
$stmt->close();


/* ============================================================
   ORDENAR POR FECHA DESC
   ============================================================ */
usort($acciones, function($a, $b) {
    $fa = isset($a['fecha']) ? strtotime($a['fecha']) : 0;
    $fb = isset($b['fecha']) ? strtotime($b['fecha']) : 0;
    return $fb <=> $fa;
});

echo json_encode($acciones, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
exit;
