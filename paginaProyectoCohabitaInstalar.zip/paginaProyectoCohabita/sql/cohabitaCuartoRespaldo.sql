-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-10-2025 a las 21:29:02
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cohabita`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_evalua_reclamo`
--

CREATE TABLE `admin_evalua_reclamo` (
  `id_reclamo` int(11) DEFAULT NULL,
  `id_admin` char(8) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `conclusion` enum('aprobado','rechazado') DEFAULT NULL,
  `razon_conclusion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_evalua_solicitud_registro`
--

CREATE TABLE `admin_evalua_solicitud_registro` (
  `id_solicitud_registro` int(11) DEFAULT NULL,
  `id_admin` char(8) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `conclusion` enum('aprobado','rechazado') DEFAULT NULL,
  `razon_conclusion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `admin_evalua_solicitud_registro`
--

INSERT INTO `admin_evalua_solicitud_registro` (`id_solicitud_registro`, `id_admin`, `fecha`, `conclusion`, `razon_conclusion`) VALUES
(2, '57127887', '2025-10-12', 'aprobado', 'son personitas reales\r\n'),
(3, '00000004', '2025-10-12', 'aprobado', 'nos sirve mucho'),
(3, '57127887', '2025-10-12', 'aprobado', 'concuerdo con peru perro gato'),
(4, '57127887', '2025-10-12', 'rechazado', 'lo que ere tu e un mentiroso'),
(4, '00000004', '2025-10-12', 'aprobado', 'tiene razon agustin'),
(5, '57127887', '2025-10-12', 'aprobado', 'prueba noams'),
(5, '00000004', '2025-10-12', 'aprobado', 'ta bien'),
(6, '57127887', '2025-10-16', 'rechazado', 'awdwad'),
(7, '57127887', '2025-10-16', 'aprobado', 'negrito');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_expulsa_familia`
--

CREATE TABLE `admin_expulsa_familia` (
  `id` int(11) NOT NULL,
  `id_admin` char(8) DEFAULT NULL,
  `id_familia` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `motivo` text DEFAULT NULL,
  `pruebas` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_sanciona_familia`
--

CREATE TABLE `admin_sanciona_familia` (
  `id` int(11) NOT NULL,
  `id_admin` char(8) DEFAULT NULL,
  `id_familia` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `motivo` text DEFAULT NULL,
  `prueba` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_tramita_exoneracion_horas`
--

CREATE TABLE `admin_tramita_exoneracion_horas` (
  `id_solicitud_exoneracion` int(11) DEFAULT NULL,
  `id_admin` char(8) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `conclusion` enum('aprobado','rechazado') DEFAULT NULL,
  `razon_conclusion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_valida_comprobante_pago`
--

CREATE TABLE `admin_valida_comprobante_pago` (
  `id_comprobante_pago` int(11) DEFAULT NULL,
  `id_admin` char(8) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `conclusion` enum('aprobado','rechazado') DEFAULT NULL,
  `razon_conclusion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `admin_valida_comprobante_pago`
--

INSERT INTO `admin_valida_comprobante_pago` (`id_comprobante_pago`, `id_admin`, `fecha`, `conclusion`, `razon_conclusion`) VALUES
(7, '57127887', '2025-09-14', 'rechazado', 'es mentira'),
(6, '57127887', '2025-09-14', 'aprobado', 'es verdad ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin_valida_horas_semanales`
--

CREATE TABLE `admin_valida_horas_semanales` (
  `id_aporte` int(11) NOT NULL,
  `id_admin` char(8) NOT NULL,
  `fecha` date DEFAULT NULL,
  `conclusion` enum('aprobado','rechazado') DEFAULT NULL,
  `razon_conclusion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `admin_valida_horas_semanales`
--

INSERT INTO `admin_valida_horas_semanales` (`id_aporte`, `id_admin`, `fecha`, `conclusion`, `razon_conclusion`) VALUES
(1, '57127887', '2025-09-12', 'aprobado', 'pues ta tontito el bro'),
(2, '57127887', '2025-09-11', 'aprobado', 'hijo del diablaso'),
(3, '57127887', '2025-09-11', 'rechazado', 'esta mal , no hiciste nada'),
(4, '57127887', '2025-09-11', 'aprobado', 'perro desgraciado'),
(5, '57127887', '2025-09-13', 'rechazado', 'no asistio , es mentira'),
(6, '57127887', '2025-09-13', 'aprobado', 'es  verda'),
(7, '57127887', '2025-09-14', 'rechazado', 'pues asi y asi'),
(8, '57127887', '2025-09-13', 'aprobado', 'mentirsin son san sen sun sin blablabla');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `adulto`
--

CREATE TABLE `adulto` (
  `cedula` char(8) NOT NULL,
  `declaracion_no_vivienda` varchar(255) DEFAULT NULL,
  `recibo_sueldo` varchar(255) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `contrasenia` varchar(30) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `rol` enum('titular','admin') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `adulto`
--

INSERT INTO `adulto` (`cedula`, `declaracion_no_vivienda`, `recibo_sueldo`, `correo`, `contrasenia`, `telefono`, `rol`) VALUES
('00000002', 'declaracion_00000002.svg', 'recibo_00000002.svg', 'asdgus@gmail.com', '00000002', '123123123', 'titular'),
('00000003', 'declaracion_00000003.svg', 'recibo_00000003.svg', 'asdgus@gmail.com', '00000003', '222222222222222', 'titular'),
('00000004', 'declaracion_00000004.svg', 'recibo_00000004.svg', 'asdasd@gmail.com', '00000004', '123232323232222', 'admin'),
('00000005', 'declaracion_00000005.svg', 'recibo_00000005.svg', 'asdgus@gmail.com', NULL, '123111123', ''),
('00000006', 'declaracion_00000006.webp', 'recibo_00000006.webp', 'asdasd@gmail.com', '00000006', '123232323232222', 'titular'),
('00000007', 'declaracion_00000007.png', 'recibo_00000007.webp', 'asdasd@gmail.com', NULL, '123232323232222', ''),
('00000009', 'declaracion_00000009.jpg', 'recibo_00000009.png', 'asdasd@gmail.com', '00000009', '123232323232222', 'titular'),
('00000011', 'declaracion_00000011.png', 'recibo_00000011.png', 'coca@gmail.com', '00000011', '99299292', 'titular'),
('00000012', 'declaracion_00000012.svg', 'recibo_00000012.svg', 'asdasd@gmail.com', '00000012', '00000012', 'titular'),
('00000013', 'declaracion_00000013.svg', 'recibo_00000013.svg', 'asdasd@gmail.com', NULL, '123232323232222', ''),
('00000014', 'declaracion_00000014.svg', 'recibo_00000014.svg', 'juansito@gmail.com', '00000014', '1231211212213', 'titular'),
('00000015', 'declaracion_00000015.svg', 'recibo_00000015.svg', 'asdasd@gmail.com', '00000015', '00000015', 'titular'),
('57127887', 'declaracion_57127887.svg', 'recibo_57127887.svg', 'agusvannet2018@gmail.com', 'bananero', '092654540', 'admin');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comprobante_pago`
--

CREATE TABLE `comprobante_pago` (
  `id` int(11) NOT NULL,
  `estado` enum('aprobado','rechazado','pendiente') DEFAULT NULL,
  `monto` decimal(10,2) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `fecha_envio_comprobante` date DEFAULT NULL,
  `archivo_comprobante` varchar(255) DEFAULT NULL,
  `cedula_emisor` char(8) DEFAULT NULL,
  `cedula_titular` char(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `comprobante_pago`
--

INSERT INTO `comprobante_pago` (`id`, `estado`, `monto`, `fecha`, `fecha_envio_comprobante`, `archivo_comprobante`, `cedula_emisor`, `cedula_titular`) VALUES
(5, 'pendiente', 123.00, '2000-03-31', '2025-09-13', 'comprobante_de_pago_5.svg', '12312312', '57127887'),
(6, 'aprobado', 233.00, '2000-03-22', '2025-09-13', 'comprobante_de_pago_6.svg', '12323232', '57127887'),
(7, 'rechazado', 22.00, '2000-03-31', '2025-09-13', 'comprobante_de_pago_7.svg', '22222222', '57127887');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `familia`
--

CREATE TABLE `familia` (
  `id` int(11) NOT NULL,
  `estado` enum('aprobado','rechazado','pendiente','expulsada') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `familia`
--

INSERT INTO `familia` (`id`, `estado`) VALUES
(1, 'aprobado'),
(2, 'aprobado'),
(3, 'aprobado'),
(4, 'rechazado'),
(5, 'aprobado'),
(6, 'pendiente'),
(7, 'pendiente'),
(8, 'pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horas_semanales`
--

CREATE TABLE `horas_semanales` (
  `id_aporte` int(11) NOT NULL,
  `fecha_aporte` date DEFAULT NULL,
  `tarea` text DEFAULT NULL,
  `cedula_adulto` char(8) DEFAULT NULL,
  `estado` enum('aprobado','rechazado','pendiente') DEFAULT NULL,
  `cant_horas` int(11) DEFAULT NULL,
  `fecha_horas` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `horas_semanales`
--

INSERT INTO `horas_semanales` (`id_aporte`, `fecha_aporte`, `tarea`, `cedula_adulto`, `estado`, `cant_horas`, `fecha_horas`) VALUES
(1, '2025-09-10', 'mucha cosa', '00000002', 'aprobado', 5, '2000-07-31 17:00:00'),
(2, '2025-09-10', 'porqueria pura', '00000002', 'aprobado', 4, '2000-08-31 13:30:00'),
(3, '2025-09-10', 'hice paredes y esas cosas', '00000002', 'rechazado', 1, '2000-03-31 15:01:00'),
(4, '2025-09-11', 'nomas pues', '57127887', 'aprobado', 21, '2000-03-22 04:23:00'),
(5, '2025-09-12', 'limpieza cosas varias bla bla bla', '57127887', 'rechazado', 1, '2000-12-31 04:22:00'),
(6, '2025-09-12', 'much mucho muchisimo muchochochosisisimomuch mucho muchisimo muchochochosisisimo', '57127887', 'aprobado', 12, '2025-04-22 03:00:00'),
(7, '2025-09-12', 'wadsawdsawdsa dwad wa a', '57127887', 'rechazado', 3, '2010-04-22 03:00:00'),
(8, '2025-09-12', 'wdawdwadwa', '57127887', 'aprobado', 1, '2000-11-22 03:00:00'),
(9, '2025-09-14', 'mucho trabajo oye', '57127887', 'pendiente', 2, '2000-10-02 00:00:00'),
(10, '2025-09-14', 'mucho muchisimo trabajon ', '57127887', 'pendiente', 15, '2000-12-31 03:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `cedula` char(8) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `primer_apellido` varchar(30) NOT NULL,
  `segundo_apellido` varchar(30) DEFAULT NULL,
  `genero` enum('M','F') NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `copia_cedula` varchar(255) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `id_familia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`cedula`, `nombre`, `primer_apellido`, `segundo_apellido`, `genero`, `fecha_nacimiento`, `copia_cedula`, `foto`, `id_familia`) VALUES
('00000001', 'menor', 'tonoto', 'wasd', 'M', '2025-12-31', 'copiaCedula_00000001.svg', 'foto_00000001.svg', 1),
('00000002', 'juan', 'perez', 'sdsad', 'M', '2000-06-22', 'copiaCedula_00000002.svg', 'foto_00000002.svg', 1),
('00000003', 'rara', 'perez', 'sdsad', 'M', '2000-04-22', 'copiaCedula_00000003.svg', 'foto_00000003.svg', 2),
('00000004', 'peru', 'perro', 'gato', 'M', '2000-12-31', 'copiaCedula_00000004.svg', 'foto_00000004.svg', 2),
('00000005', 'cargo', 'eert', 'warr', 'M', '2000-06-22', 'copiaCedula_00000005.svg', 'foto_00000005.svg', 2),
('00000006', 'forlan', 'asrte', '', 'M', '2000-02-29', 'copiaCedula_00000006.webp', 'foto_00000006.webp', 3),
('00000007', 'agustin', 'asds', 'Vannet', 'M', '2000-01-29', 'copiaCedula_00000007.webp', 'foto_00000007.png', 3),
('00000008', 'agua', 'asrte', 'vannet', 'M', '2010-01-28', 'copiaCedula_00000008.png', 'foto_00000008.webp', 3),
('00000009', 'banana', 'asrte', 'asrte', 'M', '2000-04-30', 'copiaCedula_00000009.webp', 'foto_00000009.svg', 4),
('00000010', 'manzana', 'asrte', '', 'F', '2010-02-28', 'copiaCedula_00000010.webp', 'foto_00000010.jpg', 4),
('00000011', 'pure', 'milanesa', '', 'M', '2000-06-29', 'copiaCedula_00000011.webp', 'foto_00000011.png', 5),
('00000012', 'javier', 'atun', 'asrte', 'M', '2001-02-28', 'copiaCedula_00000012.svg', 'foto_00000012.svg', 6),
('00000013', 'pera', 'asrte', '', 'M', '2000-03-31', 'copiaCedula_00000013.svg', 'foto_00000013.svg', 6),
('00000014', 'jose', 'perten', 'perta', 'M', '2001-02-28', 'copiaCedula_00000014.svg', 'foto_00000014.svg', 7),
('00000015', 'javier', 'aatnsd', '', 'M', '2000-01-31', 'copiaCedula_00000015.svg', 'foto_00000015.svg', 8),
('00000016', 'manuel', 'aatnsd', '', 'M', '2020-02-28', 'copiaCedula_00000016.svg', 'foto_00000016.svg', 8),
('57127887', 'agustin', 'asds', 'Vannet', 'M', '2000-12-31', 'copiaCedula_57127887.svg', 'foto_57127887.svg', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona_integra_familia`
--

CREATE TABLE `persona_integra_familia` (
  `cedula_persona` char(8) DEFAULT NULL,
  `id_familia` int(11) DEFAULT NULL,
  `rol` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `persona_integra_familia`
--

INSERT INTO `persona_integra_familia` (`cedula_persona`, `id_familia`, `rol`) VALUES
('00000002', 1, 'Hijo/a'),
('00000001', 1, 'Hijo/a'),
('57127887', 1, 'padre'),
('00000005', 2, 'Hijo/a'),
('00000004', 2, 'Hijo/a'),
('00000003', 2, 'padre'),
('00000008', 3, 'Conyuge'),
('00000007', 3, 'Hijo/a'),
('00000006', 3, 'padre'),
('00000010', 4, 'Hijo/a'),
('00000009', 4, 'padre'),
('00000011', 5, 'padre'),
('00000013', 6, 'Hijo/a'),
('00000012', 6, 'padre'),
('00000014', 7, 'Padre'),
('00000016', 8, 'Hijo/a'),
('00000015', 8, 'padre');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reclamo`
--

CREATE TABLE `reclamo` (
  `id` int(11) NOT NULL,
  `motivo` text DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `id_titular` char(8) DEFAULT NULL,
  `estado` enum('aprobado','rechazado','pendiente') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_admin`
--

CREATE TABLE `registro_admin` (
  `id` int(11) NOT NULL,
  `fecha` date DEFAULT NULL,
  `accion` varchar(50) DEFAULT NULL,
  `id_familia_afectada` int(11) DEFAULT NULL,
  `cedula_admin` char(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitud_exoneracion_horas`
--

CREATE TABLE `solicitud_exoneracion_horas` (
  `id` int(11) NOT NULL,
  `fecha` date DEFAULT NULL,
  `motivo` text DEFAULT NULL,
  `estado` enum('aprobado','rechazado','pendiente','en_votacion') DEFAULT NULL,
  `pruebas` varchar(255) DEFAULT NULL,
  `cant_horas` int(11) DEFAULT NULL,
  `id_familia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitud_registro`
--

CREATE TABLE `solicitud_registro` (
  `id` int(11) NOT NULL,
  `fecha` date DEFAULT NULL,
  `estado` enum('aprobado','rechazado','pendiente','en_votacion') DEFAULT NULL,
  `id_familia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `solicitud_registro`
--

INSERT INTO `solicitud_registro` (`id`, `fecha`, `estado`, `id_familia`) VALUES
(1, '2025-09-10', 'aprobado', 1),
(2, '2025-09-10', 'aprobado', 2),
(3, '2025-10-12', 'aprobado', 3),
(4, '2025-10-12', 'rechazado', 4),
(5, '2025-10-12', 'aprobado', 5),
(6, '2025-10-16', 'en_votacion', 6),
(7, '2025-10-16', 'en_votacion', 7),
(8, '2025-10-16', 'pendiente', 8);

-- --------------------------------------------------------
--
-- Estructura de tabla para la tabla `unidad_habitacional`
--

CREATE TABLE `unidad_habitacional` (
  `id` int(11) NOT NULL,
  `estado` enum('aprobado','rechazado','pendiente') NOT NULL,
  `cant_habitaciones` int(11) DEFAULT NULL,
  `bloque` varchar(20) DEFAULT NULL,
  `id_familia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admin_evalua_reclamo`
--
ALTER TABLE `admin_evalua_reclamo`
  ADD KEY `id_reclamo` (`id_reclamo`),
  ADD KEY `id_admin` (`id_admin`);

--
-- Indices de la tabla `admin_evalua_solicitud_registro`
--
ALTER TABLE `admin_evalua_solicitud_registro`
  ADD KEY `id_solicitud_registro` (`id_solicitud_registro`),
  ADD KEY `id_admin` (`id_admin`);

--
-- Indices de la tabla `admin_expulsa_familia`
--
ALTER TABLE `admin_expulsa_familia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_admin` (`id_admin`),
  ADD KEY `id_familia` (`id_familia`);

--
-- Indices de la tabla `admin_sanciona_familia`
--
ALTER TABLE `admin_sanciona_familia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_admin` (`id_admin`),
  ADD KEY `id_familia` (`id_familia`);

--
-- Indices de la tabla `admin_tramita_exoneracion_horas`
--
ALTER TABLE `admin_tramita_exoneracion_horas`
  ADD KEY `id_solicitud_exoneracion` (`id_solicitud_exoneracion`),
  ADD KEY `id_admin` (`id_admin`);

--
-- Indices de la tabla `admin_valida_comprobante_pago`
--
ALTER TABLE `admin_valida_comprobante_pago`
  ADD KEY `id_comprobante_pago` (`id_comprobante_pago`),
  ADD KEY `id_admin` (`id_admin`);

--
-- Indices de la tabla `admin_valida_horas_semanales`
--
ALTER TABLE `admin_valida_horas_semanales`
  ADD PRIMARY KEY (`id_aporte`,`id_admin`),
  ADD KEY `id_admin` (`id_admin`);

--
-- Indices de la tabla `adulto`
--
ALTER TABLE `adulto`
  ADD PRIMARY KEY (`cedula`);

--
-- Indices de la tabla `comprobante_pago`
--
ALTER TABLE `comprobante_pago`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cedula_titular` (`cedula_titular`);

--
-- Indices de la tabla `familia`
--
ALTER TABLE `familia`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `horas_semanales`
--
ALTER TABLE `horas_semanales`
  ADD PRIMARY KEY (`id_aporte`),
  ADD KEY `cedula_adulto` (`cedula_adulto`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`cedula`),
  ADD KEY `id_familia` (`id_familia`);

--
-- Indices de la tabla `persona_integra_familia`
--
ALTER TABLE `persona_integra_familia`
  ADD KEY `cedula_persona` (`cedula_persona`),
  ADD KEY `id_familia` (`id_familia`);

--
-- Indices de la tabla `reclamo`
--
ALTER TABLE `reclamo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_titular` (`id_titular`);

--
-- Indices de la tabla `registro_admin`
--
ALTER TABLE `registro_admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_familia_afectada` (`id_familia_afectada`),
  ADD KEY `cedula_admin` (`cedula_admin`);

--
-- Indices de la tabla `solicitud_exoneracion_horas`
--
ALTER TABLE `solicitud_exoneracion_horas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_familia` (`id_familia`);

--
-- Indices de la tabla `solicitud_registro`
--
ALTER TABLE `solicitud_registro`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_familia` (`id_familia`);

--
-- Indices de la tabla `unidad_habitacional`
--
ALTER TABLE `unidad_habitacional`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_familia` (`id_familia`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `admin_expulsa_familia`
--
ALTER TABLE `admin_expulsa_familia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `admin_sanciona_familia`
--
ALTER TABLE `admin_sanciona_familia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `comprobante_pago`
--
ALTER TABLE `comprobante_pago`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `familia`
--
ALTER TABLE `familia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `horas_semanales`
--
ALTER TABLE `horas_semanales`
  MODIFY `id_aporte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `reclamo`
--
ALTER TABLE `reclamo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `registro_admin`
--
ALTER TABLE `registro_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `solicitud_exoneracion_horas`
--
ALTER TABLE `solicitud_exoneracion_horas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `solicitud_registro`
--
ALTER TABLE `solicitud_registro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `unidad_habitacional`
--
ALTER TABLE `unidad_habitacional`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `admin_evalua_reclamo`
--
ALTER TABLE `admin_evalua_reclamo`
  ADD CONSTRAINT `admin_evalua_reclamo_ibfk_1` FOREIGN KEY (`id_reclamo`) REFERENCES `reclamo` (`id`),
  ADD CONSTRAINT `admin_evalua_reclamo_ibfk_2` FOREIGN KEY (`id_admin`) REFERENCES `adulto` (`cedula`);

--
-- Filtros para la tabla `admin_evalua_solicitud_registro`
--
ALTER TABLE `admin_evalua_solicitud_registro`
  ADD CONSTRAINT `admin_evalua_solicitud_registro_ibfk_1` FOREIGN KEY (`id_solicitud_registro`) REFERENCES `solicitud_registro` (`id`),
  ADD CONSTRAINT `admin_evalua_solicitud_registro_ibfk_2` FOREIGN KEY (`id_admin`) REFERENCES `adulto` (`cedula`);

--
-- Filtros para la tabla `admin_expulsa_familia`
--
ALTER TABLE `admin_expulsa_familia`
  ADD CONSTRAINT `admin_expulsa_familia_ibfk_1` FOREIGN KEY (`id_admin`) REFERENCES `adulto` (`cedula`),
  ADD CONSTRAINT `admin_expulsa_familia_ibfk_2` FOREIGN KEY (`id_familia`) REFERENCES `familia` (`id`);

--
-- Filtros para la tabla `admin_sanciona_familia`
--
ALTER TABLE `admin_sanciona_familia`
  ADD CONSTRAINT `admin_sanciona_familia_ibfk_1` FOREIGN KEY (`id_admin`) REFERENCES `adulto` (`cedula`),
  ADD CONSTRAINT `admin_sanciona_familia_ibfk_2` FOREIGN KEY (`id_familia`) REFERENCES `familia` (`id`);

--
-- Filtros para la tabla `admin_tramita_exoneracion_horas`
--
ALTER TABLE `admin_tramita_exoneracion_horas`
  ADD CONSTRAINT `admin_tramita_exoneracion_horas_ibfk_1` FOREIGN KEY (`id_solicitud_exoneracion`) REFERENCES `solicitud_exoneracion_horas` (`id`),
  ADD CONSTRAINT `admin_tramita_exoneracion_horas_ibfk_2` FOREIGN KEY (`id_admin`) REFERENCES `adulto` (`cedula`);

--
-- Filtros para la tabla `admin_valida_comprobante_pago`
--
ALTER TABLE `admin_valida_comprobante_pago`
  ADD CONSTRAINT `admin_valida_comprobante_pago_ibfk_1` FOREIGN KEY (`id_comprobante_pago`) REFERENCES `comprobante_pago` (`id`),
  ADD CONSTRAINT `admin_valida_comprobante_pago_ibfk_2` FOREIGN KEY (`id_admin`) REFERENCES `adulto` (`cedula`);

--
-- Filtros para la tabla `admin_valida_horas_semanales`
--
ALTER TABLE `admin_valida_horas_semanales`
  ADD CONSTRAINT `admin_valida_horas_semanales_ibfk_1` FOREIGN KEY (`id_aporte`) REFERENCES `horas_semanales` (`id_aporte`),
  ADD CONSTRAINT `admin_valida_horas_semanales_ibfk_2` FOREIGN KEY (`id_admin`) REFERENCES `adulto` (`cedula`);

--
-- Filtros para la tabla `adulto`
--
ALTER TABLE `adulto`
  ADD CONSTRAINT `adulto_ibfk_1` FOREIGN KEY (`cedula`) REFERENCES `persona` (`cedula`);

--
-- Filtros para la tabla `comprobante_pago`
--
ALTER TABLE `comprobante_pago`
  ADD CONSTRAINT `comprobante_pago_ibfk_1` FOREIGN KEY (`cedula_titular`) REFERENCES `adulto` (`cedula`);

--
-- Filtros para la tabla `horas_semanales`
--
ALTER TABLE `horas_semanales`
  ADD CONSTRAINT `horas_semanales_ibfk_1` FOREIGN KEY (`cedula_adulto`) REFERENCES `adulto` (`cedula`);

--
-- Filtros para la tabla `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`id_familia`) REFERENCES `familia` (`id`);

--
-- Filtros para la tabla `persona_integra_familia`
--
ALTER TABLE `persona_integra_familia`
  ADD CONSTRAINT `persona_integra_familia_ibfk_1` FOREIGN KEY (`cedula_persona`) REFERENCES `persona` (`cedula`),
  ADD CONSTRAINT `persona_integra_familia_ibfk_2` FOREIGN KEY (`id_familia`) REFERENCES `familia` (`id`);

--
-- Filtros para la tabla `reclamo`
--
ALTER TABLE `reclamo`
  ADD CONSTRAINT `reclamo_ibfk_1` FOREIGN KEY (`id_titular`) REFERENCES `adulto` (`cedula`);

--
-- Filtros para la tabla `registro_admin`
--
ALTER TABLE `registro_admin`
  ADD CONSTRAINT `registro_admin_ibfk_1` FOREIGN KEY (`id_familia_afectada`) REFERENCES `familia` (`id`),
  ADD CONSTRAINT `registro_admin_ibfk_2` FOREIGN KEY (`cedula_admin`) REFERENCES `adulto` (`cedula`);

--
-- Filtros para la tabla `solicitud_exoneracion_horas`
--

ALTER TABLE `solicitud_exoneracion_horas`
  ADD CONSTRAINT `solicitud_exoneracion_horas_ibfk_1` FOREIGN KEY (`id_familia`) REFERENCES `familia` (`id`);

--
-- Filtros para la tabla `solicitud_registro`
--
ALTER TABLE `solicitud_registro`
  ADD CONSTRAINT `solicitud_registro_ibfk_1` FOREIGN KEY (`id_familia`) REFERENCES `familia` (`id`);
--
-- Filtros para la tabla `unidad_habitacional`
--
ALTER TABLE `unidad_habitacional`
  ADD CONSTRAINT `unidad_habitacional_ibfk_1` FOREIGN KEY (`id_familia`) REFERENCES `familia` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
