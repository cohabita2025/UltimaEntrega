USE cohabita;

-- ====================================
-- TABLAS PRINCIPALES
-- ====================================

CREATE TABLE IF NOT EXISTS familia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estado ENUM('aprobado','rechazado','pendiente','expulsada') NOT NULL
);

CREATE TABLE IF NOT EXISTS persona (
    cedula CHAR(8) PRIMARY KEY,
    nombre VARCHAR(30) NOT NULL,
    primer_apellido VARCHAR(30) NOT NULL,
    segundo_apellido VARCHAR(30) ,
    genero ENUM('M','F') NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    copia_cedula VARCHAR(255),
    foto VARCHAR(255),
    id_familia INT,
    FOREIGN KEY (id_familia) REFERENCES familia(id)
);

CREATE TABLE IF NOT EXISTS adulto (
    cedula CHAR(8) PRIMARY KEY,
    declaracion_no_vivienda VARCHAR(255),
    recibo_sueldo VARCHAR(255),
    correo VARCHAR(100),
    contrasenia VARCHAR(30),
    telefono VARCHAR(15),
    rol ENUM('titular','admin'),
    FOREIGN KEY (cedula) REFERENCES persona(cedula)
);

CREATE TABLE IF NOT EXISTS unidad_habitacional (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estado ENUM('aprobado','rechazado','pendiente') NOT NULL,
    cant_habitaciones INT,
    bloque VARCHAR(20),
    id_familia INT,
    FOREIGN KEY (id_familia) REFERENCES familia(id)
);

CREATE TABLE IF NOT EXISTS horas_semanales (
    id_aporte INT AUTO_INCREMENT PRIMARY KEY,
    fecha_aporte DATE,
    tarea TEXT,
    cedula_adulto CHAR(8),
    estado ENUM('aprobado','rechazado','pendiente'),
    cant_horas INT,
    fecha_horas DATETIME,
    FOREIGN KEY (cedula_adulto) REFERENCES adulto(cedula)
);

CREATE TABLE IF NOT EXISTS reclamo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    motivo TEXT,
    fecha DATE,
    id_titular CHAR(8),
    estado ENUM('aprobado','rechazado','pendiente'),
    FOREIGN KEY (id_titular) REFERENCES adulto(cedula)
);

CREATE TABLE IF NOT EXISTS solicitud_registro (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE,
    estado ENUM('aprobado','rechazado','pendiente','en_votacion'),
    id_familia INT,
    FOREIGN KEY (id_familia) REFERENCES familia(id)
);

CREATE TABLE IF NOT EXISTS comprobante_pago (
    id INT AUTO_INCREMENT PRIMARY KEY,
    estado ENUM('aprobado','rechazado','pendiente'),
    monto DECIMAL(10,2),
    fecha DATE,
    fecha_envio_comprobante DATE,
    archivo_comprobante VARCHAR(255),
    cedula_emisor CHAR(8),
    cedula_titular CHAR(8),
    FOREIGN KEY (cedula_titular) REFERENCES adulto(cedula)
);

CREATE TABLE IF NOT EXISTS solicitud_exoneracion_horas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE,
    motivo TEXT,
    estado ENUM('aprobado','rechazado','pendiente','en_votacion'),
    pruebas VARCHAR(255),
    cant_horas INT,
    id_familia INT,
    FOREIGN KEY (id_familia) REFERENCES familia(id)
);

CREATE TABLE IF NOT EXISTS registro_admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE,
    accion VARCHAR(50),
    id_familia_afectada INT,
    cedula_admin CHAR(8),
    FOREIGN KEY (id_familia_afectada) REFERENCES familia(id),
    FOREIGN KEY (cedula_admin) REFERENCES adulto(cedula)
);

-- ====================================
-- RELACIONES / ADMIN EVALUACIONES
-- ====================================

CREATE TABLE IF NOT EXISTS persona_integra_familia (
    cedula_persona CHAR(8),
    id_familia INT,
    rol VARCHAR(50),
    FOREIGN KEY (cedula_persona) REFERENCES persona(cedula),
    FOREIGN KEY (id_familia) REFERENCES familia(id)
);

CREATE TABLE IF NOT EXISTS admin_valida_horas_semanales (
    id_aporte INT,
    id_admin CHAR(8),
    fecha DATE,
    conclusion ENUM('aprobado','rechazado'),
    razon_conclusion TEXT,
    FOREIGN KEY (id_aporte) REFERENCES horas_semanales(id_aporte),
    FOREIGN KEY (id_admin) REFERENCES adulto(cedula)
);

CREATE TABLE IF NOT EXISTS admin_evalua_reclamo (
    id_reclamo INT,
    id_admin CHAR(8),
    fecha DATE,
    conclusion ENUM('aprobado','rechazado'),
    razon_conclusion TEXT,
    FOREIGN KEY (id_reclamo) REFERENCES reclamo(id),
    FOREIGN KEY (id_admin) REFERENCES adulto(cedula)
);

CREATE TABLE IF NOT EXISTS admin_evalua_solicitud_registro (
    id_solicitud_registro INT,
    id_admin CHAR(8),
    fecha DATE,
    conclusion ENUM('aprobado','rechazado'),
    razon_conclusion TEXT,
    FOREIGN KEY (id_solicitud_registro) REFERENCES solicitud_registro(id),
    FOREIGN KEY (id_admin) REFERENCES adulto(cedula)
);

CREATE TABLE IF NOT EXISTS admin_valida_comprobante_pago (
    id_comprobante_pago INT,
    id_admin CHAR(8),
    fecha DATE,
    conclusion ENUM('aprobado','rechazado'),
    razon_conclusion TEXT,
    FOREIGN KEY (id_comprobante_pago) REFERENCES comprobante_pago(id),
    FOREIGN KEY (id_admin) REFERENCES adulto(cedula)
);

CREATE TABLE IF NOT EXISTS admin_tramita_exoneracion_horas (
    id_solicitud_exoneracion INT,
    id_admin CHAR(8),
    fecha DATE,
    conclusion ENUM('aprobado','rechazado'),
    razon_conclusion TEXT,
    FOREIGN KEY (id_solicitud_exoneracion) REFERENCES solicitud_exoneracion_horas(id),
    FOREIGN KEY (id_admin) REFERENCES adulto(cedula)
);

CREATE TABLE IF NOT EXISTS admin_expulsa_familia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_admin CHAR(8),
    id_familia INT,
    fecha DATE,
    motivo TEXT,
    pruebas VARCHAR(255),
    FOREIGN KEY (id_admin) REFERENCES adulto(cedula),
    FOREIGN KEY (id_familia) REFERENCES familia(id)
);

CREATE TABLE IF NOT EXISTS admin_sanciona_familia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_admin CHAR(8),
    id_familia INT,
    fecha DATE,
    motivo TEXT,
    prueba VARCHAR(255),
    FOREIGN KEY (id_admin) REFERENCES adulto(cedula),
    FOREIGN KEY (id_familia) REFERENCES familia(id)
);
